/* Forja — interface. Depende de logic.js (window.Forja). */
(function () {
  'use strict';
  const F = window.Forja;
  const $view = document.getElementById('view');
  const $layer = document.getElementById('layer');
  const $tag = document.getElementById('tag');

  /* ---------- Utilidades ---------- */
  const esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; }); };
  const fmt = function (n, d) { return Number(n).toLocaleString('pt-BR', { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }); };
  const hojeISO = function () { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };
  const dataBR = function (iso) { const p = String(iso).slice(0, 10).split('-'); return p[2] + '/' + p[1] + '/' + p[0]; };
  const clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  const ls = {
    get: function (k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* sem armazenamento local */ } }
  };
  function toast(msg) {
    const t = document.createElement('div');
    t.className = 'toast'; t.textContent = msg; t.setAttribute('role', 'status');
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 2600);
  }
  function imgs(id, big) {
    return '<div class="anim' + (big ? ' big' : '') + '"><img src="img/' + esc(id) + '_0.jpg" alt="" loading="lazy"><img src="img/' + esc(id) + '_1.jpg" alt="" loading="lazy"></div>';
  }

  /* ---------- Armazenamento: banco do artefato (por pessoa) ou, sem ele, só este navegador ---------- */
  const Store = {
    modo: 'local', db: null, uid: null, fila: Promise.resolve(),
    init: async function () {
      try {
        if (typeof claude === 'undefined' || !claude.use) return;
        const limite = new Promise(function (r) { setTimeout(function () { r(null); }, 10000); });
        const res = await Promise.all([Promise.race([claude.use('db'), limite]), Promise.race([claude.use('user'), limite])]);
        const db = res[0], user = res[1];
        if (!db || !user) return;
        const id = await user.id();
        if (!id) return;
        this.db = db; this.uid = id; this.modo = 'db';
      } catch (e) { /* segue no modo local */ }
    },
    ref: function () { return this.db.doc('data/users/' + this.uid + '/forja'); },
    getPerfil: async function () {
      if (this.modo === 'db') { const s = await this.ref().get(); return s.exists ? clone(s.data()) : null; }
      return ls.get('forja.perfil');
    },
    // Uma gravação por vez no mesmo documento
    savePerfil: function (obj) {
      const dados = clone(obj);
      const self = this;
      this.fila = this.fila.then(function () {
        if (self.modo === 'db') return self.ref().set(dados);
        ls.set('forja.perfil', dados);
      }).catch(function (e) { toast('Não consegui salvar. Tente de novo.'); console.error(e); });
      return this.fila;
    },
    getLogs: async function () {
      if (this.modo === 'db') {
        const q = await this.ref().collection('treinos').orderBy('data', 'desc').limit(300).get();
        return q.docs.map(function (d) { return clone(d.data()); });
      }
      return ls.get('forja.treinos') || [];
    },
    addLog: async function (log) {
      if (this.modo === 'db') return this.ref().collection('treinos').doc(log.id).set(log);
      const l = ls.get('forja.treinos') || []; l.unshift(log); ls.set('forja.treinos', l);
    },
    delLog: async function (id) {
      if (this.modo === 'db') return this.ref().collection('treinos').doc(id).delete();
      ls.set('forja.treinos', (ls.get('forja.treinos') || []).filter(function (x) { return x.id !== id; }));
    }
  };

  /* ---------- Estado ---------- */
  const S = {
    perfil: null, logs: [], aba: 'treino', dia: null, rascunho: ls.get('forja.rascunho') || {},
    abertas: {}, onb: { passo: 0, r: {} }, descanso: null, trocaDieta: null, exSel: null
  };
  function salvarRascunho() { ls.set('forja.rascunho', S.rascunho); }

  /* ---------- Questionário ---------- */
  const PASSOS = [
    { t: 'Sobre você', campos: ['sexo', 'idade', 'altura', 'peso'] },
    { t: 'Seus objetivos', campos: ['objetivos'] },
    { t: 'Sua rotina de treino', campos: ['nivel', 'dias', 'diasSemana', 'tempo'] },
    { t: 'Como você quer treinar', campos: ['divisao', 'metodo', 'estilo'] },
    { t: 'Onde e como você treina', campos: ['equip', 'trabalho'] },
    { t: 'Alimentação', campos: ['refeicoes'] }
  ];
  const OPC = {
    sexo: [['M', 'Masculino'], ['F', 'Feminino']],
    objetivos: [['emagrecer', 'Emagrecer', 'Perder gordura (déficit de 20%)'], ['definir', 'Definir', 'Déficit leve de 10%, mantendo massa'], ['massa', 'Ganhar massa', 'Hipertrofia (superávit de 10%)'], ['forca', 'Ficar mais forte', 'Cargas altas e poucas repetições']],
    nivel: [['iniciante', 'Iniciante', 'Menos de 6 meses treinando'], ['intermediario', 'Intermediário', '6 meses a 2 anos'], ['avancado', 'Avançado', 'Mais de 2 anos']],
    dias: [[2, '2'], [3, '3'], [4, '4'], [5, '5'], [6, '6']],
    tempo: [[30, '30 min'], [45, '45 min'], [60, '60 min'], [75, '75 min'], [90, '90 min']],
    equip: [['gym', 'Academia completa', 'Máquinas, barras, polias e halteres'], ['db', 'Em casa com halteres', 'Halteres e um banco ou cadeira firme'], ['bw', 'Em casa sem equipamento', 'Só o peso do corpo']],
    trabalho: [['sentado', 'Sentado a maior parte do dia'], ['em_pe', 'Em pé ou andando bastante'], ['pesado', 'Trabalho físico pesado']],
    refeicoes: [[3, '3'], [4, '4'], [5, '5'], [6, '6']],
    diasSemana: [['1', 'Seg'], ['2', 'Ter'], ['3', 'Qua'], ['4', 'Qui'], ['5', 'Sex'], ['6', 'Sáb'], ['0', 'Dom']],
    divisao: [['auto', 'Automática', 'O Forja escolhe pela quantidade de dias (3 dias = corpo inteiro)'], ['abc', 'ABC clássico', 'A: peito, ombro e tríceps · B: costas e bíceps · C: pernas']],
    estilo: [['misto', 'Misto', 'Alterna pesos livres e máquinas'], ['maquinas', 'Mais máquinas', 'Máquinas, polias e Smith primeiro'], ['livres', 'Mais pesos livres', 'Barras e halteres primeiro']],
    metodo: [['normal', 'Tradicional', 'Descanso depois de cada série'], ['trinca', 'Trinca', '3 exercícios seguidos, sem descanso entre eles. Descansa só no fim. Treino mais rápido e intenso']]
  };
  const ROT = { idade: 'Idade (anos)', altura: 'Altura (cm)', peso: 'Peso (kg)', sexo: 'Sexo', objetivos: 'Objetivos (escolha um ou mais)', nivel: 'Nível', dias: 'Treinos por semana', tempo: 'Tempo por treino', equip: 'Equipamento', trabalho: 'No dia a dia você fica', refeicoes: 'Refeições por dia', divisao: 'Divisão do treino', diasSemana: 'Em quais dias você treina', metodo: 'Método', estilo: 'Preferência de equipamento (academia)' };
  const LIM_NUM = { idade: [14, 90], altura: [130, 220], peso: [35, 250] };
  const MULTI = { objetivos: true, diasSemana: true }; // campos em que dá para marcar mais de uma opção

  function renderOnb(erro) {
    const p = PASSOS[S.onb.passo], r = S.onb.r;
    let h = '<div class="stack">';
    if (S.onb.passo === 0 && !S.perfil) {
      h += '<div class="card stack"><h2>Vamos montar seu plano</h2><p class="muted" style="margin:0">Cinco perguntas rápidas. Com elas o Forja calcula suas calorias e macros e monta a divisão de treino.</p></div>';
    }
    h += '<div class="card stack"><div class="row between"><h3>' + esc(p.t) + '</h3><span class="muted small num">' + (S.onb.passo + 1) + ' de ' + PASSOS.length + '</span></div>';
    p.campos.forEach(function (c) {
      if (LIM_NUM[c]) {
        h += '<label class="f" for="in-' + c + '">' + ROT[c] + '<input class="in num" id="in-' + c + '" data-campo="' + c + '" type="number" inputmode="decimal" step="' + (c === 'peso' ? '0.1' : '1') + '" value="' + esc(r[c] || '') + '"></label>';
      } else {
        const opts = OPC[c];
        const comDesc = opts[0].length > 2 || c === 'trabalho';
        h += '<div class="stack" style="gap:8px"><span class="small muted" style="font-weight:600">' + ROT[c] + '</span>';
        if (comDesc) {
          opts.forEach(function (o) {
            const on = MULTI[c] ? (r[c] || []).indexOf(o[0]) >= 0 : String(r[c]) === String(o[0]);
            h += '<button type="button" class="opt' + (on ? ' on' : '') + '" data-act="onb-opt" data-campo="' + c + '" data-v="' + o[0] + '" aria-pressed="' + on + '"><b>' + (MULTI[c] ? (on ? '☑ ' : '☐ ') : '') + esc(o[1]) + '</b>' + (o[2] ? '<span>' + esc(o[2]) + '</span>' : '') + '</button>';
          });
        } else {
          h += '<div class="chips">';
          opts.forEach(function (o) { const on = MULTI[c] ? (r[c] || []).indexOf(o[0]) >= 0 : String(r[c]) === String(o[0]); h += '<button type="button" class="chip' + (on ? ' on' : '') + '" data-act="onb-opt" data-campo="' + c + '" data-v="' + o[0] + '" aria-pressed="' + on + '">' + esc(o[1]) + '</button>'; });
          h += '</div>';
        }
        h += '</div>';
      }
    });
    h += '<div class="err" id="onb-err">' + esc(erro || '') + '</div>';
    h += '<div class="row">';
    if (S.onb.passo > 0) h += '<button class="btn" data-act="onb-voltar">Voltar</button>';
    else if (S.perfil) h += '<button class="btn" data-act="onb-cancelar">Cancelar</button>';
    h += '<button class="btn primary grow" data-act="onb-seguir">' + (S.onb.passo === PASSOS.length - 1 ? 'Gerar meu plano' : 'Continuar') + '</button></div></div>';
    h += '<p class="note">O Forja é um app de uso pessoal e educativo. Ele não substitui médico, nutricionista ou profissional de educação física.</p></div>';
    $view.innerHTML = h;
    renderNav();
  }
  function lerNumeros() {
    document.querySelectorAll('input[data-campo]').forEach(function (i) { S.onb.r[i.dataset.campo] = i.value === '' ? '' : Number(String(i.value).replace(',', '.')); });
  }
  function validarPasso() {
    lerNumeros();
    const p = PASSOS[S.onb.passo];
    for (let i = 0; i < p.campos.length; i++) {
      const c = p.campos[i], v = S.onb.r[c];
      if (c === 'diasSemana') {
        if (!v || v.length !== Number(S.onb.r.dias)) return 'Escolha ' + S.onb.r.dias + ' dias da semana (você disse que treina ' + S.onb.r.dias + ' vezes).';
        continue;
      }
      if (v === '' || v == null || (MULTI[c] && !v.length)) return MULTI[c] ? 'Escolha pelo menos um objetivo.' : 'Preencha: ' + ROT[c].toLowerCase() + '.';
      if (LIM_NUM[c] && (v < LIM_NUM[c][0] || v > LIM_NUM[c][1])) return ROT[c] + ' deve ficar entre ' + LIM_NUM[c][0] + ' e ' + LIM_NUM[c][1] + '.';
    }
    return '';
  }
  async function concluirOnb() {
    const r = clone(S.onb.r);
    ['dias', 'tempo', 'refeicoes', 'idade', 'altura', 'peso'].forEach(function (k) { r[k] = Number(r[k]); });
    r.objetivo = r.objetivos[0]; // compatibilidade com versões antigas
    if (!r.diasSemana || r.diasSemana.length !== r.dias) r.diasSemana = diasPadrao(r.dias);
    if (S.perfil && String(F.listaObjetivos(S.perfil.resp)) !== String(r.objetivos)) r.ajusteKcal = 0; // objetivo novo: zera ajustes do check-in
    const novo = !S.perfil;
    const p = S.perfil || { pesos: [], trocasTreino: {}, trocasDieta: {}, criado: hojeISO() };
    // Mudou a divisão ou o equipamento: as trocas de exercício antigas deixam de valer
    if (!novo && (p.resp.dias !== r.dias || p.resp.equip !== r.equip || p.resp.tempo !== r.tempo || p.resp.divisao !== r.divisao || p.resp.metodo !== r.metodo || p.resp.estilo !== r.estilo || String(F.listaObjetivos(p.resp)) !== String(r.objetivos))) p.trocasTreino = {};
    p.resp = r;
    if (!p.pesos.length || p.pesos[p.pesos.length - 1].kg !== r.peso) registrarPesoNoPerfil(p, r.peso);
    S.perfil = p; S.dia = null; S.wdSel = null;
    await Store.savePerfil(p);
    S.aba = novo ? 'treino' : 'perfil';
    toast(novo ? 'Plano criado. Bora treinar!' : 'Plano atualizado');
    render();
  }
  function registrarPesoNoPerfil(p, kg) {
    const d = hojeISO();
    p.pesos = (p.pesos || []).filter(function (x) { return x.d !== d; });
    p.pesos.push({ d: d, kg: kg });
    p.pesos.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
    p.pesos = p.pesos.slice(-400);
  }

  /* ---------- Navegação ---------- */
  const ICON = {
    treino: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 8v8M3 10v4M18 8v8M21 10v4M6 12h12"/></svg>',
    dieta: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="13" r="7"/><path d="M12 6V3M9 3h6"/></svg>',
    progresso: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19h16M5 15l4-4 3 3 6-7"/></svg>',
    perfil: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/></svg>',
    coach: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h16v11H9l-5 4z"/><path d="M8 9h8M8 12h5"/></svg>'
  };
  const NOMES_ABA = { treino: 'Treino', dieta: 'Dieta', coach: 'Treinador', progresso: 'Progresso', perfil: 'Perfil' };
  function renderNav() {
    let nav = document.getElementById('tabs');
    if (!S.perfil || S.aba === 'onb') { if (nav) nav.remove(); return; }
    if (!nav) { nav = document.createElement('nav'); nav.id = 'tabs'; nav.className = 'tabs'; nav.setAttribute('aria-label', 'Seções'); document.body.appendChild(nav); }
    nav.innerHTML = '<div class="in">' + Object.keys(NOMES_ABA).map(function (k) {
      return '<button data-act="aba" data-aba="' + k + '" class="' + (S.aba === k ? 'on' : '') + '"' + (S.aba === k ? ' aria-current="page"' : '') + '>' + ICON[k] + NOMES_ABA[k] + '</button>';
    }).join('') + '</div>';
  }

  /* ---------- Treino ---------- */
  // Plano do app + exercícios que o usuário adicionou em cada dia
  /* ---------- Fichas da academia e número das máquinas ----------
     Números das máquinas da academia (tickets de 17/11/2026). O usuário pode editar em cada exercício. */
  const MAQ_PADRAO = { Butterfly: '4 ou 5', Reverse_Machine_Flyes: '4 ou 5', 'V-Bar_Pulldown': '8, 9 ou 11', Leverage_Iso_Row: '13', Standing_Biceps_Cable_Curl: '1, 2 ou 3' };
  // Fichas impressas pela academia, prontas para adicionar (sem nomes de pessoas). INT 1' = 60 s.
  const FICHAS_PRONTAS = [
    { id: 'm2', letra: '2', nome: 'Treino 2 adaptativo masculino', validade: '26/01/2027', itens: [
      ['Butterfly', 'Peck deck', '4 ou 5', 3, '10'], ['Reverse_Machine_Flyes', 'Crucifixo inverso máquina', '4 ou 5', 3, '10'],
      ['V-Bar_Pulldown', 'Puxador frente pegada neutra', '8, 9 ou 11', 3, '12'], ['Leverage_Iso_Row', 'Remada sentada máquina', '13', 3, '12'],
      ['Side_Lateral_Raise', 'Elevação lateral halteres', '', 3, '12–15'], ['Standing_Biceps_Cable_Curl', 'Rosca direta cross', '', 3, '12'],
      ['Triceps_Pushdown', 'Tríceps polia barra reta', '', 3, '12']] },
    { id: 'f2', letra: '2', nome: 'Treino 2 adaptativo feminino', validade: '26/01/2027', itens: [
      ['V-Bar_Pulldown', 'Puxador frente pegada neutra', '8, 9 ou 11', 3, '12–15'], ['Butterfly', 'Crucifixo máquina', '4 ou 5', 3, '12–15'],
      ['Side_Lateral_Raise', 'Elevação lateral halteres', '', 3, '12–15'], ['Triceps_Pushdown', 'Tríceps polia barra', '', 3, '12–15'],
      ['Standing_Biceps_Cable_Curl', 'Rosca na polia baixa', '1, 2 ou 3', 3, '12–15'], ['Crunches', 'Abd supra curto solo', '', 3, '12–15']] }
  ];
  function usaFichas() { return !!(S.perfil.usarFichas && (S.perfil.fichas || []).length); }
  // Número da máquina: o que o usuário digitou > o da ficha > o padrão da academia
  function maquinaDe(it) {
    const m = S.perfil.maquinas || {};
    if (Object.prototype.hasOwnProperty.call(m, it.ex)) return m[it.ex];
    return it.maquina || MAQ_PADRAO[it.ex] || '';
  }
  function fichaParaDias() {
    const tr = S.perfil.trocasTreino || {};
    return S.perfil.fichas.map(function (f) {
      return { letra: f.letra, nome: f.nome, ficha: f.id, itens: f.itens.filter(function (x) { return F.EX_BY_ID[x.ex]; }).map(function (x, i) {
        const chave = 'f' + f.id + '_' + i;
        return { chave: chave, ex: tr[chave] && F.EX_BY_ID[tr[chave]] ? tr[chave] : x.ex, series: x.series, reps: x.reps, descanso: x.descanso, maquina: x.maquina, nomeFicha: x.nomeFicha };
      }) };
    });
  }
  // Número livre para a ficha nova (o "2" do "Treino 2"; se já existir, usa o próximo)
  function letraLivre(pref) {
    const usadas = (S.perfil.fichas || []).map(function (f) { return f.letra; });
    let l = String(pref || '').match(/\d+/); l = l ? l[0] : '';
    if (l && usadas.indexOf(l) < 0) return l;
    for (let n = 1; n < 50; n++) if (usadas.indexOf(String(n)) < 0) return String(n);
    return String(Date.now() % 1000);
  }
  async function adicionarFicha(f) {
    S.perfil.fichas = S.perfil.fichas || [];
    f.id = f.id + '_' + Date.now().toString(36);
    f.letra = letraLivre(f.letra || f.nome);
    S.perfil.fichas.push(f);
    S.perfil.usarFichas = true;
    S.perfil.maquinas = S.perfil.maquinas || {};
    f.itens.forEach(function (x) { if (x.maquina && !Object.prototype.hasOwnProperty.call(S.perfil.maquinas, x.ex)) S.perfil.maquinas[x.ex] = x.maquina; });
    await Store.savePerfil(S.perfil);
    S.wdSel = null;
  }

  function plano() {
    const pl = usaFichas() ? fichaParaDias() : F.montarTreino(S.perfil.resp, S.perfil.trocasTreino);
    const ext = S.perfil.extrasTreino || {};
    pl.forEach(function (d) {
      (ext[d.letra] || []).forEach(function (id, i) {
        const ex = F.EX_BY_ID[id];
        if (!ex) return;
        const p = F.prescricao(ex, F.estiloTreino(S.perfil.resp), S.perfil.resp.nivel);
        d.itens.push({ chave: 'x' + d.letra + '_' + i, ex: id, series: p.series, reps: p.reps, descanso: p.descanso, extra: true });
      });
      // Exercícios que o usuário tirou do treino (até restaurar)
      const rem = S.perfil.removidosTreino || {};
      d.removidos = d.itens.filter(function (it) { return rem[d.letra + ':' + it.chave]; });
      d.itens = d.itens.filter(function (it) { return !rem[d.letra + ':' + it.chave]; });
      // Séries a mais ou a menos que o usuário escolheu em cada exercício
      const aj = S.perfil.seriesAjuste || {};
      d.itens.forEach(function (it) {
        const k = d.letra + ':' + it.chave;
        if (aj[k]) it.series = Math.min(8, Math.max(1, it.series + aj[k]));
        it.ajusteKey = k;
      });
    });
    return pl;
  }
  /* ---------- Agenda da semana ----------
     Os dias escolhidos, em ordem de segunda a domingo, recebem os treinos A, B, C… em sequência
     (se houver mais dias que treinos, a sequência recomeça). */
  const NOME_DIA = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
  const CURTO_DIA = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  function diasPadrao(n) {
    return ({ 1: ['3'], 2: ['2', '4'], 3: ['1', '3', '5'], 4: ['1', '2', '4', '5'], 5: ['1', '2', '3', '4', '5'], 6: ['1', '2', '3', '4', '5', '6'], 7: ['1', '2', '3', '4', '5', '6', '0'] })[n] || ['1', '3', '5'];
  }
  function agenda(pl) {
    const r = S.perfil.resp;
    let ds = (r.diasSemana && r.diasSemana.length) ? r.diasSemana : diasPadrao(Number(r.dias) || 3);
    ds = ds.map(Number).sort(function (a, b) { return ((a + 6) % 7) - ((b + 6) % 7); }); // segunda primeiro
    return ds.map(function (wd, i) { return { wd: wd, idx: i % pl.length }; });
  }
  function hojeWd() { return new Date().getDay(); }
  // Treino de hoje; num dia de descanso, o próximo da semana
  function proximoDia(pl) {
    const ag = agenda(pl), w = hojeWd();
    const hoje = ag.find(function (a) { return a.wd === w; });
    if (hoje) return hoje.idx;
    for (let k = 1; k <= 7; k++) { const a = ag.find(function (x) { return x.wd === (w + k) % 7; }); if (a) return a.idx; }
    return 0;
  }
  // Última vez que o exercício foi feito: série com mais carga
  function ultimaVez(exId) {
    for (let i = 0; i < S.logs.length; i++) {
      const it = (S.logs[i].itens || []).find(function (x) { return x.ex === exId; });
      if (it && it.series && it.series.length) {
        const best = it.series.reduce(function (a, b) { return (Number(b.kg) || 0) > (Number(a.kg) || 0) ? b : a; });
        return { data: S.logs[i].data, kg: Number(best.kg) || 0, reps: best.reps, series: it.series };
      }
    }
    return null;
  }
  function rascunhoDia(letra) { S.rascunho[letra] = S.rascunho[letra] || {}; return S.rascunho[letra]; }

  function renderTreino() {
    const pl = plano();
    const sug = proximoDia(pl), ag = agenda(pl), w = hojeWd();
    const treinaHoje = ag.some(function (a) { return a.wd === w; });
    if (S.wdSel == null) S.wdSel = treinaHoje ? w : (ag.find(function (a) { return a.idx === sug; }) || ag[0]).wd;
    const sel = ag.find(function (a) { return a.wd === S.wdSel; }) || ag[0];
    S.dia = sel.idx;
    const dia = pl[S.dia];
    const rd = rascunhoDia(dia.letra);
    let h = '<div class="stack">';
    h += '<div class="days" role="tablist">' + ag.map(function (a) {
      const d = pl[a.idx], on = a.wd === S.wdSel;
      return '<button class="day' + (on ? ' on' : '') + '" data-act="dia-sem" data-w="' + a.wd + '" role="tab" aria-selected="' + on + '">' + (a.wd === w ? '<div class="next">Hoje</div>' : '<div class="next" style="visibility:hidden">.</div>') + '<b>' + CURTO_DIA[a.wd] + '</b><span>Treino ' + d.letra + '</span></button>';
    }).join('') + '</div>';
    const feitoHoje = S.logs.some(function (l) { return l.data.slice(0, 10) === hojeISO(); });
    if (!treinaHoje) {
      const prox = ag.find(function (a) { return a.idx === sug && a.wd !== w; }) || ag[0];
      h += '<div class="card stack" style="border-color:var(--ok)"><h3>Hoje (' + NOME_DIA[w].toLowerCase() + ') é dia de descanso</h3><p class="small muted" style="margin:0">Próximo treino: <b>' + NOME_DIA[prox.wd] + ' · Treino ' + pl[prox.idx].letra + '</b>. Um cardio leve ou caminhada ajuda na recuperação. Se quiser treinar mesmo assim, escolha o dia acima.</p></div>';
    } else if (feitoHoje && S.wdSel === w) {
      h += '<div class="card" style="border-color:var(--ok)"><b>Treino de hoje concluído.</b> <span class="small muted">Bom trabalho! O próximo aparece no dia dele.</span></div>';
    }
    const pulados = rd._pulados || {};
    const totalSeries = dia.itens.reduce(function (a, it) { return a + (pulados[it.chave] ? 0 : it.series); }, 0);
    const feitas = dia.itens.reduce(function (a, it) { return a + ((rd[it.chave] || []).filter(function (s) { return s && s.ok; }).length); }, 0);
    h += '<div class="card"><div class="row between"><div><h2>' + NOME_DIA[S.wdSel] + ' · Treino ' + dia.letra + '</h2><div class="muted">' + esc(dia.nome) + '</div></div><div style="text-align:right"><div class="big num">' + feitas + '<span class="muted" style="font-size:18px">/' + totalSeries + '</span></div><div class="small muted">séries feitas</div></div></div>';
    h += '<div class="bar" style="margin-top:12px"><i style="width:' + (totalSeries ? Math.round(feitas / totalSeries * 100) : 0) + '%"></i></div></div>';
    dia.itens.forEach(function (it) {
      if (it.bloco && it.posBloco === 1) {
        const ultimo = dia.itens.filter(function (x) { return x.bloco === it.bloco; }).slice(-1)[0];
        h += '<div class="card" style="border-color:var(--ember);background:var(--ember-soft)"><h3 style="color:var(--ember)">' + (it.tamBloco === 3 ? 'Trinca ' : 'Bloco ') + it.bloco + '</h3><div class="small">Faça 1 série de cada exercício em sequência, sem descanso. Depois do último, descanse ' + ultimo.descanso + ' s e repita. ' + it.series + ' voltas no total.</div></div>';
      }
      const ex = F.EX_BY_ID[it.ex];
      if (pulados[it.chave]) {
        h += '<article class="card" style="opacity:.6"><div class="row between"><div><b>' + esc(ex.nome) + '</b><div class="small muted">Pulado hoje</div></div><button class="btn sm" data-act="despular-ex" data-k="' + it.chave + '">Desfazer</button></div></article>';
        return;
      }
      const ult = ultimaVez(it.ex);
      const linhas = rd[it.chave] || [];
      h += '<article class="card ex"><div class="head">' + imgs(it.ex) + '<div class="stack" style="gap:2px"><h3>' + esc(ex.nome) + '</h3>' + linhaMaquina(it) + '<div class="meta">' + esc(F.GRUPOS[ex.g]) + (it.nomeFicha && it.nomeFicha.toLowerCase() !== ex.nome.toLowerCase() ? ' · na ficha: ' + esc(it.nomeFicha) : '') + '</div><div class="pres num">' + it.series + ' × ' + esc(it.reps) + '</div><div class="meta">' + (it.bloco ? it.posBloco + 'º da trinca · ' : '') + (it.descanso ? 'Descanso ' + it.descanso + ' s' : 'Sem descanso: vá direto ao próximo') + '</div>' + (ult ? '<div class="last num">Última vez (' + dataBR(ult.data) + '): ' + fmt(ult.kg, 1) + ' kg × ' + esc(ult.reps) + '</div>' : '') + '</div></div>';
      h += '<div class="sets"><div class="lbl"><span>Série</span><span>Kg</span><span>Reps</span><span>Feita</span></div>';
      for (let s = 0; s < it.series; s++) {
        const v = linhas[s] || {};
        const phKg = ult && ult.series[s] ? ult.series[s].kg : '';
        const phRp = ult && ult.series[s] ? ult.series[s].reps : '';
        h += '<div class="set' + (v.ok ? ' done' : '') + '"><span class="n num">' + (s + 1) + '</span>' +
          '<input class="num" id="kg-' + it.chave + '-' + s + '" aria-label="Carga da série ' + (s + 1) + ' em kg" type="number" inputmode="decimal" step="0.5" data-set="kg" data-k="' + it.chave + '" data-s="' + s + '" value="' + esc(v.kg != null ? v.kg : '') + '" placeholder="' + esc(phKg) + '">' +
          '<input class="num" id="rp-' + it.chave + '-' + s + '" aria-label="Repetições da série ' + (s + 1) + '" type="number" inputmode="numeric" data-set="reps" data-k="' + it.chave + '" data-s="' + s + '" value="' + esc(v.reps != null ? v.reps : '') + '" placeholder="' + esc(phRp) + '">' +
          '<button class="ok' + (v.ok ? ' on' : '') + '" data-act="serie" data-k="' + it.chave + '" data-s="' + s + '" data-d="' + it.descanso + '" aria-label="Marcar série ' + (s + 1) + ' como feita" aria-pressed="' + (!!v.ok) + '"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5 9-10"/></svg></button></div>';
      }
      h += '<div class="row" style="gap:6px;justify-content:flex-end"><button class="btn sm ghost" data-act="serie-menos" data-a="' + esc(it.ajusteKey) + '"' + (it.series <= 1 ? ' disabled' : '') + ' aria-label="Uma série a menos">− série</button><button class="btn sm ghost" data-act="serie-mais" data-a="' + esc(it.ajusteKey) + '"' + (it.series >= 8 ? ' disabled' : '') + ' aria-label="Uma série a mais">+ série</button></div>';
      h += '</div><div class="tools"><button class="btn sm" data-act="como" data-k="' + it.chave + '">' + (S.abertas[it.chave] ? 'Fechar dica' : 'Como fazer') + '</button><button class="btn sm" data-act="trocar-ex" data-k="' + it.chave + '" data-ex="' + it.ex + '">Trocar</button><button class="btn sm" data-act="pular-ex" data-k="' + it.chave + '">Pular hoje</button>' + (it.extra ? '<button class="btn sm ghost" data-act="remover-ex" data-k="' + it.chave + '">Remover</button>' : '<button class="btn sm ghost" data-act="tirar-ex" data-k="' + it.chave + '">Tirar do treino</button>') + '</div>';
      if (S.abertas[it.chave]) h += '<div class="dica">' + imgs(it.ex, true) + '<p style="margin:10px 0 0">' + esc(ex.dica) + '</p></div>';
      h += '</article>';
    });
    if (dia.removidos && dia.removidos.length) h += '<div class="card stack"><div class="small muted">Tirados deste treino:</div>' + dia.removidos.map(function (it) { return '<div class="row between"><span>' + esc(F.EX_BY_ID[it.ex].nome) + '</span><button class="btn sm ghost" data-act="restaurar-ex" data-k="' + it.chave + '">Restaurar</button></div>'; }).join('') + '</div>';
    h += '<div class="row"><button class="btn grow" data-act="add-ex">+ Adicionar exercício</button><button class="btn grow" data-act="foto-aparelho">Foto do aparelho</button></div><input type="file" id="aparelho-in" accept="image/*" capture="environment" hidden>';
    h += renderAparelho(dia.letra);
    h += '<button class="btn primary block" data-act="finalizar"' + (feitas ? '' : ' disabled') + '>Finalizar treino ' + dia.letra + '</button>';
    if (feitas || Object.keys(rd).length) h += '<button class="btn ghost block" data-act="descartar-treino">Descartar marcações deste treino</button>';
    if (S.logs.length) h += '<p class="note">Salvou um treino por engano? Apague em Progresso → Treinos → Apagar.</p>';
    h += renderFichas();
    h += renderCardio();
    h += '<p class="note">Imagens: Free Exercise DB (domínio público). Os campos em cinza mostram o que você fez da última vez.</p></div>';
    $view.innerHTML = h;
  }

  function marcarSerie(k, s, descanso) {
    const pl = plano(), dia = pl[S.dia], rd = rascunhoDia(dia.letra);
    rd[k] = rd[k] || [];
    const v = rd[k][s] || {};
    // Campos vazios herdam o que foi feito da última vez (o valor em cinza)
    const kgIn = document.getElementById('kg-' + k + '-' + s), rpIn = document.getElementById('rp-' + k + '-' + s);
    if (!v.ok) {
      if (kgIn && kgIn.value === '' && kgIn.placeholder !== '') v.kg = Number(kgIn.placeholder);
      if (rpIn && rpIn.value === '' && rpIn.placeholder !== '') v.reps = Number(rpIn.placeholder);
    }
    v.ok = !v.ok;
    rd[k][s] = v;
    salvarRascunho();
    if (v.ok && descanso > 0) iniciarDescanso(descanso);
    render();
  }

  async function finalizarTreino() {
    const pl = plano(), dia = pl[S.dia], rd = rascunhoDia(dia.letra);
    const itens = [];
    dia.itens.forEach(function (it) {
      const ss = (rd[it.chave] || []).filter(function (x) { return x && x.ok; }).map(function (x) { return { kg: Number(x.kg) || 0, reps: Number(x.reps) || 0 }; });
      if (ss.length) itens.push({ ex: it.ex, series: ss });
    });
    if (!itens.length) return;
    const vol = itens.reduce(function (a, it) { return a + it.series.reduce(function (b, s) { return b + s.kg * s.reps; }, 0); }, 0);
    const log = { id: Date.now().toString(36), data: new Date().toISOString(), letra: dia.letra, nome: dia.nome, itens: itens, volume: Math.round(vol) };
    try {
      await Store.addLog(log);
      S.logs.unshift(log);
      delete S.rascunho[dia.letra]; salvarRascunho();
      pararDescanso();
      S.wdSel = null;
      toast('Treino ' + dia.letra + ' salvo. Volume: ' + fmt(vol) + ' kg');
      render();
    } catch (e) { toast('Não consegui salvar o treino. Tente de novo.'); }
  }

  /* Cronômetro de descanso */
  function iniciarDescanso(seg) {
    pararDescanso();
    S.descanso = { fim: Date.now() + seg * 1000 };
    S.descanso.timer = setInterval(desenharDescanso, 250);
    desenharDescanso();
  }
  function pararDescanso() {
    if (S.descanso) clearInterval(S.descanso.timer);
    S.descanso = null;
    const el = document.getElementById('rest'); if (el) el.remove();
  }
  function desenharDescanso() {
    if (!S.descanso) return;
    const rest = Math.max(0, Math.ceil((S.descanso.fim - Date.now()) / 1000));
    let el = document.getElementById('rest');
    if (!el) { el = document.createElement('div'); el.id = 'rest'; el.className = 'rest'; document.body.appendChild(el); }
    if (rest === 0) {
      el.innerHTML = '<div class="in" role="status"><span class="t">0:00</span><span class="grow" style="font-weight:700">Descanso acabou. Próxima série!</span><button class="btn sm" data-act="desc-fim">Ok</button></div>';
      clearInterval(S.descanso.timer);
      if (navigator.vibrate) { try { navigator.vibrate([200, 100, 200]); } catch (e) { /* sem vibração */ } }
      return;
    }
    el.innerHTML = '<div class="in" role="timer"><span class="t num">' + Math.floor(rest / 60) + ':' + String(rest % 60).padStart(2, '0') + '</span><span class="grow" style="font-weight:700">Descansando</span><button class="btn sm" data-act="desc-mais">+15 s</button><button class="btn sm" data-act="desc-fim">Pular</button></div>';
  }

  function abrirTrocaEx(k, exId) {
    const alts = F.alternativas(exId, S.perfil.resp.equip, S.perfil.resp.estilo);
    let h = '<div class="sheet-bg" data-act="fechar-sheet"><div class="sheet stack" role="dialog" aria-modal="true" aria-label="Trocar exercício"><div class="row between"><h3>Trocar ' + esc(F.EX_BY_ID[exId].nome) + '</h3><button class="btn sm" data-act="fechar-sheet">Fechar</button></div>';
    if (!alts.length) h += '<p class="muted">Não há outro exercício deste grupo para o seu equipamento.</p>';
    alts.forEach(function (e) {
      h += '<button class="alt" data-act="escolher-ex" data-k="' + k + '" data-ex="' + e.id + '">' + imgs(e.id) + '<span><b>' + esc(e.nome) + '</b><br><span class="small muted">' + esc(e.dica) + '</span></span></button>';
    });
    h += '</div></div>';
    $layer.innerHTML = h;
  }

  // Número da máquina no card do exercício (toque para editar)
  function linhaMaquina(it) {
    if (S.maqEdit === it.chave) {
      return '<div class="row" style="gap:6px;margin:2px 0"><input id="maq-in" aria-label="Número da máquina" maxlength="30" value="' + esc(maquinaDe(it)) + '" placeholder="ex.: 4 ou 5" style="max-width:130px"><button class="btn sm primary" data-act="maq-salvar" data-ex="' + it.ex + '">Salvar</button><button class="btn sm ghost" data-act="maq-cancelar" aria-label="Cancelar">×</button></div>';
    }
    const m = maquinaDe(it);
    return '<button class="maq' + (m ? ' on' : '') + '" data-act="maq-editar" data-k="' + it.chave + '" aria-label="' + (m ? 'Máquina ' + esc(m) + ', toque para editar' : 'Adicionar número da máquina') + '">' + (m ? 'Máquina ' + esc(m) : '+ nº da máquina') + '</button>';
  }

  /* ---------- Fichas da academia ---------- */
  function renderFichas() {
    const fs = S.perfil.fichas || [];
    let h = '<div class="card stack"><div class="row between"><h3>Ficha da academia</h3>' + (fs.length ? '<label class="row small" style="gap:6px"><input type="checkbox" data-act="fichas-usar"' + (S.perfil.usarFichas ? ' checked' : '') + '> Usar no treino</label>' : '') + '</div>';
    if (!fs.length) h += '<p class="small muted" style="margin:0">Treina com a ficha impressa da academia? Tire uma foto do ticket e o app monta o treino com os números das máquinas.</p>';
    fs.forEach(function (f) {
      h += '<div class="row between"><div><b>Treino ' + esc(f.letra) + '</b> <span class="small muted">' + esc(f.nome) + ' · ' + f.itens.length + ' exercícios' + (f.validade ? ' · até ' + esc(f.validade) : '') + '</span></div><button class="btn sm ghost" data-act="ficha-del" data-id="' + esc(f.id) + '">Apagar</button></div>';
    });
    if (fs.length && !S.perfil.usarFichas) h += '<p class="small muted" style="margin:0">Desligado: o treino mostrado é o montado pelo app.</p>';
    h += '<button class="btn block" data-act="ficha-foto">Importar ficha (foto do ticket)</button><input type="file" id="ficha-in" accept="image/*" capture="environment" hidden>';
    const faltam = FICHAS_PRONTAS.filter(function (p) { return !fs.some(function (f) { return f.id.split('_')[0] === p.id; }); });
    if (faltam.length) h += '<div class="small muted">Fichas de 17/11 já digitadas:</div><div class="row" style="flex-wrap:wrap;gap:6px">' + faltam.map(function (p) { return '<button class="btn sm" data-act="ficha-pronta" data-id="' + p.id + '">+ ' + esc(p.nome.replace(' adaptativo', '')) + '</button>'; }).join('') + '</div>';
    h += renderImportFicha();
    h += '</div>';
    return h;
  }
  function renderImportFicha() {
    const a = S.fichaImp;
    if (!a) return '';
    if (a.estado === 'carregando') return '<div class="card">Lendo o ticket… pode levar até um minuto.</div>';
    if (a.estado === 'erro') return '<div class="card warnbox stack" style="white-space:pre-line">' + esc(a.erro) + '<div class="row"><button class="btn" data-act="ficha-repetir">Tentar de novo</button><button class="btn ghost" data-act="ficha-fechar">Fechar</button></div></div>';
    const r = a.res;
    if (!r.legivel) return '<div class="card warnbox stack">Não consegui ler uma ficha nessa foto. Tire a foto de perto, reta e com boa luz.<div class="row"><button class="btn" data-act="ficha-foto">Tirar outra foto</button><button class="btn ghost" data-act="ficha-fechar">Fechar</button></div></div>';
    const cat = F.EX.slice().sort(function (x, y) { return x.nome.localeCompare(y.nome, 'pt-BR'); });
    let h = '<div class="card stack" style="border-color:var(--ember)"><h3>Confira a ficha lida</h3>';
    h += '<label class="small stack" style="gap:4px">Nome<input id="fi-nome" maxlength="60" value="' + esc(r.treino || 'Ficha da academia') + '"></label>';
    r.exercicios.forEach(function (e, i) {
      h += '<div class="stack" style="gap:4px;border-top:1px solid var(--line);padding-top:8px"><div class="small"><b>' + (i + 1) + '. ' + esc(e.nomeFicha) + '</b></div>' +
        '<select id="fi-ex-' + i + '" aria-label="Exercício do app para ' + esc(e.nomeFicha) + '"><option value="">— não incluir —</option>' + cat.map(function (c) { return '<option value="' + c.id + '"' + (c.id === e.ex ? ' selected' : '') + '>' + esc(c.nome) + '</option>'; }).join('') + '</select>' +
        '<div class="row" style="gap:6px"><input id="fi-maq-' + i + '" aria-label="Máquina" placeholder="Máquina" maxlength="30" value="' + esc(e.maquina) + '" style="flex:2;min-width:0"><input id="fi-ser-' + i + '" aria-label="Séries" type="number" min="1" max="8" value="' + e.series + '" style="flex:1;min-width:0"><input id="fi-rep-' + i + '" aria-label="Repetições" maxlength="12" value="' + esc(e.reps) + '" style="flex:1.4;min-width:0"><input id="fi-int-' + i + '" aria-label="Descanso em segundos" type="number" min="0" max="600" value="' + e.descanso + '" style="flex:1;min-width:0"></div>' +
        (e.ex ? '' : '<div class="small" style="color:var(--ember)">Escolha o exercício correspondente.</div>') + '</div>';
    });
    h += '<div class="small muted">Campos: máquina · séries · repetições · descanso (s).</div>';
    if ((S.perfil.fichas || []).length) h += '<label class="row small" style="gap:6px"><input type="checkbox" id="fi-subst" checked> Substituir a ficha atual (desmarque se você alterna entre as duas)</label>';
    h += '<div class="row"><button class="btn primary grow" data-act="ficha-salvar">Salvar ficha</button><button class="btn ghost" data-act="ficha-fechar">Cancelar</button></div>';
    h += '<p class="note">Leitura feita por IA: confira os números antes de salvar.</p></div>';
    return h;
  }
  async function lerFicha(arquivo) {
    S.ultimaFicha = arquivo;
    S.fichaImp = { estado: 'carregando' }; render();
    try {
      const cat = F.EX.map(function (e) { return { id: e.id, nome: e.nome }; });
      S.fichaImp = { estado: 'ok', res: await X.importarFicha(arquivo, cat) };
    } catch (e) { S.fichaImp = { estado: 'erro', erro: e.message || String(e) }; }
    render();
  }

  /* ---------- Foto do aparelho ---------- */
  function renderAparelho(letra) {
    const a = S.aparelho;
    if (!a) return '';
    if (a.estado === 'carregando') return '<div class="card">Identificando o aparelho… pode levar até um minuto.</div>';
    if (a.estado === 'erro') return '<div class="card warnbox stack" style="white-space:pre-line">' + esc(a.erro) + '<div class="row"><button class="btn" data-act="aparelho-repetir">Tentar de novo</button><button class="btn ghost" data-act="aparelho-fechar">Fechar</button></div></div>';
    const r = a.res;
    if (!r.reconhecido) return '<div class="card warnbox stack">Não consegui identificar um aparelho nessa foto.' + (r.dica ? ' ' + esc(r.dica) : '') + '<div class="row"><button class="btn" data-act="foto-aparelho">Tirar outra foto</button><button class="btn ghost" data-act="aparelho-fechar">Fechar</button></div></div>';
    const lista = function (t, l, num) { return l.length ? '<div><b>' + t + '</b>' + (num ? '<ol style="margin:4px 0 0;padding-left:20px">' : '<ul style="margin:4px 0 0;padding-left:20px">') + l.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + (num ? '</ol>' : '</ul>') + '</div>' : ''; };
    let h = '<div class="card stack" style="border-color:var(--ember)"><div class="row between"><h3>' + esc(r.aparelho) + '</h3><button class="btn sm ghost" data-act="aparelho-fechar">Fechar</button></div>';
    if (r.exercicio_id) h += imgs(r.exercicio_id, true);
    if (r.musculos.length) h += '<div class="small"><b>Trabalha:</b> ' + r.musculos.map(esc).join(', ') + '</div>';
    h += lista('Como ajustar', r.ajustes, false) + lista('Como fazer', r.execucao, true) + lista('Erros comuns', r.erros, false);
    if (r.seguranca) h += '<div class="small" style="color:var(--warn)"><b>Cuidado:</b> ' + esc(r.seguranca) + '</div>';
    const ids = (r.exercicio_id ? [r.exercicio_id] : []).concat(r.outros_ids);
    if (ids.length) {
      h += '<div class="stack" style="gap:6px"><b>Adicionar ao treino ' + letra + '</b>' + ids.map(function (id) {
        const e = F.EX_BY_ID[id];
        return e ? '<button class="btn" data-act="add-escolher" data-ex="' + id + '">+ ' + esc(e.nome) + '</button>' : '';
      }).join('') + '</div>';
    }
    h += '<p class="note">Orientação gerada por IA a partir da foto. Comece com carga leve e, na dúvida, peça ajuda ao professor da academia.</p></div>';
    return h;
  }
  async function analisarAparelho(arquivo) {
    S.ultimoAparelho = arquivo;
    S.aparelho = { estado: 'carregando' }; render();
    try {
      const cat = F.EX.filter(function (e) { return e.eq === 'gym' || e.eq === 'db'; }).map(function (e) { return { id: e.id, nome: e.nome }; });
      S.aparelho = { estado: 'ok', res: await X.identificarAparelho(arquivo, cat) };
    } catch (e) { S.aparelho = { estado: 'erro', erro: e.message || String(e) }; }
    render();
  }

  function abrirAdicionarEx() {
    const r = S.perfil.resp, g = S.addGrupo || 'peito';
    let h = '<div class="sheet-bg" data-act="fechar-sheet"><div class="sheet stack" role="dialog" aria-modal="true" aria-label="Adicionar exercício"><div class="row between"><h3>Adicionar exercício</h3><button class="btn sm" data-act="fechar-sheet">Fechar</button></div>';
    h += '<div class="chips">' + Object.keys(F.GRUPOS).map(function (k) { return '<button class="chip' + (k === g ? ' on' : '') + '" data-act="add-grupo" data-v="' + k + '">' + esc(F.GRUPOS[k]) + '</button>'; }).join('') + '</div>';
    F.doGrupo(g, r.equip, r.estilo).forEach(function (e) {
      h += '<button class="alt" data-act="add-escolher" data-ex="' + e.id + '">' + imgs(e.id) + '<span><b>' + esc(e.nome) + '</b>' + (e.maq ? ' <span class="small" style="color:var(--ember)">máquina/polia</span>' : '') + '<br><span class="small muted">' + esc(e.dica) + '</span></span></button>';
    });
    h += '</div></div>';
    $layer.innerHTML = h;
  }

  /* ---------- Dieta ---------- */
  /* ---------- Diário alimentar com foto do prato ---------- */
  const X = window.ForjaExtras;
  function diarioHoje() { S.perfil.diario = S.perfil.diario || {}; return S.perfil.diario[hojeISO()] || []; }
  function renderDiario(m) {
    const itens = diarioHoje();
    const t = X.totalItens(itens.map(function (e) { return e.total; }));
    const pct = function (a, b) { return b ? Math.min(100, Math.round(a / b * 100)) : 0; };
    const resta = m.kcal - t.kcal;
    let h = '<div class="card stack"><div class="row between"><h3>Diário de hoje</h3><span class="small muted num">' + fmt(t.kcal) + ' de ' + fmt(m.kcal) + ' kcal</span></div>';
    h += '<div class="bar"><i style="width:' + pct(t.kcal, m.kcal) + '%' + (t.kcal > m.kcal ? ';background:var(--warn)' : '') + '"></i></div>';
    h += '<div class="small ' + (resta < 0 ? '' : 'muted') + ' num" style="' + (resta < 0 ? 'color:var(--warn)' : '') + '">' + (resta >= 0 ? 'Faltam ' + fmt(resta) + ' kcal' : 'Passou ' + fmt(-resta) + ' kcal da meta') + ' · P ' + fmt(t.p) + '/' + fmt(m.p) + ' g · C ' + fmt(t.c) + '/' + fmt(m.c) + ' g · G ' + fmt(t.g) + '/' + fmt(m.g) + ' g</div>';
    const cardioHoje = (S.perfil.cardio || []).filter(function (x) { return x.d.slice(0, 10) === hojeISO(); }).reduce(function (a, x) { return a + x.kcal; }, 0);
    if (cardioHoje) h += '<div class="small muted num">Cardio hoje: ≈ ' + fmt(cardioHoje) + ' kcal gastas (não somadas à meta; os treinos já entram no cálculo do gasto diário)</div>';
    h += '<div class="row wrap"><button class="btn primary grow" data-act="foto">Foto do prato</button><button class="btn grow" data-act="galeria">Escolher da galeria</button><button class="btn grow" data-act="descrever">Descrever</button></div>';
    h += '<input type="file" id="foto-in" accept="image/*" capture="environment" hidden><input type="file" id="galeria-in" accept="image/*" hidden>';
    if (S.descrever) h += '<label class="f" for="desc-txt">' + (S.refAlvo ? 'O que você comeu no ' + esc(nomeRef(S.refAlvo)) + '?' : 'O que você comeu?') + ' Inclua quantidades se souber<textarea class="in" id="desc-txt" rows="3" placeholder="2 conchas de arroz, 1 concha de feijão, 1 filé de frango grelhado e salada">' + esc(S.descTxt || '') + '</textarea></label><button class="btn" data-act="analisar-texto">Calcular</button>';
    const a = S.analise;
    if (a && a.estado === 'carregando') h += '<div class="card" style="background:var(--surface-2)">Analisando a refeição… pode levar até um minuto.</div>';
    if (a && a.estado === 'erro') h += '<div class="card warnbox stack" style="white-space:pre-line">' + esc(a.erro) + (S.ultimoPedido ? '<button class="btn" data-act="tentar-de-novo">Tentar de novo</button>' : '') + '</div>';
    if (a && a.estado === 'resultado') {
      const r = a.res, tt = X.totalItens(r.itens);
      h += '<div class="card stack" style="background:var(--surface-2)"><div class="row between"><b>' + esc(r.titulo) + '</b><span class="small muted">' + (r.confianca ? 'confiança ' + esc(r.confianca) : '') + '</span></div>';
      if (!r.itens.length) h += '<div class="small">' + esc(r.observacao || 'Não encontrei comida nessa imagem.') + '</div>';
      r.itens.forEach(function (i, k) {
        h += '<div class="food"><div><b>' + esc(i.nome) + '</b><div class="q num">' + fmt(i.kcal) + ' kcal · P ' + fmt(i.p, 1) + ' · C ' + fmt(i.c, 1) + ' · G ' + fmt(i.g, 1) + '</div></div><label class="row small muted" style="gap:4px"><input class="in num" style="width:76px;padding:6px" type="number" inputmode="numeric" data-res-g="' + k + '" value="' + i.gramas + '" aria-label="Gramas de ' + esc(i.nome) + '">g</label></div>';
      });
      if (r.itens.length) {
        h += '<div class="small num"><b>Total: ' + fmt(tt.kcal) + ' kcal</b> · P ' + fmt(tt.p) + ' g · C ' + fmt(tt.c) + ' g · G ' + fmt(tt.g) + ' g</div>';
        if (r.observacao) h += '<div class="note">' + esc(r.observacao) + '</div>';
        h += '<div class="note">Estimativa da IA. Ajuste as gramas se souber a quantidade certa: as calorias se recalculam.</div>';
      }
      if (r.itens.length) {
        const fx = refeicoesFechadasHoje(), n = Math.min(6, Math.max(3, Number(S.perfil.resp.refeicoes) || 4));
        const ops = dietaDoDia(hojeISO()).refeicoes.filter(function (x) { return fx.todas.indexOf(x.chave) < 0 || x.chave === S.refAlvo; });
        h += '<div class="small muted">Registrar como:</div><div class="chips">' + ops.map(function (x) { return '<button class="chip' + (S.refAlvo === x.chave ? ' on' : '') + '" data-act="ref-alvo" data-r="' + x.chave + '">' + esc(x.nome) + '</button>'; }).join('') + '<button class="chip' + (!S.refAlvo ? ' on' : '') + '" data-act="ref-alvo" data-r="">Extra</button></div>';
      }
      h += '<div class="row">' + (r.itens.length ? '<button class="btn primary grow" data-act="res-add">Adicionar ao diário</button>' : '') + '<button class="btn" data-act="res-descartar">Descartar</button></div></div>';
    }
    if (itens.length) {
      h += '<div class="hist">' + itens.map(function (e) {
        return '<div class="it"><div><b>' + esc(e.titulo) + '</b> <span class="small muted">' + esc(e.hora) + (e.refeicao ? ' · ' + esc(nomeRef(e.refeicao)) : '') + '</span><div class="small muted num">' + fmt(e.total.kcal) + ' kcal · ' + e.itens.map(function (i) { return esc(i.nome) + ' ' + i.gramas + ' g'; }).join(', ') + '</div></div><button class="btn sm ghost" data-act="diario-del" data-id="' + esc(e.id) + '" aria-label="Apagar ' + esc(e.titulo) + '">Apagar</button></div>';
      }).join('') + '</div>';
    } else if (!a) h += '<p class="small muted" style="margin:0">Tire uma foto do prato ou descreva o que comeu. A IA estima as calorias e soma no seu dia.</p>';
    h += '</div>';
    return h;
  }
  function nomeRef(chave) { return (F.REF[chave] || {}).nome || chave; }
  async function analisarRefeicao(arquivo, nota) {
    S.ultimoPedido = { arquivo: arquivo, nota: nota }; // para o botão Tentar de novo
    S.analise = { estado: 'carregando' }; render();
    try {
      const r = await X.analisar(arquivo, nota);
      S.analise = { estado: 'resultado', res: r };
    } catch (e) { S.analise = { estado: 'erro', erro: e.message || String(e) }; }
    render();
  }
  async function adicionarAoDiario() {
    const r = S.analise.res, d = hojeISO(), agora = new Date();
    S.perfil.diario = S.perfil.diario || {};
    const lista = S.perfil.diario[d] || [];
    lista.push({ id: Date.now().toString(36), hora: String(agora.getHours()).padStart(2, '0') + ':' + String(agora.getMinutes()).padStart(2, '0'), titulo: r.titulo, refeicao: S.refAlvo || undefined, itens: r.itens.map(function (i) { return { nome: i.nome, gramas: i.gramas }; }), total: X.totalItens(r.itens) });
    S.perfil.diario[d] = lista;
    // Guarda só os últimos 45 dias
    const corte = new Date(Date.now() - 45 * 864e5).toISOString().slice(0, 10);
    Object.keys(S.perfil.diario).forEach(function (k) { if (k < corte) delete S.perfil.diario[k]; });
    S.analise = null; S.descrever = false; S.descTxt = ''; S.refAlvo = '';
    await Store.savePerfil(S.perfil);
    render(); toast('Refeição adicionada ao diário');
  }

  /* Dia do cardápio: hoje + 6 dias à frente. O número do dia faz o cardápio girar. */
  function dataMais(n) { const d = new Date(Date.now() + n * 864e5); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); }
  function numeroDia(iso) { return Math.floor(Date.parse(iso + 'T12:00:00Z') / 864e5); }
  const DIAS_SEM = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  function refeicoesFechadasHoje() {
    const d = hojeISO();
    const feitas = diarioHoje().filter(function (e) { return e.refeicao; }).map(function (e) { return e.refeicao; });
    const pulas = ((S.perfil.pulas || {})[d]) || [];
    return { feitas: feitas, pulas: pulas, todas: feitas.concat(pulas) };
  }
  function dietaDoDia(iso) {
    const trocas = ((S.perfil.trocasDia || {})[iso]) || {};
    if (iso !== hojeISO()) return F.montarDieta(S.perfil.resp, trocas, { rot: numeroDia(iso) });
    const fx = refeicoesFechadasHoje();
    const cons = X.totalItens(diarioHoje().map(function (e) { return e.total; }));
    return F.montarDieta(S.perfil.resp, trocas, { rot: numeroDia(iso), consumido: cons, fechadas: fx.todas });
  }
  function podarDatas(obj) {
    const corte = dataMais(-45);
    Object.keys(obj || {}).forEach(function (k) { if (k < corte) delete obj[k]; });
  }

  function renderDieta() {
    const off = S.diaDieta || 0, iso = dataMais(off), ehHoje = off === 0;
    const d = dietaDoDia(iso);
    const m = d.metas, t = d.total;
    const pct = function (a, b) { return b ? Math.min(100, Math.round(a / b * 100)) : 0; };
    let h = '<div class="stack">' + renderDiario(m);
    // Escolha do dia
    h += '<div class="days" role="tablist">' + [0, 1, 2, 3, 4, 5, 6].map(function (n) {
      const di = dataMais(n), dt = new Date(di + 'T12:00:00');
      return '<button class="day' + (n === off ? ' on' : '') + '" data-act="dia-dieta" data-n="' + n + '" role="tab" aria-selected="' + (n === off) + '"><div class="next">' + (n === 0 ? 'Hoje' : n === 1 ? 'Amanhã' : '&nbsp;') + '</div><b>' + dt.getDate() + '</b><span>' + DIAS_SEM[dt.getDay()] + '</span></button>';
    }).join('') + '</div>';
    h += '<div class="card stack"><h3>Cardápio ' + (ehHoje ? 'de hoje' : 'de ' + dataBR(iso).slice(0, 5)) + '</h3><div class="row between"><div><div class="small muted">Meta diária</div><div class="kcal num">' + fmt(m.kcal) + '<span style="font-size:20px"> kcal</span></div></div><div style="text-align:right" class="small muted num">' + (d.resto ? 'Falta para fechar o dia:<br><b style="color:var(--text)">' + fmt(d.resto.kcal) + ' kcal</b>' : 'Cardápio abaixo:<br>' + fmt(t.kcal) + ' kcal') + '</div></div>';
    if (d.resto) h += '<div class="small muted">As refeições que faltam foram recalculadas para fechar a meta com o que você já comeu e pulou.</div>';
    else h += '<div class="mac">' + [['Proteína', t.p, m.p], ['Carboidrato', t.c, m.c], ['Gordura', t.g, m.g]].map(function (x) {
      return '<div><div class="small muted">' + x[0] + '</div><div class="v num">' + fmt(x[1]) + '<span class="muted" style="font-size:14px"> / ' + fmt(x[2]) + ' g</span></div><div class="bar"><i style="width:' + pct(x[1], x[2]) + '%"></i></div></div>';
    }).join('') + '</div>';
    if (m.noPiso) h += '<div class="card warnbox">A meta ficou no piso de segurança (sua taxa basal ou ' + (S.perfil.resp.sexo === 'M' ? '1.500' : '1.200') + ' kcal). O Forja não sugere menos que isso.</div>';
    h += '<details class="calc"><summary>Como esse número foi calculado</summary><table class="num"><tbody>' +
      '<tr><td>Taxa metabólica basal (Mifflin-St Jeor)</td><td>' + fmt(m.tmb) + ' kcal</td></tr>' +
      '<tr><td>Fator de atividade (dia a dia + 0,03 por treino na semana)</td><td>× ' + fmt(m.fator, 3) + '</td></tr>' +
      '<tr><td>Gasto diário estimado</td><td>' + fmt(m.get) + ' kcal</td></tr>' +
      '<tr><td>Ajuste do objetivo (' + esc(m.tipoAjuste) + ')</td><td>' + (m.ajuste > 0 ? '+' : '') + fmt(m.ajuste * 100) + '%</td></tr>' +
      (m.ajusteCheckin ? '<tr><td>Ajuste dos check-ins semanais</td><td>' + (m.ajusteCheckin > 0 ? '+' : '') + m.ajusteCheckin + ' kcal</td></tr>' : '') +
      '<tr><td>' + (m.manual ? 'Meta definida por você' : 'Meta (arredondada)') + '</td><td>' + fmt(m.kcal) + ' kcal</td></tr>' +
      '<tr><td>Proteína: ' + fmt(m.gpk, 1) + ' g por kg</td><td>' + fmt(m.p) + ' g</td></tr>' +
      '<tr><td>Gordura: 0,8 g/kg (mínimo 20% das kcal)</td><td>' + fmt(m.g) + ' g</td></tr>' +
      '<tr><td>Carboidrato: o que sobra das kcal</td><td>' + fmt(m.c) + ' g</td></tr></tbody></table>' +
      '<form class="row" data-form="meta-manual" style="margin-top:8px"><label class="f grow" for="meta-in">Definir minha meta (kcal)' + (m.manual ? '' : ' — deixe vazio para usar o cálculo') + '<input class="in num" id="meta-in" type="number" inputmode="numeric" min="1000" max="6000" step="10" value="' + (S.perfil.resp.kcalManual || '') + '" placeholder="' + fmt(m.kcal) + '"></label><button class="btn" type="submit" style="align-self:flex-end">Salvar</button></form>' +
      (m.manual ? '<button class="btn sm ghost" data-act="meta-auto" style="margin-top:6px">Voltar ao cálculo automático</button>' : '') +
      '<p class="note">Use a meta manual se um nutricionista passou um valor para você.</p></details></div>';
    const fx = ehHoje ? refeicoesFechadasHoje() : { feitas: [], pulas: [] };
    d.refeicoes.forEach(function (r) {
      const feita = fx.feitas.indexOf(r.chave) >= 0, pulada = fx.pulas.indexOf(r.chave) >= 0;
      h += '<div class="card"' + (feita || pulada ? ' style="opacity:.75"' : '') + '><div class="row between" style="margin-bottom:6px"><h3>' + esc(r.nome) + '</h3>';
      if (feita) {
        const e = diarioHoje().filter(function (x) { return x.refeicao === r.chave; });
        const k = X.totalItens(e.map(function (x) { return x.total; })).kcal;
        h += '<span class="pill down num">Feita · ' + fmt(k) + ' kcal</span></div><div class="small muted">' + e.map(function (x) { return esc(x.titulo); }).join(', ') + '</div><button class="btn sm ghost" data-act="ref-desfazer" data-r="' + r.chave + '" style="margin-top:6px">Desfazer</button></div>';
        return;
      }
      if (pulada) {
        h += '<span class="pill up">Pulada</span></div><div class="small muted">As calorias dela foram divididas entre as próximas refeições.</div><button class="btn sm ghost" data-act="ref-despular" data-r="' + r.chave + '" style="margin-top:6px">Desfazer</button></div>';
        return;
      }
      h += '<span class="small muted num">' + fmt(r.total.kcal) + ' kcal · P ' + fmt(r.total.p) + ' · C ' + fmt(r.total.c) + ' · G ' + fmt(r.total.g) + '</span></div>';
      r.itens.forEach(function (i) {
        const chave = r.chave + '.' + i.papel;
        h += '<div class="food"><div><b>' + esc(F.ALIM[i.id].nome) + '</b><div class="q num">' + esc(F.porcao(i.id, i.gramas)) + '</div></div><div class="k num">' + fmt(i.macros.kcal) + ' kcal' + (i.opcoes.length > 1 ? '<br><button class="btn sm ghost" data-act="troca-dieta" data-c="' + chave + '" style="margin-top:4px">Trocar</button>' : '') + '</div>';
        if (S.trocaDieta === chave) {
          h += '<div class="swap">' + i.opcoes.map(function (o) { return '<button class="chip' + (o === i.id ? ' on' : '') + '" data-act="escolher-alim" data-c="' + chave + '" data-v="' + o + '">' + esc(F.ALIM[o].nome) + '</button>'; }).join('') + '</div>';
        }
        h += '</div>';
      });
      if (ehHoje) h += '<div class="row wrap" style="margin-top:8px"><button class="btn sm grow" data-act="ref-comi" data-r="' + r.chave + '">Comi isto</button><button class="btn sm grow" data-act="ref-outra" data-r="' + r.chave + '">Comi outra coisa</button><button class="btn sm ghost" data-act="ref-pular" data-r="' + r.chave + '">Pular</button></div>';
      h += '</div>';
    });
    h += '<p class="note">O cardápio muda a cada dia. Valores aproximados por 100 g com base na Tabela TACO (UNICAMP); whey pela média de rótulos. Confira o rótulo dos seus produtos. Conteúdo educativo: não substitui um nutricionista.</p></div>';
    $view.innerHTML = h;
  }

  async function registrarRefeicaoDoPlano(chave) {
    const d = dietaDoDia(hojeISO()), r = d.refeicoes.find(function (x) { return x.chave === chave; });
    if (!r) return;
    const agora = new Date(), dia = hojeISO();
    S.perfil.diario = S.perfil.diario || {};
    S.perfil.diario[dia] = (S.perfil.diario[dia] || []).concat([{ id: Date.now().toString(36), hora: String(agora.getHours()).padStart(2, '0') + ':' + String(agora.getMinutes()).padStart(2, '0'), titulo: r.nome + ' (cardápio)', refeicao: chave, itens: r.itens.map(function (i) { return { nome: F.ALIM[i.id].nome, gramas: i.gramas }; }), total: r.total }]);
    await Store.savePerfil(S.perfil); render(); toast(r.nome + ' registrado · +10 XP');
  }

  /* ---------- Progresso ---------- */
  function graficoPeso(pesos) {
    const pts = pesos.slice(-60);
    if (pts.length < 2) return '<p class="muted small">Registre o peso em dias diferentes para ver o gráfico.</p>';
    const W = 340, H = 150, pl = 34, pr = 12, pt = 12, pb = 24;
    const kgs = pts.map(function (p) { return p.kg; });
    let min = Math.min.apply(null, kgs), max = Math.max.apply(null, kgs);
    if (max - min < 2) { min -= 1; max += 1; }
    min = Math.floor(min); max = Math.ceil(max);
    const x = function (i) { return pl + (W - pl - pr) * (i / (pts.length - 1)); };
    const y = function (v) { return pt + (H - pt - pb) * (1 - (v - min) / (max - min)); };
    const linha = pts.map(function (p, i) { return (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(p.kg).toFixed(1); }).join(' ');
    const area = linha + ' L' + x(pts.length - 1).toFixed(1) + ' ' + (H - pb) + ' L' + x(0).toFixed(1) + ' ' + (H - pb) + ' Z';
    const ult = pts[pts.length - 1];
    let g = '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Peso de ' + fmt(pts[0].kg, 1) + ' a ' + fmt(ult.kg, 1) + ' kg">';
    [min, (min + max) / 2, max].forEach(function (v) { g += '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + y(v) + '" y2="' + y(v) + '" stroke="#31363F" stroke-width="1"/><text x="' + (pl - 6) + '" y="' + (y(v) + 4) + '" fill="#9AA1AD" font-size="11" text-anchor="end">' + fmt(v, v % 1 ? 1 : 0) + '</text>'; });
    g += '<path d="' + area + '" fill="#FF6B2C" fill-opacity=".12"/><path d="' + linha + '" fill="none" stroke="#FF6B2C" stroke-width="2.5" stroke-linejoin="round"/>';
    g += '<circle cx="' + x(pts.length - 1) + '" cy="' + y(ult.kg) + '" r="4.5" fill="#FF6B2C"/>';
    g += '<text x="' + pl + '" y="' + (H - 6) + '" fill="#9AA1AD" font-size="11">' + dataBR(pts[0].d).slice(0, 5) + '</text><text x="' + (W - pr) + '" y="' + (H - 6) + '" fill="#9AA1AD" font-size="11" text-anchor="end">' + dataBR(ult.d).slice(0, 5) + '</text></svg>';
    return g;
  }
  function renderProgresso() {
    const pesos = S.perfil.pesos || [];
    const ini = pesos[0], atual = pesos[pesos.length - 1];
    const dif = ini && atual ? atual.kg - ini.kg : 0;
    let h = '<div class="stack">' + renderXP() + '<div class="card stack"><div class="row between"><div><div class="small muted">Peso atual</div><div class="big num">' + (atual ? fmt(atual.kg, 1) : '–') + ' <span style="font-size:18px">kg</span></div></div>' +
      (pesos.length > 1 ? '<span class="pill ' + (dif <= 0 ? 'down' : 'up') + ' num">' + (dif > 0 ? '+' : '') + fmt(dif, 1) + ' kg desde ' + dataBR(ini.d).slice(0, 5) + '</span>' : '') + '</div>' + graficoPeso(pesos) +
      '<form class="row" data-form="peso"><label class="f grow" for="in-peso-hoje">Peso de hoje (kg)<input class="in num" id="in-peso-hoje" type="number" inputmode="decimal" step="0.1" min="35" max="250"></label><button class="btn primary" type="submit" style="align-self:flex-end">Registrar</button></form><div class="err" id="peso-err"></div></div>';
    h += renderCheckin();
    const cds = (S.perfil.cardio || []).slice(-10).reverse();
    if (cds.length) h += '<div class="card"><h3 style="margin-bottom:6px">Cardio recente</h3><div class="hist">' + cds.map(function (c) { return '<div class="it"><div>' + esc(M.CARDIO_BY_ID[c.mod] ? M.CARDIO_BY_ID[c.mod].nome : c.mod) + '<div class="small muted num">' + dataBR(c.d.slice(0, 10)) + '</div></div><div class="num">' + c.min + ' min · ≈ ' + fmt(c.kcal) + ' kcal</div></div>'; }).join('') + '</div></div>';
    // Recordes por exercício (maior carga)
    const rec = {};
    S.logs.slice().reverse().forEach(function (l) { (l.itens || []).forEach(function (it) { it.series.forEach(function (s) { if (!rec[it.ex] || s.kg > rec[it.ex].kg) rec[it.ex] = { kg: s.kg, reps: s.reps, data: l.data }; }); }); });
    const recs = Object.keys(rec).filter(function (k) { return rec[k].kg > 0; });
    const semana = S.logs.filter(function (l) { return Date.now() - new Date(l.data).getTime() < 7 * 864e5; }).length;
    h += '<div class="card"><div class="row between"><h3>Treinos</h3><span class="small muted num">' + semana + ' nos últimos 7 dias · ' + S.logs.length + ' no total</span></div>';
    if (!S.logs.length) h += '<p class="muted small">Quando você finalizar um treino, ele aparece aqui.</p>';
    h += '<div class="hist">' + S.logs.slice(0, 30).map(function (l) {
      const ns = l.itens.reduce(function (a, i) { return a + i.series.length; }, 0);
      return '<div class="it"><div><b>Treino ' + esc(l.letra) + '</b> <span class="muted small">' + esc(l.nome) + '</span><div class="small muted num">' + dataBR(l.data.slice(0, 10)) + ' · ' + ns + ' séries · ' + fmt(l.volume) + ' kg de volume</div></div><button class="btn sm ghost" data-act="del-log" data-id="' + esc(l.id) + '" aria-label="Apagar treino de ' + dataBR(l.data.slice(0, 10)) + '">Apagar</button></div>';
    }).join('') + '</div></div>';
    if (recs.length) {
      h += '<div class="card"><h3 style="margin-bottom:6px">Recordes de carga</h3><div class="hist">' + recs.map(function (k) {
        return '<div class="it"><div>' + esc(F.EX_BY_ID[k] ? F.EX_BY_ID[k].nome : k) + '<div class="small muted num">' + dataBR(rec[k].data.slice(0, 10)) + '</div></div><div class="num" style="font-weight:700">' + fmt(rec[k].kg, 1) + ' kg × ' + rec[k].reps + '</div></div>';
      }).join('') + '</div></div>';
    }
    h += '</div>';
    $view.innerHTML = h;
  }


  /* ---------- Cardio ---------- */
  const M = window.ForjaMais;
  S.cardio = ls.get('forja.cardio.atual') || { mod: 'caminhada_rapida', inicio: null, acumulado: 0 };
  function cardioSegundos() { const c = S.cardio; return Math.floor((c.acumulado || 0) + (c.inicio ? (Date.now() - c.inicio) / 1000 : 0)); }
  function salvarCardioAtual() { ls.set('forja.cardio.atual', S.cardio); }
  function fmtTempo(seg) { return Math.floor(seg / 60) + ':' + String(seg % 60).padStart(2, '0'); }
  function renderCardio() {
    const c = S.cardio, seg = cardioSegundos(), peso = Number(S.perfil.resp.peso);
    let h = '<div class="card stack"><div class="row between"><h3>Cardio</h3><span class="small muted">calorias estimadas</span></div>';
    h += '<div class="chips">' + M.CARDIO.map(function (m) { return '<button class="chip' + (c.mod === m.id ? ' on' : '') + '" data-act="cardio-mod" data-v="' + m.id + '"' + (c.inicio || c.acumulado ? ' disabled' : '') + '>' + esc(m.nome) + '</button>'; }).join('') + '</div>';
    h += '<div class="cardio-t num" id="cardio-t">' + fmtTempo(seg) + '</div><div class="small muted num" style="text-align:center" id="cardio-k">≈ ' + fmt(M.kcalCardio(c.mod, peso, seg / 60)) + ' kcal</div>';
    h += '<div class="row">';
    if (c.inicio) h += '<button class="btn grow" data-act="cardio-pausar">Pausar</button>';
    else h += '<button class="btn primary grow" data-act="cardio-iniciar">' + (c.acumulado ? 'Continuar' : 'Iniciar') + '</button>';
    if (seg > 0) h += '<button class="btn grow" data-act="cardio-salvar">Concluir</button><button class="btn" data-act="cardio-cancelar">Zerar</button>';
    h += '</div>';
    h += '<form class="row" data-form="cardio-manual"><label class="f grow" for="cardio-min">Ou registre os minutos que já fez<input class="in num" id="cardio-min" type="number" inputmode="numeric" min="1" max="300"></label><button class="btn" type="submit" style="align-self:flex-end">Registrar</button></form>';
    const hoje = (S.perfil.cardio || []).filter(function (x) { return x.d.slice(0, 10) === hojeISO(); });
    if (hoje.length) h += '<div class="small muted num">Hoje: ' + hoje.reduce(function (a, x) { return a + x.min; }, 0) + ' min · ≈ ' + fmt(hoje.reduce(function (a, x) { return a + x.kcal; }, 0)) + ' kcal</div>';
    h += '<p class="note">Estimativa por MET (Compêndio de Atividades Físicas) × seu peso × tempo. Varia com o ritmo.</p></div>';
    return h;
  }
  setInterval(function () {
    const t = document.getElementById('cardio-t');
    if (!t || !S.cardio.inicio) return;
    const seg = cardioSegundos();
    t.textContent = fmtTempo(seg);
    const k = document.getElementById('cardio-k');
    if (k) k.textContent = '≈ ' + fmt(M.kcalCardio(S.cardio.mod, Number(S.perfil.resp.peso), seg / 60)) + ' kcal';
  }, 1000);
  async function registrarCardio(min) {
    const m = Math.round(min);
    if (m < 1) return;
    S.perfil.cardio = (S.perfil.cardio || []).concat([{ id: Date.now().toString(36), d: new Date().toISOString(), mod: S.cardio.mod, min: m, kcal: Math.round(M.kcalCardio(S.cardio.mod, Number(S.perfil.resp.peso), m)) }]).slice(-300);
    S.cardio = { mod: S.cardio.mod, inicio: null, acumulado: 0 }; salvarCardioAtual();
    await Store.savePerfil(S.perfil);
    render(); toast('Cardio salvo: ' + m + ' min · +' + Math.min(120, 2 * m) + ' XP');
  }

  /* ---------- XP, liga e conquistas (topo da aba Progresso) ---------- */
  function renderXP() {
    const x = M.resumoXP(S.perfil, S.logs), n = x.nivel, lg = x.liga;
    const pct = Math.round((x.total - n.base) / (n.proximo - n.base) * 100);
    let h = '<div class="card stack"><div class="row between"><div><div class="small muted">Nível</div><div class="big num">' + n.nivel + '</div></div><div style="text-align:right"><div class="small muted">Liga da semana</div><div class="big" style="color:var(--ember)">' + lg.nome + '</div></div></div>';
    h += '<div class="bar"><i style="width:' + pct + '%"></i></div><div class="small muted num">' + fmt(x.total) + ' XP · faltam ' + fmt(n.proximo - x.total) + ' para o nível ' + (n.nivel + 1) + ' · ' + fmt(x.semana) + ' XP nos últimos 7 dias' + (lg.prox ? ' (' + lg.prox[0] + ' com ' + fmt(lg.prox[1]) + ')' : '') + '</div>';
    h += '<details class="calc"><summary>Conquistas (' + x.conquistas.filter(function (c) { return c.ok; }).length + ' de ' + x.conquistas.length + ')</summary><div class="conq" style="margin-top:8px">' + x.conquistas.map(function (c) {
      return '<div class="' + (c.ok ? 'on' : 'off') + '"><b>' + (c.ok ? '★ ' : '☆ ') + esc(c.nome) + '</b><br><span class="muted">' + esc(c.como) + '</span></div>';
    }).join('') + '</div><p class="note">XP: treino 100 + 5 por série · cardio 2 por minuto · refeição 10 · peso 10 por dia · check-in 50.</p></details></div>';
    return h;
  }

  /* ---------- Check-in semanal ---------- */
  function renderCheckin() {
    const mt = F.metas(S.perfil.resp);
    const sg = M.sugerirCheckin(S.perfil, mt.tipoAjuste, mt.noPiso);
    let h = '<div class="card stack"><div class="row between"><h3>Check-in semanal</h3>' + (mt.ajusteCheckin ? '<span class="small muted num">ajuste atual ' + (mt.ajusteCheckin > 0 ? '+' : '') + mt.ajusteCheckin + ' kcal</span>' : '') + '</div>';
    if (!sg.pode) h += '<p class="small muted" style="margin:0">' + esc(sg.motivo) + '</p>';
    else {
      h += '<div class="small num">Média desta semana: <b>' + fmt(sg.mediaAtual, 1) + ' kg</b> · semana anterior: ' + fmt(sg.mediaAntes, 1) + ' kg</div><p class="small" style="margin:0">' + esc(sg.texto) + '</p>';
      h += '<button class="btn primary" data-act="checkin" data-delta="' + sg.delta + '" data-pct="' + sg.pct.toFixed(3) + '" data-media="' + sg.mediaAtual.toFixed(2) + '">' + (sg.delta ? 'Aplicar ' + (sg.delta > 0 ? '+' : '') + sg.delta + ' kcal e concluir' : 'Concluir check-in') + '</button>';
      if (sg.delta) h += '<button class="btn" data-act="checkin" data-delta="0" data-pct="' + sg.pct.toFixed(3) + '" data-media="' + sg.mediaAtual.toFixed(2) + '">Concluir sem mudar as calorias</button>';
    }
    if (mt.ajusteCheckin) h += '<button class="btn sm ghost" data-act="checkin-zerar" style="align-self:flex-start">Desfazer ajustes de calorias</button>';
    h += '</div>';
    return h;
  }

  /* ---------- Treinador (chat) ---------- */
  S.chat = ls.get('forja.chat') || [];
  function contextoTreinador() {
    const r = S.perfil.resp, mt = F.metas(r), pl = plano(), prox = pl[proximoDia(pl)];
    const hoje = diarioHoje();
    return {
      perfil: { sexo: r.sexo, idade: r.idade, altura_cm: r.altura, peso_kg: r.peso, objetivos: F.listaObjetivos(r), nivel: r.nivel, treinos_por_semana: r.dias, minutos_por_treino: r.tempo, equipamento: rotulo('equip', r.equip), metodo: r.metodo },
      metas_dia: { kcal: mt.kcal, proteina_g: mt.p, carbo_g: mt.c, gordura_g: mt.g },
      hoje: { data: hojeISO(), kcal_consumidas: Math.round(X.totalItens(hoje.map(function (e) { return e.total; })).kcal), refeicoes: hoje.map(function (e) { return e.titulo; }) },
      proximo_treino: { nome: prox.nome, exercicios: prox.itens.map(function (i) { return F.EX_BY_ID[i.ex].nome + ' ' + i.series + 'x' + i.reps; }) },
      ultimos_treinos: S.logs.slice(0, 5).map(function (l) { return { data: l.data.slice(0, 10), treino: l.nome, series: l.itens.reduce(function (a, i) { return a + i.series.length; }, 0), volume_kg: l.volume }; }),
      pesos_recentes: (S.perfil.pesos || []).slice(-8),
      cardio_recente: (S.perfil.cardio || []).slice(-5).map(function (c) { return { data: c.d.slice(0, 10), tipo: M.CARDIO_BY_ID[c.mod] ? M.CARDIO_BY_ID[c.mod].nome : c.mod, min: c.min }; })
    };
  }
  function renderCoach() {
    let h = '<div class="stack"><div class="card stack"><div class="row between"><h3>Treinador</h3>' + (S.chat.length ? '<button class="btn sm ghost" data-act="chat-limpar">Limpar conversa</button>' : '') + '</div>';
    h += '<p class="small muted" style="margin:0">Pergunte sobre treino, cargas, alimentação ou sua semana. O treinador vê seu plano, metas, diário e últimos treinos. Não substitui médico ou nutricionista.</p></div>';
    h += '<div class="chat">' + S.chat.map(function (m) { return '<div class="msg ' + (m.role === 'user' ? 'eu' : 'ia') + '">' + esc(m.content) + '</div>'; }).join('');
    if (S.chatEstado === 'pensando') h += '<div class="msg ia muted">Pensando…</div>';
    if (S.chatErro) h += '<div class="card warnbox stack" style="white-space:pre-line">' + esc(S.chatErro) + (S.chatUltima ? '<button class="btn" data-act="chat-repetir">Tentar de novo</button>' : '') + '</div>';
    h += '</div>';
    if (!S.chat.length) h += '<div class="chips">' + ['Analise minha semana', 'O que comer antes do treino?', 'Como aumentar a carga com segurança?', 'Monte um lanche com 30 g de proteína'].map(function (q) { return '<button class="chip" data-act="chat-sug" data-v="' + esc(q) + '">' + esc(q) + '</button>'; }).join('') + '</div>';
    h += '<form class="stack" data-form="chat"><label class="f" for="chat-in">Sua mensagem<textarea class="in" id="chat-in" rows="2" placeholder="Escreva ou use o microfone do teclado"></textarea></label><button class="btn primary" type="submit"' + (S.chatEstado === 'pensando' ? ' disabled' : '') + '>Enviar</button></form></div>';
    $view.innerHTML = h;
    window.scrollTo(0, document.body.scrollHeight);
  }
  async function enviarChat(texto) {
    const t = String(texto || '').trim();
    if (!t || S.chatEstado === 'pensando') return;
    S.chat.push({ role: 'user', content: t.slice(0, 2000) });
    S.chatEstado = 'pensando'; S.chatErro = ''; render();
    try {
      const r = await X.conversar(S.chat, contextoTreinador());
      S.chat.push({ role: 'assistant', content: String(r || '').trim() || '(sem resposta)' });
      S.chatUltima = '';
    } catch (e) { S.chat.pop(); S.chatUltima = t; S.chatErro = e.message || 'Não consegui responder agora.'; }
    S.chat = S.chat.slice(-40); ls.set('forja.chat', S.chat);
    S.chatEstado = ''; render();
  }

  /* ---------- Perfil ---------- */
  function rotulo(c, v) {
    if (LIM_NUM[c]) return fmt(v, c === 'peso' ? 1 : 0);
    if (MULTI[c]) return (v || []).map(function (x) { const o = OPC[c].find(function (y) { return y[0] === x; }); return o ? o[1] : x; }).join(' + ');
    const o = (OPC[c] || []).find(function (x) { return String(x[0]) === String(v); });
    return o ? o[1] + (c === 'dias' ? ' por semana' : c === 'refeicoes' ? ' por dia' : '') : v;
  }
  function renderPerfil() {
    const r = S.perfil.resp;
    let h = '<div class="stack"><div class="card"><h3 style="margin-bottom:6px">Suas respostas</h3><div class="hist">' + ['sexo', 'idade', 'altura', 'peso', 'objetivos', 'nivel', 'dias', 'diasSemana', 'tempo', 'divisao', 'metodo', 'estilo', 'equip', 'trabalho', 'refeicoes'].map(function (c) {
      return '<div class="it"><span class="muted">' + ROT[c] + '</span><b class="num">' + esc(rotulo(c, c === 'diasSemana' ? (r.diasSemana || diasPadrao(Number(r.dias))) : r[c])) + '</b></div>';
    }).join('') + '</div><button class="btn block" data-act="refazer" style="margin-top:12px">Refazer questionário</button><p class="note">Seu histórico de treinos e de peso é mantido.</p></div>';
    h += '<div class="card stack"><h3>Onde seus dados ficam</h3><p class="small muted" style="margin:0">' + (Store.modo === 'db' ? 'Salvos na sua conta Claude, numa área privada deste app. Você acessa de qualquer aparelho em que estiver logado.' : (window.Capacitor ? 'Salvos neste celular. Faça um backup de vez em quando e guarde em um lugar seguro.' : 'Salvos só neste navegador. Abra o app logado na sua conta Claude para guardar na nuvem.')) + '</p></div>';
    h += '<div class="card stack"><h3>Backup</h3><p class="small muted" style="margin:0">Use para levar seus dados entre a versão web e o app no celular.</p><button class="btn" data-act="bk-copiar">Copiar backup</button><label class="f" for="bk-txt">Restaurar: cole aqui o backup<textarea class="in" id="bk-txt" rows="3" style="font-size:13px"></textarea></label><div class="err" id="bk-err"></div><button class="btn" data-act="bk-restaurar">Restaurar backup</button></div>';
    h += '<div class="card stack"><h3>Inteligência artificial (foto do prato)</h3>';
    if (X.ehAndroid()) {
      const g = X.ChaveGemini.get(), c = X.Chave.get();
      h += '<p class="small muted" style="margin:0">Cadastre pelo menos uma chave. O app tenta na ordem Gemini → GitHub → Claude: se um falhar ou estiver sobrecarregado, passa para o próximo. As chaves ficam só neste celular: não vão para o backup.</p>';
      h += '<div class="stack" style="gap:6px"><b>Gemini (grátis)</b>' + (g ? '<div class="row"><span class="grow small">Chave cadastrada: ••••' + esc(g.slice(-4)) + '</span><button class="btn sm" data-act="ia-remover" data-q="gemini">Remover</button></div>'
        : '<label class="f" for="ia-gemini">Chave do Google AI Studio (começa com AQ. ou AIza)<input class="in" id="ia-gemini" type="password" autocomplete="off" placeholder="AQ.Ab..."></label><button class="btn" data-act="ia-salvar" data-q="gemini">Salvar chave do Gemini</button><p class="note">Crie em aistudio.google.com → Get API key. Na faixa grátis o Google pode usar as fotos para melhorar os produtos dele.</p>') + '</div>';
      const gh = X.ChaveGitHub.get();
      h += '<div class="stack" style="gap:6px"><b>GitHub Models (grátis, reserva)</b>' + (gh ? '<div class="row"><span class="grow small">Token cadastrado: ••••' + esc(gh.slice(-4)) + '</span><button class="btn sm" data-act="ia-remover" data-q="github">Remover</button></div>'
        : '<label class="f" for="ia-github">Token do GitHub (começa com github_pat_)<input class="in" id="ia-github" type="password" autocomplete="off" placeholder="github_pat_..."></label><button class="btn" data-act="ia-salvar" data-q="github">Salvar token do GitHub</button><p class="note">Crie em github.com → Settings → Developer settings → Fine-grained tokens, só com a permissão Models (leitura).</p>') + '</div>';
      h += '<div class="stack" style="gap:6px"><b>Claude (pago)</b>' + (c ? '<div class="row"><span class="grow small">Chave cadastrada: ••••' + esc(c.slice(-4)) + '</span><button class="btn sm" data-act="ia-remover" data-q="claude">Remover</button></div>'
        : '<label class="f" for="ia-chave">Chave de API (começa com sk-ant-)<input class="in" id="ia-chave" type="password" autocomplete="off" placeholder="sk-ant-..."></label><button class="btn" data-act="ia-salvar" data-q="claude">Salvar chave do Claude</button><p class="note">Crie em platform.claude.com → API Keys. Precisa de créditos pré-pagos.</p>') + '</div>';
      h += '<div class="err" id="ia-err"></div>';
    } else {
      h += '<p class="small muted" style="margin:0">Nesta versão web, a IA usa a sua conta Claude: não precisa de chave. Na primeira foto, o Claude pede sua autorização.</p>';
    }
    h += '</div>';
    if (X.ehAndroid()) {
      const u = S.atualizacao;
      h += '<div class="card stack"><div class="row between"><h3>Atualização do app</h3><span class="small muted num">versão ' + X.VERSAO_WEB + '</span></div>';
      if (u && u.temNova) h += '<div class="small"><b>Versão ' + u.nova + ' disponível.</b>' + (u.novidades.length ? '<br>' + u.novidades.map(esc).join('<br>') : '') + '</div><button class="btn primary" data-act="upd-instalar">Atualizar agora</button><p class="note">Seus dados ficam guardados. O app reinicia sozinho no final.</p>';
      else h += '<div class="small muted">' + (u ? (u.erro ? esc(u.erro) : 'Você está na versão mais recente.') : 'Toque para ver se há novidades.') + '</div><button class="btn" data-act="upd-procurar">Procurar atualização</button>';
      h += '</div>';
    }
    h += '<div class="card stack"><h3>Registro por voz</h3><p class="small muted" style="margin:0">Em Dieta → Descrever e no Treinador, toque no microfone do teclado do celular e fale. O texto entra no campo e a IA calcula.</p></div>';
    h += '<p class="note">Forja · criado por Elenilton Siqueira · (11) 94335-8761<br>Uso pessoal e educativo. Não substitui médico, nutricionista ou profissional de educação física. Imagens de exercícios: Free Exercise DB (domínio público).</p></div>';
    $view.innerHTML = h;
  }

  /* ---------- Widget (só no APK Android) ---------- */
  let ultimoWidget = '';
  function atualizarWidget() {
    const cap = window.Capacitor;
    if (!cap || !cap.nativePromise || !cap.getPlatform || cap.getPlatform() !== 'android' || !S.perfil) return;
    try {
      const pl = plano(), d = pl[proximoDia(pl)], m = F.metas(S.perfil.resp);
      const semana = S.logs.filter(function (l) { return Date.now() - new Date(l.data).getTime() < 7 * 864e5; }).length;
      const rd = S.rascunho[d.letra] || {};
      const sTotal = d.itens.reduce(function (a, it) { return a + ((rd._pulados || {})[it.chave] ? 0 : it.series); }, 0);
      const sFeitas = d.itens.reduce(function (a, it) { return a + ((rd[it.chave] || []).filter(function (x) { return x && x.ok; }).length); }, 0);
      const kHoje = Math.round(X.totalItens(diarioHoje().map(function (e) { return e.total; })).kcal);
      const xp = window.ForjaMais ? window.ForjaMais.resumoXP(S.perfil, S.logs) : null;
      const dados = JSON.stringify({
        letra: d.letra, nome: d.nome, exercicios: d.itens.length,
        seriesFeitas: sFeitas, seriesTotal: sTotal, kcalHoje: kHoje, kcalMeta: m.kcal,
        kcalTexto: fmt(kHoje) + ' de ' + fmt(m.kcal) + ' kcal hoje',
        liga: xp ? 'Nível ' + xp.nivel.nivel + ' · Liga ' + xp.liga.nome : '',
        kcal: fmt(m.kcal) + ' kcal', macros: 'P ' + m.p + ' g · C ' + m.c + ' g · G ' + m.g + ' g',
        semana: semana + (semana === 1 ? ' treino' : ' treinos') + ' nos últimos 7 dias'
      });
      if (dados === ultimoWidget) return;
      ultimoWidget = dados;
      cap.nativePromise('WidgetBridge', 'update', { dados: dados }).catch(function () { /* widget opcional */ });
    } catch (e) { /* widget opcional */ }
  }

  /* Botões do widget: Treino, Foto do prato e Peso abrem o app na tela certa */
  async function acaoDoWidget() {
    const cap = window.Capacitor;
    if (!cap || !cap.nativePromise || !X.ehAndroid() || !S.perfil) return;
    let a = '';
    try { a = ((await cap.nativePromise('WidgetBridge', 'acao', {})) || {}).acao || ''; } catch (e) { return; }
    if (!a) return;
    if (a === 'treino') { S.aba = 'treino'; S.wdSel = null; render(); window.scrollTo(0, 0); }
    else if (a === 'foto') {
      S.aba = 'dieta'; render(); window.scrollTo(0, 0);
      const f = document.getElementById('foto-in');
      try { if (f) f.click(); } catch (e) { /* se o Android bloquear, o botão Foto do prato está no topo */ }
    } else if (a === 'peso') {
      S.aba = 'progresso'; render();
      const i = document.getElementById('in-peso-hoje');
      if (i) { i.scrollIntoView({ block: 'center' }); try { i.focus(); } catch (e) { /* teclado abre ao tocar */ } }
    }
  }

  /* ---------- Backup (levar dados entre web e APK) ---------- */
  async function copiarBackup() {
    const txt = JSON.stringify({ forja: 1, perfil: S.perfil, treinos: S.logs });
    try { await navigator.clipboard.writeText(txt); toast('Backup copiado. Cole no outro aparelho.'); }
    catch (e) { const t = document.getElementById('bk-txt'); if (t) { t.value = txt; t.select(); } toast('Copie o texto que apareceu na caixa.'); }
  }
  async function restaurarBackup() {
    const t = document.getElementById('bk-txt'), err = document.getElementById('bk-err');
    let o;
    try { o = JSON.parse(t.value); } catch (e) { err.textContent = 'O texto colado não é um backup do Forja.'; return; }
    if (!o || o.forja !== 1 || !o.perfil || !o.perfil.resp) { err.textContent = 'O texto colado não é um backup do Forja.'; return; }
    S.perfil = o.perfil;
    S.perfil.trocasTreino = S.perfil.trocasTreino || {}; S.perfil.trocasDieta = S.perfil.trocasDieta || {}; S.perfil.pesos = S.perfil.pesos || [];
    await Store.savePerfil(S.perfil);
    const ids = {}; S.logs.forEach(function (l) { ids[l.id] = 1; });
    const novos = (o.treinos || []).filter(function (l) { return l && l.id && !ids[l.id]; });
    for (let i = 0; i < novos.length; i++) await Store.addLog(novos[i]);
    S.logs = S.logs.concat(novos).sort(function (a, b) { return a.data < b.data ? 1 : -1; });
    toast('Backup restaurado: ' + novos.length + ' treinos importados');
    render();
  }

  /* ---------- Render ---------- */
  function render() {
    $layer.innerHTML = $layer.innerHTML && S.sheetAberta ? $layer.innerHTML : '';
    if (!S.perfil || S.aba === 'onb') { $tag.textContent = 'Seu plano'; renderOnb(); return; }
    const r = S.perfil.resp;
    $tag.textContent = rotulo('objetivos', F.listaObjetivos(r)) + ' · ' + rotulo('dias', r.dias);
    if (S.aba === 'treino') renderTreino();
    else if (S.aba === 'dieta') renderDieta();
    else if (S.aba === 'progresso') renderProgresso();
    else if (S.aba === 'coach') renderCoach();
    else renderPerfil();
    renderNav();
    atualizarWidget();
  }

  /* ---------- Eventos ---------- */
  document.addEventListener('click', async function (ev) {
    const b = ev.target.closest('[data-act]');
    if (!b) return;
    const a = b.dataset.act;
    if (a === 'fechar-sheet' && ev.target !== b) return; // clique dentro da janela não fecha
    switch (a) {
      case 'aba': S.aba = b.dataset.aba; S.trocaDieta = null; window.scrollTo(0, 0); render(); break;
      case 'onb-opt': {
        lerNumeros();
        const c = b.dataset.campo, v = b.dataset.v;
        if (MULTI[c]) {
          const l = (S.onb.r[c] || []).slice(), i = l.indexOf(v);
          if (i >= 0) l.splice(i, 1); else l.push(v);
          S.onb.r[c] = l;
        } else S.onb.r[c] = v;
        if (c === 'dias' && (S.onb.r.diasSemana || []).length !== Number(v)) S.onb.r.diasSemana = diasPadrao(Number(v));
        renderOnb(); break;
      }
      case 'onb-voltar': lerNumeros(); S.onb.passo--; renderOnb(); break;
      case 'onb-cancelar': S.aba = 'perfil'; render(); break;
      case 'onb-seguir': {
        const e = validarPasso();
        if (e) { renderOnb(e); return; }
        if (S.onb.passo < PASSOS.length - 1) { S.onb.passo++; renderOnb(); window.scrollTo(0, 0); }
        else await concluirOnb();
        break;
      }
      case 'refazer': S.onb = { passo: 0, r: clone(S.perfil.resp) }; if (!S.onb.r.diasSemana) S.onb.r.diasSemana = diasPadrao(Number(S.onb.r.dias)); S.aba = 'onb'; render(); break;
      case 'dia-sem': S.wdSel = Number(b.dataset.w); render(); break;
      case 'serie': marcarSerie(b.dataset.k, Number(b.dataset.s), Number(b.dataset.d)); break;
      case 'como': S.abertas[b.dataset.k] = !S.abertas[b.dataset.k]; render(); break;
      case 'trocar-ex': S.sheetAberta = true; abrirTrocaEx(b.dataset.k, b.dataset.ex); break;
      case 'serie-mais':
      case 'serie-menos': {
        S.perfil.seriesAjuste = S.perfil.seriesAjuste || {};
        const k = b.dataset.a, d = a === 'serie-mais' ? 1 : -1;
        S.perfil.seriesAjuste[k] = Math.max(-4, Math.min(5, (S.perfil.seriesAjuste[k] || 0) + d));
        if (!S.perfil.seriesAjuste[k]) delete S.perfil.seriesAjuste[k];
        await Store.savePerfil(S.perfil); render(); break;
      }
      case 'add-ex': S.sheetAberta = true; abrirAdicionarEx(); break;
      case 'foto-aparelho': document.getElementById('aparelho-in').click(); break;
      case 'aparelho-fechar': S.aparelho = null; render(); break;
      case 'maq-editar': { S.maqEdit = b.dataset.k; render(); const i = document.getElementById('maq-in'); if (i) i.focus(); break; }
      case 'maq-cancelar': S.maqEdit = null; render(); break;
      case 'maq-salvar': {
        const v = (document.getElementById('maq-in').value || '').trim().slice(0, 30);
        S.perfil.maquinas = S.perfil.maquinas || {};
        S.perfil.maquinas[b.dataset.ex] = v;
        S.maqEdit = null; await Store.savePerfil(S.perfil); render(); toast(v ? 'Máquina ' + v + ' salva.' : 'Número da máquina apagado.'); break;
      }
      case 'ficha-foto': document.getElementById('ficha-in').click(); break;
      case 'ficha-repetir': if (S.ultimaFicha) lerFicha(S.ultimaFicha); break;
      case 'ficha-fechar': S.fichaImp = null; render(); break;
      case 'ficha-pronta': {
        const p = FICHAS_PRONTAS.find(function (x) { return x.id === b.dataset.id; });
        if (!p) break;
        await adicionarFicha({ id: p.id, letra: p.letra, nome: p.nome, validade: p.validade, itens: p.itens.map(function (x) { return { ex: x[0], nomeFicha: x[1], maquina: x[2], series: x[3], reps: x[4], descanso: 60 }; }) });
        render(); toast('Ficha adicionada. O treino agora segue a ficha da academia.'); break;
      }
      case 'ficha-salvar': {
        const r = S.fichaImp && S.fichaImp.res;
        if (!r) break;
        const itens = [];
        r.exercicios.forEach(function (e, i) {
          const ex = document.getElementById('fi-ex-' + i).value;
          if (!ex || !F.EX_BY_ID[ex]) return;
          const ser = Math.min(8, Math.max(1, Math.round(Number(document.getElementById('fi-ser-' + i).value) || 3)));
          const int = Math.min(600, Math.max(0, Math.round(Number(document.getElementById('fi-int-' + i).value) || 0)));
          itens.push({ ex: ex, nomeFicha: e.nomeFicha, maquina: (document.getElementById('fi-maq-' + i).value || '').trim().slice(0, 30), series: ser, reps: (document.getElementById('fi-rep-' + i).value || '').trim().slice(0, 12) || '10–12', descanso: int });
        });
        if (!itens.length) { toast('Escolha pelo menos um exercício.'); break; }
        const nome = (document.getElementById('fi-nome').value || '').trim().slice(0, 60) || 'Ficha da academia';
        const subst = document.getElementById('fi-subst');
        if (subst && subst.checked) S.perfil.fichas = [];
        await adicionarFicha({ id: 'imp', letra: nome, nome: nome, validade: r.validade, itens: itens });
        // Números lidos agora valem para os exercícios (atualiza os antigos)
        itens.forEach(function (x) { if (x.maquina) S.perfil.maquinas[x.ex] = x.maquina; });
        await Store.savePerfil(S.perfil);
        S.fichaImp = null;
        // Abre a ficha nova na tela, pronta para treinar hoje
        { const pl = plano(), ag = agenda(pl), idx = pl.length - 1, w = hojeWd();
          const a = ag.find(function (x) { return x.wd === w && x.idx === idx; }) || ag.find(function (x) { return x.idx === idx; }) || ag[0];
          S.wdSel = a.wd; }
        render(); window.scrollTo(0, 0); toast('Ficha salva com ' + itens.length + ' exercícios. Pode começar!'); break;
      }
      case 'ficha-del': {
        if (b.dataset.confirm !== '1') { b.dataset.confirm = '1'; b.textContent = 'Confirmar'; return; }
        S.perfil.fichas = (S.perfil.fichas || []).filter(function (f) { return f.id !== b.dataset.id; });
        if (!S.perfil.fichas.length) S.perfil.usarFichas = false;
        S.wdSel = null; await Store.savePerfil(S.perfil); render(); toast('Ficha apagada.'); break;
      }
      case 'aparelho-repetir': if (S.ultimoAparelho) await analisarAparelho(S.ultimoAparelho); break;
      case 'add-grupo': S.addGrupo = b.dataset.v; abrirAdicionarEx(); break;
      case 'add-escolher': {
        const letra = plano()[S.dia].letra;
        S.perfil.extrasTreino = S.perfil.extrasTreino || {};
        S.perfil.extrasTreino[letra] = (S.perfil.extrasTreino[letra] || []).concat([b.dataset.ex]).slice(0, 8);
        S.aparelho = null;
        S.sheetAberta = false; $layer.innerHTML = '';
        await Store.savePerfil(S.perfil); render(); toast('Exercício adicionado ao treino ' + letra);
        break;
      }
      case 'remover-ex': {
        const m = /^x([A-Z])_(\d+)$/.exec(b.dataset.k);
        if (!m) return;
        const l = (S.perfil.extrasTreino || {})[m[1]] || [];
        l.splice(Number(m[2]), 1);
        delete rascunhoDia(m[1])[b.dataset.k]; salvarRascunho();
        await Store.savePerfil(S.perfil); render(); toast('Exercício removido');
        break;
      }
      case 'escolher-ex': {
        const mx = /^x([A-Z])_(\d+)$/.exec(b.dataset.k);
        if (mx) {
          S.perfil.extrasTreino[mx[1]][Number(mx[2])] = b.dataset.ex;
          delete rascunhoDia(mx[1])[b.dataset.k]; salvarRascunho();
          S.sheetAberta = false; $layer.innerHTML = '';
          await Store.savePerfil(S.perfil); render(); toast('Exercício trocado');
          break;
        }
        S.perfil.trocasTreino[b.dataset.k] = b.dataset.ex;
        const pl = plano(); delete rascunhoDia(pl[S.dia].letra)[b.dataset.k]; salvarRascunho();
        S.sheetAberta = false; $layer.innerHTML = '';
        await Store.savePerfil(S.perfil); render(); toast('Exercício trocado');
        break;
      }
      case 'fechar-sheet': S.sheetAberta = false; $layer.innerHTML = ''; break;
      case 'finalizar': await finalizarTreino(); break;
      case 'bk-copiar': await copiarBackup(); break;
      case 'cardio-mod': S.cardio.mod = b.dataset.v; salvarCardioAtual(); render(); break;
      case 'cardio-iniciar': S.cardio.inicio = Date.now(); salvarCardioAtual(); render(); break;
      case 'cardio-pausar': S.cardio.acumulado = cardioSegundos(); S.cardio.inicio = null; salvarCardioAtual(); render(); break;
      case 'cardio-cancelar': S.cardio = { mod: S.cardio.mod, inicio: null, acumulado: 0 }; salvarCardioAtual(); render(); break;
      case 'cardio-salvar': {
        const seg = cardioSegundos();
        if (seg < 60) { toast('Faça pelo menos 1 minuto para salvar.'); return; }
        await registrarCardio(seg / 60); break;
      }
      case 'checkin': {
        const delta = Number(b.dataset.delta) || 0;
        S.perfil.checkins = (S.perfil.checkins || []).concat([{ d: hojeISO(), media: Number(b.dataset.media), pct: Number(b.dataset.pct), delta: delta }]).slice(-104);
        S.perfil.resp.ajusteKcal = Math.max(-500, Math.min(500, (Number(S.perfil.resp.ajusteKcal) || 0) + delta));
        await Store.savePerfil(S.perfil); render(); toast(delta ? 'Calorias ajustadas em ' + (delta > 0 ? '+' : '') + delta + ' kcal · +50 XP' : 'Check-in feito · +50 XP'); break;
      }
      case 'pular-ex': {
        const letra = plano()[S.dia].letra, rd = rascunhoDia(letra);
        rd._pulados = rd._pulados || {}; rd._pulados[b.dataset.k] = true; salvarRascunho();
        render(); toast('Exercício pulado hoje'); break;
      }
      case 'despular-ex': {
        const letra = plano()[S.dia].letra, rd = rascunhoDia(letra);
        if (rd._pulados) delete rd._pulados[b.dataset.k]; salvarRascunho(); render(); break;
      }
      case 'tirar-ex': {
        if (b.dataset.confirm !== '1') { b.dataset.confirm = '1'; b.textContent = 'Confirmar'; return; }
        const letra = plano()[S.dia].letra;
        S.perfil.removidosTreino = S.perfil.removidosTreino || {};
        S.perfil.removidosTreino[letra + ':' + b.dataset.k] = true;
        await Store.savePerfil(S.perfil); render(); toast('Exercício tirado do treino ' + letra + '. Dá para restaurar no fim da lista.'); break;
      }
      case 'restaurar-ex': {
        const letra = plano()[S.dia].letra;
        delete (S.perfil.removidosTreino || {})[letra + ':' + b.dataset.k];
        await Store.savePerfil(S.perfil); render(); toast('Exercício restaurado'); break;
      }
      case 'meta-auto': S.perfil.resp.kcalManual = 0; await Store.savePerfil(S.perfil); render(); toast('Voltou ao cálculo automático'); break;
      case 'descartar-treino': {
        if (b.dataset.confirm !== '1') { b.dataset.confirm = '1'; b.textContent = 'Toque de novo para confirmar'; return; }
        const letra = plano()[S.dia].letra;
        delete S.rascunho[letra]; salvarRascunho(); pararDescanso();
        render(); toast('Marcações do treino ' + letra + ' apagadas'); break;
      }
      case 'checkin-zerar': S.perfil.resp.ajusteKcal = 0; await Store.savePerfil(S.perfil); render(); toast('Ajustes desfeitos'); break;
      case 'chat-sug': await enviarChat(b.dataset.v); break;
      case 'chat-repetir': await enviarChat(S.chatUltima); break;
      case 'chat-limpar': S.chat = []; ls.set('forja.chat', []); S.chatErro = ''; render(); break;
      case 'bk-restaurar': await restaurarBackup(); break;
      case 'foto': document.getElementById('foto-in').click(); break;
      case 'galeria': document.getElementById('galeria-in').click(); break;
      case 'descrever': S.descrever = !S.descrever; if (!S.descrever) S.refAlvo = ''; render(); break;
      case 'analisar-texto': {
        const txt = (document.getElementById('desc-txt').value || '').trim();
        if (txt.length < 3) { toast('Escreva o que você comeu.'); return; }
        S.descTxt = txt; await analisarRefeicao(null, txt); break;
      }
      case 'res-add': await adicionarAoDiario(); break;
      case 'tentar-de-novo': if (S.ultimoPedido) await analisarRefeicao(S.ultimoPedido.arquivo, S.ultimoPedido.nota); break;
      case 'res-descartar': S.analise = null; render(); break;
      case 'diario-del': {
        if (b.dataset.confirm !== '1') { b.dataset.confirm = '1'; b.textContent = 'Confirmar'; return; }
        const d = hojeISO();
        S.perfil.diario[d] = (S.perfil.diario[d] || []).filter(function (e) { return e.id !== b.dataset.id; });
        await Store.savePerfil(S.perfil); render(); break;
      }
      case 'ia-salvar': {
        const q = b.dataset.q;
        const cfg = {
          gemini: ['ia-gemini', /^(AIza[0-9A-Za-z_-]{20,}|AQ\.[0-9A-Za-z._-]{20,})$/, 'A chave do Gemini começa com AQ. ou AIza. Confira se copiou inteira, sem espaços.', X.ChaveGemini],
          github: ['ia-github', /^(github_pat_[0-9A-Za-z_]{20,}|ghp_[0-9A-Za-z]{20,})$/, 'O token do GitHub começa com github_pat_. Confira se copiou inteiro, sem espaços.', X.ChaveGitHub],
          claude: ['ia-chave', /^sk-ant-/, 'A chave do Claude começa com sk-ant-.', X.Chave]
        }[q];
        const v = (document.getElementById(cfg[0]).value || '').trim();
        if (!cfg[1].test(v)) { document.getElementById('ia-err').textContent = cfg[2]; return; }
        cfg[3].set(v); render(); toast('Chave salva neste celular'); break;
      }
      case 'ia-remover': ({ gemini: X.ChaveGemini, github: X.ChaveGitHub, claude: X.Chave })[b.dataset.q].set(''); render(); break;
      case 'upd-procurar': {
        b.textContent = 'Procurando…';
        try { S.atualizacao = await X.procurarAtualizacao(); } catch (e) { S.atualizacao = { erro: e.message || 'Sem conexão.' }; }
        render(); break;
      }
      case 'upd-instalar': {
        b.textContent = 'Baixando…'; b.disabled = true;
        try { await X.instalarAtualizacao(S.atualizacao); } catch (e) { b.disabled = false; b.textContent = 'Atualizar agora'; toast(e.message || 'Não consegui atualizar.'); }
        break;
      }
      case 'desc-mais': if (S.descanso) { S.descanso.fim += 15000; desenharDescanso(); } break;
      case 'desc-fim': pararDescanso(); break;
      case 'dia-dieta': S.diaDieta = Number(b.dataset.n); S.trocaDieta = null; render(); break;
      case 'ref-comi': await registrarRefeicaoDoPlano(b.dataset.r); break;
      case 'ref-outra': S.refAlvo = b.dataset.r; S.descrever = true; render(); window.scrollTo(0, 0); { const t = document.getElementById('desc-txt'); if (t) t.focus(); } break;
      case 'ref-alvo': S.refAlvo = b.dataset.r; render(); break;
      case 'ref-pular': {
        const dia = hojeISO();
        S.perfil.pulas = S.perfil.pulas || {}; podarDatas(S.perfil.pulas);
        S.perfil.pulas[dia] = (S.perfil.pulas[dia] || []).concat([b.dataset.r]);
        await Store.savePerfil(S.perfil); render(); toast('Refeição pulada. O resto do dia foi recalculado.'); break;
      }
      case 'ref-despular': {
        const dia = hojeISO();
        S.perfil.pulas[dia] = (S.perfil.pulas[dia] || []).filter(function (x) { return x !== b.dataset.r; });
        await Store.savePerfil(S.perfil); render(); break;
      }
      case 'ref-desfazer': {
        const dia = hojeISO();
        S.perfil.diario[dia] = (S.perfil.diario[dia] || []).filter(function (e) { return e.refeicao !== b.dataset.r; });
        await Store.savePerfil(S.perfil); render(); break;
      }
      case 'troca-dieta': S.trocaDieta = S.trocaDieta === b.dataset.c ? null : b.dataset.c; render(); break;
      case 'escolher-alim': {
        const iso = dataMais(S.diaDieta || 0);
        S.perfil.trocasDia = S.perfil.trocasDia || {}; podarDatas(S.perfil.trocasDia);
        S.perfil.trocasDia[iso] = S.perfil.trocasDia[iso] || {};
        S.perfil.trocasDia[iso][b.dataset.c] = b.dataset.v;
        S.trocaDieta = null; render(); await Store.savePerfil(S.perfil); break;
      }
      case 'del-log': {
        if (b.dataset.confirm !== '1') { b.dataset.confirm = '1'; b.textContent = 'Confirmar'; return; }
        await Store.delLog(b.dataset.id);
        S.logs = S.logs.filter(function (l) { return l.id !== b.dataset.id; });
        render(); toast('Treino apagado');
        break;
      }
    }
  });
  // Foto escolhida: manda para a IA
  document.addEventListener('change', function (ev) {
    const i = ev.target;
    if ((i.id === 'foto-in' || i.id === 'galeria-in') && i.files && i.files[0]) analisarRefeicao(i.files[0], '');
    if (i.id === 'aparelho-in' && i.files && i.files[0]) analisarAparelho(i.files[0]);
    if (i.id === 'ficha-in' && i.files && i.files[0]) { lerFicha(i.files[0]); i.value = ''; }
    if (i.dataset && i.dataset.act === 'fichas-usar') { S.perfil.usarFichas = i.checked; S.wdSel = null; Store.savePerfil(S.perfil).then(render); }
  });
  // Gramas editadas no resultado: recalcula (redesenha ao sair do campo)
  document.addEventListener('focusout', function (ev) {
    const i = ev.target;
    if (!i.dataset || i.dataset.resG == null || !S.analise || !S.analise.res) return;
    const k = Number(i.dataset.resG), it = S.analise.res.itens[k];
    if (it && Number(i.value) !== it.gramas) { S.analise.res.itens[k] = X.ajustarGramas(it, i.value); render(); }
  });
  // Digitação nas séries vai para o rascunho (sem redesenhar a tela)
  document.addEventListener('input', function (ev) {
    const i = ev.target;
    if (!i.dataset || !i.dataset.set) return;
    const pl = plano(), rd = rascunhoDia(pl[S.dia].letra);
    rd[i.dataset.k] = rd[i.dataset.k] || [];
    const v = rd[i.dataset.k][Number(i.dataset.s)] || {};
    v[i.dataset.set] = i.value === '' ? null : Number(i.value);
    rd[i.dataset.k][Number(i.dataset.s)] = v;
    salvarRascunho();
  });
  document.addEventListener('submit', async function (ev) {
    if (ev.target.dataset.form === 'chat') {
      ev.preventDefault();
      const i = document.getElementById('chat-in');
      await enviarChat(i.value);
      return;
    }
    if (ev.target.dataset.form === 'meta-manual') {
      ev.preventDefault();
      const v = Number(document.getElementById('meta-in').value);
      if (!v) { S.perfil.resp.kcalManual = 0; }
      else if (v < 1000 || v > 6000) { toast('Digite uma meta entre 1.000 e 6.000 kcal.'); return; }
      else S.perfil.resp.kcalManual = v;
      await Store.savePerfil(S.perfil); render(); toast(v ? 'Meta definida: ' + fmt(F.metas(S.perfil.resp).kcal) + ' kcal' : 'Voltou ao cálculo automático');
      return;
    }
    if (ev.target.dataset.form === 'cardio-manual') {
      ev.preventDefault();
      const v = Number(document.getElementById('cardio-min').value);
      if (!v || v < 1 || v > 300) { toast('Digite entre 1 e 300 minutos.'); return; }
      await registrarCardio(v);
      return;
    }
    if (ev.target.dataset.form !== 'peso') return;
    ev.preventDefault();
    const inp = document.getElementById('in-peso-hoje');
    const kg = Number(String(inp.value).replace(',', '.'));
    if (!kg || kg < 35 || kg > 250) { document.getElementById('peso-err').textContent = 'Digite um peso entre 35 e 250 kg.'; return; }
    registrarPesoNoPerfil(S.perfil, kg);
    S.perfil.resp.peso = kg; // a dieta passa a usar o peso novo
    await Store.savePerfil(S.perfil);
    render(); toast('Peso registrado. Metas da dieta atualizadas.');
  });

  // Alterna as duas fotos de cada exercício, simulando o movimento
  if (!window.matchMedia || !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    setInterval(function () { document.body.classList.toggle('f1'); }, 1100);
  }

  /* ---------- Início ---------- */
  (async function iniciar() {
    await Store.init();
    try {
      S.perfil = await Store.getPerfil();
      if (S.perfil) S.logs = await Store.getLogs();
    } catch (e) {
      $view.innerHTML = '<div class="card">Não consegui carregar seus dados agora. Feche e abra o app de novo em instantes.</div>';
      return;
    }
    if (S.perfil) {
      S.perfil.trocasTreino = S.perfil.trocasTreino || {};
      S.perfil.trocasDieta = S.perfil.trocasDieta || {};
      S.perfil.pesos = S.perfil.pesos || [];
      S.perfil.resp.objetivos = F.listaObjetivos(S.perfil.resp);
      S.perfil.resp.divisao = S.perfil.resp.divisao || 'auto';
      S.perfil.resp.estilo = S.perfil.resp.estilo || 'misto';
      S.perfil.resp.metodo = S.perfil.resp.metodo || 'normal';
    }
    // Uma vez só: coloca a ficha da academia (masculina ou feminina, pelo sexo do perfil) direto na tela de treino
    if (S.perfil && !S.perfil.fichaAuto) {
      S.perfil.fichaAuto = true;
      const p = FICHAS_PRONTAS.find(function (x) { return x.id === (S.perfil.resp.sexo === 'F' ? 'f2' : 'm2'); });
      if (p && !(S.perfil.fichas || []).length) {
        await adicionarFicha({ id: p.id, letra: p.letra, nome: p.nome, validade: p.validade, itens: p.itens.map(function (x) { return { ex: x[0], nomeFicha: x[1], maquina: x[2], series: x[3], reps: x[4], descanso: 60 }; }) });
        S.aba = 'treino'; S.fichaAvisar = true;
      } else await Store.savePerfil(S.perfil);
    }
    render();
    if (S.fichaAvisar) toast('Ficha da academia (Treino 2) já está no seu treino, com os números das máquinas.');
    X.avisarPronto();
    acaoDoWidget();
    window.addEventListener('forja-acao', acaoDoWidget);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) acaoDoWidget(); });
    // Confere atualização uma vez ao abrir (só no app do celular, em silêncio)
    if (X.ehAndroid()) {
      X.procurarAtualizacao().then(function (u) {
        S.atualizacao = u;
        if (u.temNova) toast('Atualização disponível. Veja em Perfil.');
        if (S.aba === 'perfil') render();
      }).catch(function () { /* sem internet: tenta na próxima abertura */ });
    }
  })();
})();
