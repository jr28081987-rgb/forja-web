/* Forja — cardio, XP/ligas/conquistas e check-in semanal (cálculos puros, sem tela).
   Expõe window.ForjaMais (e module.exports para testes no Node). */
(function (root) {
  'use strict';

  /* ---------- Cardio ----------
     MET aproximados do Compêndio de Atividades Físicas (Ainsworth et al.).
     Calorias = MET × peso (kg) × horas. É uma estimativa: varia com ritmo e condicionamento. */
  const CARDIO = [
    ['caminhada', 'Caminhada leve (≈5 km/h)', 3.5],
    ['caminhada_rapida', 'Caminhada rápida (≈6,5 km/h)', 5.0],
    ['corrida_leve', 'Corrida leve (≈8 km/h)', 8.3],
    ['corrida', 'Corrida (≈10 km/h)', 9.8],
    ['bike', 'Bicicleta ergométrica moderada', 6.8],
    ['eliptico', 'Elíptico moderado', 5.0],
    ['escada', 'Escada / simulador de escada', 9.0],
    ['corda', 'Pular corda', 11.8]
  ].map(function (r) { return { id: r[0], nome: r[1], met: r[2] }; });
  const CARDIO_BY_ID = {};
  CARDIO.forEach(function (c) { CARDIO_BY_ID[c.id] = c; });

  function kcalCardio(modId, pesoKg, minutos) {
    const m = CARDIO_BY_ID[modId];
    if (!m) return 0;
    return m.met * Number(pesoKg) * (Number(minutos) / 60);
  }

  /* ---------- Datas ---------- */
  function dia(iso) { return String(iso).slice(0, 10); }
  function diasAtras(n) {
    const d = new Date(Date.now() - n * 864e5);
    return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10);
  }

  /* ---------- XP ----------
     Treino finalizado: 100 + 5 por série · Cardio: 2 por minuto (até 120 por sessão)
     Refeição registrada: 10 (até 60 por dia) · Peso registrado: 10 por dia · Check-in: 50 */
  function eventosXP(perfil, logs) {
    const ev = [];
    (logs || []).forEach(function (l) {
      const series = (l.itens || []).reduce(function (a, i) { return a + (i.series || []).length; }, 0);
      ev.push({ d: dia(l.data), xp: 100 + 5 * series, tipo: 'treino' });
    });
    (perfil.cardio || []).forEach(function (c) { ev.push({ d: dia(c.d), xp: Math.min(120, Math.round(2 * c.min)), tipo: 'cardio' }); });
    Object.keys(perfil.diario || {}).forEach(function (d) {
      ev.push({ d: d, xp: Math.min(60, 10 * (perfil.diario[d] || []).length), tipo: 'refeicao' });
    });
    (perfil.pesos || []).forEach(function (p) { ev.push({ d: p.d, xp: 10, tipo: 'peso' }); });
    (perfil.checkins || []).forEach(function (c) { ev.push({ d: c.d, xp: 50, tipo: 'checkin' }); });
    return ev;
  }
  // Nível: precisa de 50 × (nível − 1)² XP no total (1: 0, 2: 50, 3: 200, 4: 450, 5: 800…)
  function nivelDe(xp) {
    const n = Math.floor(Math.sqrt(xp / 50)) + 1;
    return { nivel: n, base: 50 * (n - 1) * (n - 1), proximo: 50 * n * n };
  }
  // Liga pelo XP dos últimos 7 dias
  const LIGAS = [['Diamante', 1200], ['Platina', 800], ['Ouro', 500], ['Prata', 250], ['Bronze', 0]];
  function ligaDe(xpSemana) {
    for (let i = 0; i < LIGAS.length; i++) if (xpSemana >= LIGAS[i][1]) return { nome: LIGAS[i][0], min: LIGAS[i][1], prox: i > 0 ? LIGAS[i - 1] : null };
    return { nome: 'Bronze', min: 0, prox: LIGAS[3] };
  }

  /* ---------- Conquistas ---------- */
  function conquistas(perfil, logs) {
    logs = logs || [];
    const semanaIni = diasAtras(6);
    const treinosSemana = logs.filter(function (l) { return dia(l.data) >= semanaIni; }).length;
    const refeicoes = Object.keys(perfil.diario || {}).reduce(function (a, d) { return a + (perfil.diario[d] || []).length; }, 0);
    const minCardio = (perfil.cardio || []).reduce(function (a, c) { return a + c.min; }, 0);
    // Recorde: algum exercício cuja maior carga subiu em relação a uma sessão anterior
    const porEx = {};
    logs.slice().reverse().forEach(function (l) {
      (l.itens || []).forEach(function (it) {
        const max = Math.max.apply(null, (it.series || []).map(function (s) { return Number(s.kg) || 0; }).concat([0]));
        (porEx[it.ex] = porEx[it.ex] || []).push(max);
      });
    });
    const recorde = Object.keys(porEx).some(function (k) {
      const a = porEx[k];
      for (let i = 1; i < a.length; i++) if (a[i] > Math.max.apply(null, a.slice(0, i)) && a[i] > 0) return true;
      return false;
    });
    return [
      ['Primeiro treino', 'Finalize 1 treino', logs.length >= 1],
      ['10 treinos', 'Finalize 10 treinos', logs.length >= 10],
      ['50 treinos', 'Finalize 50 treinos', logs.length >= 50],
      ['Semana completa', 'Faça todos os treinos da semana', treinosSemana >= (Number(perfil.resp && perfil.resp.dias) || 3)],
      ['Novo recorde', 'Aumente a carga máxima de um exercício', recorde],
      ['Diário em dia', 'Registre 20 refeições', refeicoes >= 20],
      ['1 hora de cardio', 'Some 60 minutos de cardio', minCardio >= 60],
      ['Balança fiel', 'Registre o peso em 7 dias', (perfil.pesos || []).length >= 7],
      ['Primeiro check-in', 'Faça o check-in semanal', (perfil.checkins || []).length >= 1]
    ].map(function (c) { return { nome: c[0], como: c[1], ok: !!c[2] }; });
  }

  function resumoXP(perfil, logs) {
    const ev = eventosXP(perfil, logs);
    const total = ev.reduce(function (a, e) { return a + e.xp; }, 0);
    const ini = diasAtras(6);
    const semana = ev.filter(function (e) { return e.d >= ini; }).reduce(function (a, e) { return a + e.xp; }, 0);
    return { total: total, semana: semana, nivel: nivelDe(total), liga: ligaDe(semana), conquistas: conquistas(perfil, logs) };
  }

  /* ---------- Check-in semanal ----------
     Compara a média do peso dos últimos 7 dias com a dos 7 dias anteriores.
     Faixa de variação semanal esperada (% do peso) por tipo de ajuste:
     emagrecer −1,0 a −0,5 · definir −0,75 a −0,25 · recomposição −0,5 a 0 · massa +0,1 a +0,5 · força 0 a +0,5.
     Fora da faixa, sugere ±100 kcal (limite acumulado de ±500 kcal). */
  const FAIXAS = { 'emagrecer': [-1.0, -0.5], 'definir': [-0.75, -0.25], 'recomposição corporal': [-0.5, 0.0], 'ganhar massa': [0.1, 0.5], 'força': [0.0, 0.5] };
  function media(lista) { return lista.reduce(function (a, p) { return a + p.kg; }, 0) / lista.length; }

  function sugerirCheckin(perfil, tipoAjuste, noPiso) {
    const ult = (perfil.checkins || []).slice(-1)[0];
    if (ult && ult.d > diasAtras(6)) return { pode: false, motivo: 'O próximo check-in libera em ' + proximoEm(ult.d) + '.' };
    const pesos = perfil.pesos || [];
    const atual = pesos.filter(function (p) { return p.d >= diasAtras(6); });
    const antes = pesos.filter(function (p) { return p.d >= diasAtras(13) && p.d < diasAtras(6); });
    if (atual.length < 2 || antes.length < 1) {
      return { pode: false, motivo: 'Registre o peso em pelo menos 2 dias desta semana e 1 dia da semana anterior. Pese-se de manhã, em jejum, depois de ir ao banheiro.' };
    }
    const mAtual = media(atual), mAntes = media(antes);
    const pct = (mAtual - mAntes) / mAntes * 100;
    const faixa = FAIXAS[tipoAjuste] || [-0.25, 0.25];
    let delta = 0;
    if (pct < faixa[0]) delta = 100;      // mudando rápido demais para baixo (ou ganhando devagar)
    else if (pct > faixa[1]) delta = -100; // subindo rápido demais (ou perdendo devagar)
    const acumulado = Number(perfil.resp && perfil.resp.ajusteKcal) || 0;
    if (acumulado + delta > 500 || acumulado + delta < -500) delta = 0;
    let texto;
    if (delta === 0) texto = 'Seu peso variou ' + fmtPct(pct) + ' na semana, dentro do esperado (' + fmtPct(faixa[0]) + ' a ' + fmtPct(faixa[1]) + '). Mantenha as calorias.';
    else texto = 'Seu peso variou ' + fmtPct(pct) + ' na semana; o esperado é de ' + fmtPct(faixa[0]) + ' a ' + fmtPct(faixa[1]) + '. Sugestão: ' + (delta > 0 ? 'aumentar' : 'reduzir') + ' 100 kcal por dia.';
    if (delta < 0 && noPiso) { delta = 0; texto += ' Mas sua meta já está no piso de segurança, então o Forja não reduz mais. Aumente o cardio ou revise o diário.'; }
    return { pode: true, mediaAtual: mAtual, mediaAntes: mAntes, pct: pct, faixa: faixa, delta: delta, texto: texto };
  }
  function fmtPct(v) { return (v > 0 ? '+' : '') + v.toFixed(2).replace('.', ',') + '%'; }
  function proximoEm(dIso) {
    const d = new Date(dIso + 'T12:00:00'); d.setDate(d.getDate() + 7);
    return String(d.getDate()).padStart(2, '0') + '/' + String(d.getMonth() + 1).padStart(2, '0');
  }

  const api = { CARDIO: CARDIO, CARDIO_BY_ID: CARDIO_BY_ID, kcalCardio: kcalCardio, resumoXP: resumoXP, nivelDe: nivelDe, ligaDe: ligaDe, sugerirCheckin: sugerirCheckin, diasAtras: diasAtras };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.ForjaMais = api;
})(typeof window !== 'undefined' ? window : globalThis);
