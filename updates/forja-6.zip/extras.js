/* Forja — foto do prato (IA), diário alimentar e atualização do app.
   Carregado depois de logic.js e antes de app.js. Expõe window.ForjaExtras. */
(function () {
  'use strict';

  /* Versão dos arquivos do app (telas e cálculos). Aumente a cada atualização publicada. */
  const VERSAO_WEB = 6;
  const URL_VERSAO = 'https://jr28081987-rgb.github.io/forja-web/version.json';
  const MODELO_API = 'claude-sonnet-5-5';
  // Gemini: tenta na ordem; se um modelo não existir ou estourar o limite grátis, passa ao próximo
  const MODELOS_GEMINI = ['gemini-flash-latest', 'gemini-2.5-flash', 'gemini-2.5-flash-lite'];

  const ehAndroid = function () {
    const c = window.Capacitor;
    return !!(c && c.getPlatform && c.getPlatform() === 'android' && c.nativePromise);
  };
  const nativo = function (plugin, metodo, opcoes) { return window.Capacitor.nativePromise(plugin, metodo, opcoes || {}); };

  /* ---------- Chave de API (só no celular; nunca vai para backup nem para o banco) ---------- */
  function guardado(nome) {
    return {
      get: function () { try { return localStorage.getItem(nome) || ''; } catch (e) { return ''; } },
      set: function (v) { try { if (v) localStorage.setItem(nome, v); else localStorage.removeItem(nome); } catch (e) { /* sem armazenamento */ } }
    };
  }
  const Chave = guardado('forja.apikey');          // Claude (pago)
  const ChaveGemini = guardado('forja.gemini');    // Gemini (faixa grátis)

  /* ---------- Imagem: reduz para no máximo 1024 px e converte em JPEG ---------- */
  function reduzirImagem(arquivo) {
    return new Promise(function (ok, erro) {
      const url = URL.createObjectURL(arquivo);
      const img = new Image();
      img.onload = function () {
        const max = 1024, esc = Math.min(1, max / Math.max(img.width, img.height));
        const cv = document.createElement('canvas');
        cv.width = Math.round(img.width * esc); cv.height = Math.round(img.height * esc);
        cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
        URL.revokeObjectURL(url);
        cv.toBlob(function (b) { b ? ok(b) : erro(new Error('Não consegui ler a foto.')); }, 'image/jpeg', 0.82);
      };
      img.onerror = function () { URL.revokeObjectURL(url); erro(new Error('Não consegui abrir essa imagem.')); };
      img.src = url;
    });
  }
  function blobParaBase64(blob) {
    return new Promise(function (ok, erro) {
      const r = new FileReader();
      r.onload = function () { ok(String(r.result).split(',')[1]); };
      r.onerror = function () { erro(new Error('Não consegui ler a foto.')); };
      r.readAsDataURL(blob);
    });
  }

  /* ---------- Pedido à IA ---------- */
  function instrucao(temFoto, nota) {
    return 'Você é um nutricionista brasileiro. ' +
      (temFoto ? 'Analise a foto do prato. Identifique cada alimento visível e estime a porção em gramas pelo tamanho no prato.' : 'Analise a descrição da refeição abaixo e estime a porção de cada alimento em gramas.') +
      (nota ? '\nInformação do usuário sobre a refeição: "' + nota.slice(0, 500) + '"' : '') +
      '\nUse como referência valores da Tabela TACO (alimentos preparados como aparecem). Seja realista: não arredonde tudo para valores redondos.' +
      '\nResponda SOMENTE com JSON, sem texto fora dele, neste formato:' +
      '\n{"titulo":"nome curto da refeição","itens":[{"nome":"Arroz branco cozido","gramas":150,"kcal":192,"p":3.8,"c":42.2,"g":0.3}],"confianca":"alta|media|baixa","observacao":"uma frase curta, por exemplo o que não deu para ver"}' +
      '\nSe a imagem não mostrar comida, responda {"itens":[],"observacao":"explique em uma frase"}.';
  }
  function lerJson(texto) {
    const t = String(texto || '').trim();
    try { return JSON.parse(t); } catch (e) { /* tenta extrair */ }
    const i = t.indexOf('{'), f = t.lastIndexOf('}');
    if (i >= 0 && f > i) return JSON.parse(t.slice(i, f + 1));
    throw new Error('A resposta da IA veio num formato inesperado. Tente de novo.');
  }
  // Normaliza e confere números (a IA pode mandar texto onde devia vir número)
  function normalizar(r) {
    const n = function (v) { const x = Number(String(v).replace(',', '.')); return isFinite(x) && x >= 0 ? x : 0; };
    const itens = (Array.isArray(r && r.itens) ? r.itens : []).slice(0, 15).map(function (i) {
      return { nome: String(i.nome || 'Alimento').slice(0, 60), gramas: Math.round(n(i.gramas)), kcal: n(i.kcal), p: n(i.p), c: n(i.c), g: n(i.g) };
    }).filter(function (i) { return i.gramas > 0 || i.kcal > 0; });
    return { titulo: String((r && r.titulo) || 'Refeição').slice(0, 60), itens: itens, confianca: String((r && r.confianca) || ''), observacao: String((r && r.observacao) || '').slice(0, 200) };
  }

  // Onde a IA roda: na versão web usa a conta Claude; no APK usa a chave de API do usuário
  async function provedor() {
    if (!ehAndroid() && typeof claude !== 'undefined' && claude.use) {
      const s = await claude.use('sample');
      if (s) return { tipo: 'conta', sample: s };
    }
    if (ChaveGemini.get()) return { tipo: 'gemini' };
    if (Chave.get()) return { tipo: 'chave' };
    return null;
  }
  async function disponivel() { try { return !!(await provedor()); } catch (e) { return false; } }

  async function analisar(arquivo, nota) {
    const pv = await provedor();
    if (!pv) throw new Error(ehAndroid() ? 'Para usar a IA no celular, cadastre uma chave em Perfil → Inteligência artificial (o Gemini é grátis).' : 'A IA não está disponível nesta tela.');
    const blob = arquivo ? await reduzirImagem(arquivo) : null;
    const prompt = instrucao(!!blob, nota);
    let texto;
    if (pv.tipo === 'conta') {
      try {
        const res = await pv.sample(prompt, blob ? { images: [blob], cache: false } : { cache: false });
        texto = res.text;
      } catch (e) {
        const msg = { not_granted: 'Você não autorizou o uso do Claude nesta página.', rate_limited: 'Muitos pedidos seguidos. Espere um pouco e tente de novo.', images_unavailable: 'Esta tela não consegue enviar fotos. Use a descrição em texto.', refused: 'A IA não conseguiu analisar essa imagem. Tente outra foto.' }[e && e.code];
        throw new Error(msg || 'Não consegui falar com a IA agora. Tente de novo em instantes.');
      }
    } else if (pv.tipo === 'gemini') {
      texto = await chamarGemini(blob, prompt);
    } else {
      const conteudo = [];
      if (blob) conteudo.push({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: await blobParaBase64(blob) } });
      conteudo.push({ type: 'text', text: prompt });
      let resp;
      try {
        resp = await fetch('https://api.anthropic.com/v1/messages', {
          method: 'POST',
          headers: { 'content-type': 'application/json', 'x-api-key': Chave.get(), 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
          body: JSON.stringify({ model: MODELO_API, max_tokens: 1200, messages: [{ role: 'user', content: conteudo }] })
        });
      } catch (e) { throw new Error('Sem conexão com a internet, ou a IA não respondeu.'); }
      if (resp.status === 401) throw new Error('Chave de API inválida. Confira em Perfil → Inteligência artificial.');
      if (resp.status === 429) throw new Error('Limite de uso da chave atingido. Espere um pouco ou confira seus créditos.');
      if (resp.status === 400) { const j = await resp.json().catch(function () { return {}; }); throw new Error('A IA recusou o pedido: ' + ((j.error && j.error.message) || 'verifique créditos e modelo') + '.'); }
      if (!resp.ok) throw new Error('A IA respondeu com erro ' + resp.status + '. Tente de novo.');
      const j = await resp.json();
      texto = (j.content || []).filter(function (c) { return c.type === 'text'; }).map(function (c) { return c.text; }).join('');
    }
    return normalizar(lerJson(texto));
  }

  async function chamarGemini(blob, prompt) {
    const partes = [];
    if (blob) partes.push({ inline_data: { mime_type: 'image/jpeg', data: await blobParaBase64(blob) } });
    partes.push({ text: prompt });
    const corpo = JSON.stringify({ contents: [{ role: 'user', parts: partes }], generationConfig: { responseMimeType: 'application/json', temperature: 0.2 } });
    let ultimoErro = 'Não consegui usar o Gemini agora.';
    for (let i = 0; i < MODELOS_GEMINI.length; i++) {
      let resp;
      try {
        resp = await fetch('https://generativelanguage.googleapis.com/v1beta/models/' + MODELOS_GEMINI[i] + ':generateContent', {
          method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': ChaveGemini.get() }, body: corpo
        });
      } catch (e) { throw new Error('Sem conexão com a internet, ou o Gemini não respondeu.'); }
      const j = await resp.json().catch(function () { return {}; });
      const msg = (j.error && j.error.message) || '';
      if (resp.ok) {
        const c = (j.candidates || [])[0];
        const t = c && c.content && (c.content.parts || []).map(function (p) { return p.text || ''; }).join('');
        if (t) return t;
        ultimoErro = 'O Gemini não devolveu resposta para essa imagem. Tente outra foto.';
        continue;
      }
      if (resp.status === 400 && /api key/i.test(msg)) throw new Error('Chave do Gemini inválida. Confira em Perfil → Inteligência artificial.');
      if (resp.status === 403) throw new Error('A chave do Gemini não tem permissão. Crie a chave de novo no Google AI Studio.');
      // 404 = modelo não existe mais; 429 = limite grátis do modelo: tenta o próximo
      ultimoErro = resp.status === 429 ? 'Limite grátis do Gemini atingido por hoje. Tente amanhã.' : 'O Gemini respondeu com erro ' + resp.status + (msg ? ': ' + msg : '') + '.';
      if (resp.status !== 404 && resp.status !== 429 && resp.status < 500) break;
    }
    throw new Error(ultimoErro);
  }

  /* ---------- Diário: soma e ajuste de porção ---------- */
  function totalItens(itens) {
    return itens.reduce(function (t, i) { return { kcal: t.kcal + i.kcal, p: t.p + i.p, c: t.c + i.c, g: t.g + i.g }; }, { kcal: 0, p: 0, c: 0, g: 0 });
  }
  // Mudou a gramagem: recalcula proporcionalmente
  function ajustarGramas(item, novas) {
    const g = Math.max(0, Math.round(Number(novas) || 0));
    const f = item.gramas > 0 ? g / item.gramas : 0;
    return { nome: item.nome, gramas: g, kcal: item.kcal * f, p: item.p * f, c: item.c * f, g: item.g * f };
  }

  /* ---------- Atualização do app (só no APK) ---------- */
  async function avisarPronto() {
    if (!ehAndroid()) return;
    try { await nativo('CapacitorUpdater', 'notifyAppReady'); } catch (e) { /* plugin ausente em APK antigo */ }
  }
  async function procurarAtualizacao() {
    const r = await fetch(URL_VERSAO + '?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) throw new Error('Não consegui verificar agora (erro ' + r.status + ').');
    const v = await r.json();
    return { atual: VERSAO_WEB, nova: Number(v.versao) || 0, url: String(v.url || ''), checksum: String(v.checksum || ''), novidades: Array.isArray(v.novidades) ? v.novidades.map(String) : [], temNova: Number(v.versao) > VERSAO_WEB };
  }
  async function instalarAtualizacao(info) {
    if (!ehAndroid()) throw new Error('A atualização automática funciona só no app do celular.');
    if (!/^https:\/\/jr28081987-rgb\.github\.io\/forja-web\//.test(info.url)) throw new Error('Endereço de atualização inesperado.');
    // O atualizador exige o SHA-256 do pacote: confere que o arquivo baixado é exatamente o publicado
    if (!/^[0-9a-f]{64}$/.test(info.checksum)) throw new Error('Pacote de atualização sem verificação. Tente mais tarde.');
    const pacote = await nativo('CapacitorUpdater', 'download', { url: info.url, version: String(info.nova), checksum: info.checksum });
    await nativo('CapacitorUpdater', 'set', { id: pacote.id }); // recarrega o app na versão nova
  }

  window.ForjaExtras = {
    VERSAO_WEB: VERSAO_WEB, ehAndroid: ehAndroid, Chave: Chave, ChaveGemini: ChaveGemini,
    analisar: analisar, disponivel: disponivel, totalItens: totalItens, ajustarGramas: ajustarGramas,
    avisarPronto: avisarPronto, procurarAtualizacao: procurarAtualizacao, instalarAtualizacao: instalarAtualizacao
  };
})();
