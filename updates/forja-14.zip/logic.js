/* Forja — lógica pura (cálculos de dieta e montagem de treino).
   Sem acesso a DOM ou banco: pode ser testada isoladamente no Node. */
(function (root) {
  'use strict';

  /* ---------- Catálogo de exercícios ----------
     g = grupo muscular | eq = equipamento mínimo (gym = academia, db = halteres, bw = peso corporal)
     c = 1 se for multiarticular (vem primeiro no treino) | t = dica de execução */
  const EX = [
    // Peito
    ['Barbell_Bench_Press_-_Medium_Grip', 'Supino reto com barra', 'peito', 'gym', 1, 'Escápulas presas no banco e pés firmes no chão. Desça a barra até encostar de leve na linha do peito.'],
    ['Dumbbell_Bench_Press', 'Supino reto com halteres', 'peito', 'db', 1, 'Cotovelos a uns 45° do tronco. Suba sem bater um halter no outro.'],
    ['Barbell_Incline_Bench_Press_-_Medium_Grip', 'Supino inclinado com barra', 'peito', 'gym', 1, 'Banco entre 30° e 45°. A barra desce na parte alta do peito.'],
    ['Incline_Dumbbell_Press', 'Supino inclinado com halteres', 'peito', 'db', 1, 'Banco entre 30° e 45°. Controle a descida em 2 segundos.'],
    ['Pushups', 'Flexão de braço', 'peito', 'bw', 1, 'Corpo reto da cabeça aos pés, abdômen firme. Peito quase toca o chão.'],
    ['Butterfly', 'Voador (peck deck)', 'peito', 'gym', 0, 'Cotovelos levemente flexionados. Aperte o peito no fim do movimento.'],
    ['Cable_Crossover', 'Crossover na polia', 'peito', 'gym', 0, 'Tronco levemente à frente. Traga as mãos em arco até se encontrarem.'],
    ['Dumbbell_Flyes', 'Crucifixo com halteres', 'peito', 'db', 0, 'Abra os braços até sentir o alongamento do peito, sem passar da linha do ombro.'],
    ['Incline_Push-Up', 'Flexão inclinada (mãos no banco)', 'peito', 'bw', 0, 'Versão mais leve da flexão. Quanto mais alto o apoio, mais fácil.'],
    // Costas
    ['Wide-Grip_Lat_Pulldown', 'Puxada frontal aberta', 'costas', 'gym', 1, 'Puxe a barra até o alto do peito, levando os cotovelos para baixo e para trás.'],
    ['Pullups', 'Barra fixa', 'costas', 'gym', 1, 'Comece com os braços estendidos e suba até o queixo passar a barra. Use elástico se precisar.'],
    ['Bent_Over_Barbell_Row', 'Remada curvada com barra', 'costas', 'gym', 1, 'Tronco inclinado a uns 45°, coluna neutra. Puxe a barra em direção ao umbigo.'],
    ['Seated_Cable_Rows', 'Remada baixa sentada', 'costas', 'gym', 1, 'Peito aberto, sem balançar o tronco. Puxe até a pegada encostar no abdômen.'],
    ['One-Arm_Dumbbell_Row', 'Remada unilateral com halter', 'costas', 'db', 1, 'Apoie joelho e mão no banco. Puxe o halter em direção ao quadril.'],
    ['Inverted_Row', 'Remada invertida', 'costas', 'bw', 1, 'Deitado sob uma mesa firme ou barra baixa, puxe o peito até ela com o corpo reto.'],
    ['Close-Grip_Front_Lat_Pulldown', 'Puxada frontal fechada', 'costas', 'gym', 0, 'Pegada fechada, puxe até o peito sem jogar o tronco para trás.'],
    ['Superman', 'Superman (lombar)', 'costas', 'bw', 0, 'Deitado de bruços, eleve braços e pernas juntos e segure 2 segundos.'],
    // Ombro
    ['Machine_Shoulder_Military_Press', 'Desenvolvimento na máquina', 'ombro', 'gym', 1, 'Costas apoiadas. Empurre até quase estender os cotovelos.'],
    ['Dumbbell_Shoulder_Press', 'Desenvolvimento com halteres', 'ombro', 'db', 1, 'Halteres na altura das orelhas. Suba sem arquear a lombar.'],
    ['Side_Lateral_Raise', 'Elevação lateral', 'ombro', 'db', 0, 'Suba os braços até a linha dos ombros, cotovelos levemente flexionados.'],
    ['Face_Pull', 'Face pull na polia', 'ombro', 'gym', 0, 'Corda na altura do rosto. Puxe abrindo as mãos para os lados das orelhas.'],
    ['Reverse_Flyes', 'Crucifixo invertido', 'ombro', 'db', 0, 'Tronco inclinado à frente. Abra os braços apertando a parte de trás dos ombros.'],
    ['Front_Dumbbell_Raise', 'Elevação frontal', 'ombro', 'db', 0, 'Suba o halter à frente até a linha dos ombros, sem balançar o corpo.'],
    // Bíceps
    ['Barbell_Curl', 'Rosca direta com barra', 'biceps', 'gym', 0, 'Cotovelos colados ao corpo. Não jogue o tronco para trás.'],
    ['Dumbbell_Bicep_Curl', 'Rosca com halteres', 'biceps', 'db', 0, 'Gire a palma para cima durante a subida. Desça devagar.'],
    ['Hammer_Curls', 'Rosca martelo', 'biceps', 'db', 0, 'Palmas viradas uma para a outra o tempo todo.'],
    // Tríceps
    ['Triceps_Pushdown_-_Rope_Attachment', 'Tríceps na corda', 'triceps', 'gym', 0, 'Cotovelos fixos ao lado do corpo. Abra a corda no final.'],
    ['Triceps_Pushdown', 'Tríceps no pulley (barra)', 'triceps', 'gym', 0, 'Cotovelos fixos. Estenda os braços por completo.'],
    ['Lying_Triceps_Press', 'Tríceps testa', 'triceps', 'gym', 0, 'Cotovelos apontados para cima. Desça a barra em direção à testa com controle.'],
    ['Bench_Dips', 'Mergulho no banco', 'triceps', 'bw', 0, 'Mãos na borda do banco, desça até os cotovelos formarem 90°.'],
    ['Push-Ups_-_Close_Triceps_Position', 'Flexão fechada', 'triceps', 'bw', 0, 'Mãos mais juntas que os ombros, cotovelos rentes ao corpo.'],
    // Quadríceps
    ['Barbell_Squat', 'Agachamento livre com barra', 'quad', 'gym', 1, 'Pés na largura dos ombros. Desça com o peito aberto e joelhos na direção dos pés.'],
    ['Leg_Press', 'Leg press', 'quad', 'gym', 1, 'Lombar sempre encostada. Não trave os joelhos no topo.'],
    ['Hack_Squat', 'Agachamento hack', 'quad', 'gym', 1, 'Desça até as coxas ficarem paralelas à plataforma.'],
    ['Goblet_Squat', 'Agachamento goblet', 'quad', 'db', 1, 'Segure um halter junto ao peito. Desça mantendo o tronco ereto.'],
    ['Split_Squat_with_Dumbbells', 'Afundo estático com halteres', 'quad', 'db', 1, 'Passada longa. Desça o joelho de trás em direção ao chão.'],
    ['Dumbbell_Lunges', 'Avanço com halteres', 'quad', 'db', 1, 'Dê um passo à frente e desça até os dois joelhos formarem 90°.'],
    ['Dumbbell_Step_Ups', 'Subida no banco', 'quad', 'db', 1, 'Empurre pelo calcanhar da perna que está no banco.'],
    ['Bodyweight_Squat', 'Agachamento (peso corporal)', 'quad', 'bw', 1, 'Braços à frente para equilibrar. Desça o quadril como se fosse sentar.'],
    ['Bodyweight_Walking_Lunge', 'Avanço caminhando', 'quad', 'bw', 1, 'Passos longos e tronco ereto, alternando as pernas.'],
    ['Leg_Extensions', 'Cadeira extensora', 'quad', 'gym', 0, 'Estenda as pernas por completo e segure 1 segundo no topo.'],
    // Posterior e glúteo
    ['Romanian_Deadlift', 'Levantamento terra romeno', 'post', 'gym', 1, 'Joelhos levemente flexionados. Leve o quadril para trás com a barra rente às pernas.'],
    ['Barbell_Hip_Thrust', 'Elevação pélvica com barra', 'post', 'gym', 1, 'Costas apoiadas no banco. Suba o quadril e contraia os glúteos no topo.'],
    ['Stiff-Legged_Dumbbell_Deadlift', 'Stiff com halteres', 'post', 'db', 1, 'Coluna neutra. Desça os halteres até sentir o alongamento atrás da coxa.'],
    ['Butt_Lift_Bridge', 'Ponte de glúteo', 'post', 'bw', 1, 'Deitado, pés no chão. Suba o quadril e segure 2 segundos.'],
    ['Lying_Leg_Curls', 'Mesa flexora', 'post', 'gym', 0, 'Quadril colado no banco. Traga os calcanhares em direção aos glúteos.'],
    ['Seated_Leg_Curl', 'Cadeira flexora', 'post', 'gym', 0, 'Coxas presas pelo apoio. Flexione até o fim e volte devagar.'],
    ['Glute_Kickback', 'Coice de glúteo', 'post', 'bw', 0, 'Em quatro apoios, empurre o calcanhar para cima sem arquear a lombar.'],
    // Panturrilha
    ['Standing_Calf_Raises', 'Panturrilha em pé na máquina', 'pant', 'gym', 0, 'Desça o calcanhar o máximo e suba na ponta dos pés.'],
    ['Seated_Calf_Raise', 'Panturrilha sentado', 'pant', 'gym', 0, 'Amplitude total, com 1 segundo de pausa no topo.'],
    ['Standing_Dumbbell_Calf_Raise', 'Panturrilha em pé (com ou sem halteres)', 'pant', 'bw', 0, 'Use um degrau para aumentar a amplitude. Segure halteres se tiver.'],
    // Core
    ['Plank', 'Prancha', 'core', 'bw', 0, 'Apoio nos antebraços, corpo reto. Contraia abdômen e glúteos.'],
    ['Crunches', 'Abdominal', 'core', 'bw', 0, 'Suba só até tirar as escápulas do chão. Sem puxar o pescoço.'],
    ['Cable_Crunch', 'Abdominal na polia', 'core', 'gym', 0, 'Ajoelhado, enrole o tronco para baixo usando o abdômen.'],
    ['Hanging_Leg_Raise', 'Elevação de pernas na barra', 'core', 'gym', 0, 'Pendurado, suba as pernas sem balançar o corpo.'],
    ['Russian_Twist', 'Giro russo', 'core', 'bw', 0, 'Tronco inclinado para trás, gire de um lado ao outro.'],
    ['Mountain_Climbers', 'Escalador', 'core', 'bw', 0, 'Em posição de flexão, traga os joelhos ao peito alternando rápido.'],
    ['Flutter_Kicks', 'Tesoura', 'core', 'bw', 0, 'Deitado, lombar colada no chão, alterne as pernas estendidas.'],
    ['Air_Bike', 'Abdominal bicicleta', 'core', 'bw', 0, 'Leve o cotovelo ao joelho oposto, alternando.'],
    // Ampliação: máquinas, polias, Smith e variações
    ["Machine_Bench_Press", "Supino reto na máquina", "peito", "gym", 1, "Ajuste o banco para as pegadas ficarem na linha do meio do peito. Empurre sem travar os cotovelos."],
    ["Leverage_Incline_Chest_Press", "Supino inclinado na máquina", "peito", "gym", 1, "Costas apoiadas. Empurre para cima e à frente e controle a volta."],
    ["Smith_Machine_Bench_Press", "Supino reto no Smith", "peito", "gym", 1, "A barra desce até a linha do peito. Destrave e trave a barra girando o punho."],
    ["Smith_Machine_Incline_Bench_Press", "Supino inclinado no Smith", "peito", "gym", 1, "Banco entre 30° e 45°. A barra desce na parte alta do peito."],
    ["Decline_Barbell_Bench_Press", "Supino declinado com barra", "peito", "gym", 1, "Pés presos no apoio. Desça a barra na parte baixa do peito."],
    ["Flat_Bench_Cable_Flyes", "Crucifixo na polia (banco reto)", "peito", "gym", 0, "Braços levemente dobrados. Abra até alongar o peito e feche em arco."],
    ["Low_Cable_Crossover", "Crossover na polia baixa", "peito", "gym", 0, "Puxe de baixo para cima, juntando as mãos na altura do peito."],
    ["Incline_Cable_Flye", "Crucifixo inclinado na polia", "peito", "gym", 0, "Banco inclinado entre as polias. Feche os braços em arco sobre o peito."],
    ["Leverage_Iso_Row", "Remada na máquina (pegada neutra)", "costas", "gym", 1, "Peito apoiado. Leve os cotovelos para trás e aperte as escápulas no fim."],
    ["Leverage_High_Row", "Remada alta na máquina", "costas", "gym", 1, "Puxe de cima para baixo e para trás, com o peito sempre no apoio."],
    ["Lying_T-Bar_Row", "Remada cavalinho com apoio", "costas", "gym", 1, "Peito no apoio. Puxe até o abdômen sem tirar o peito do banco."],
    ["T-Bar_Row_with_Handle", "Remada cavalinho (barra T)", "costas", "gym", 1, "Tronco inclinado e coluna neutra. Puxe a barra até o abdômen."],
    ["V-Bar_Pulldown", "Puxada com triângulo", "costas", "gym", 1, "Puxe o triângulo até o alto do peito, inclinando o tronco só um pouco."],
    ["Underhand_Cable_Pulldowns", "Puxada supinada", "costas", "gym", 1, "Palmas viradas para você. Puxe até o peito levando os cotovelos para baixo."],
    ["Smith_Machine_Bent_Over_Row", "Remada curvada no Smith", "costas", "gym", 1, "Tronco inclinado e coluna neutra. Puxe a barra até o umbigo."],
    ["Seated_One-arm_Cable_Pulley_Rows", "Remada unilateral na polia", "costas", "gym", 0, "Um braço de cada vez. Puxe até a cintura girando levemente o tronco."],
    ["Straight-Arm_Pulldown", "Pulldown com braços estendidos", "costas", "gym", 0, "Braços quase retos. Leve a barra da altura da cabeça até as coxas."],
    ["Leverage_Shoulder_Press", "Desenvolvimento na máquina articulada", "ombro", "gym", 1, "Pegadas na altura dos ombros. Empurre para cima sem arquear a lombar."],
    ["Smith_Machine_Overhead_Shoulder_Press", "Desenvolvimento no Smith", "ombro", "gym", 1, "Sentado. A barra desce até a altura do queixo."],
    ["Cable_Seated_Lateral_Raise", "Elevação lateral na polia", "ombro", "gym", 0, "Puxe o cabo para o lado até a linha do ombro, sem balançar o corpo."],
    ["Reverse_Machine_Flyes", "Crucifixo inverso na máquina (voador inverso)", "ombro", "gym", 0, "Peito no apoio. Abra os braços para trás apertando a parte de trás do ombro."],
    ["Cable_Rear_Delt_Fly", "Crucifixo inverso na polia", "ombro", "gym", 0, "Cabos cruzados à frente. Abra os braços para trás na altura dos ombros."],
    ["Cable_Rope_Rear-Delt_Rows", "Remada para deltoide posterior (corda)", "ombro", "gym", 0, "Puxe a corda em direção ao rosto com os cotovelos altos e abertos."],
    ["Upright_Cable_Row", "Remada alta na polia", "ombro", "gym", 0, "Puxe a barra até a altura do peito, com os cotovelos acima das mãos."],
    ["Front_Cable_Raise", "Elevação frontal na polia", "ombro", "gym", 0, "De costas para a polia baixa, suba o cabo à frente até a linha dos ombros."],
    ["Barbell_Shrug", "Encolhimento com barra", "ombro", "gym", 0, "Suba os ombros em direção às orelhas e segure 1 segundo. Não gire."],
    ["Dumbbell_Shrug", "Encolhimento com halteres", "ombro", "db", 0, "Suba os ombros em direção às orelhas e segure 1 segundo."],
    ["Standing_Biceps_Cable_Curl", "Rosca direta na polia", "biceps", "gym", 0, "Cotovelos colados ao corpo. Suba a barra sem jogar o tronco."],
    ["Cable_Hammer_Curls_-_Rope_Attachment", "Rosca martelo na polia (corda)", "biceps", "gym", 0, "Palmas viradas uma para a outra. Cotovelos fixos."],
    ["Machine_Preacher_Curls", "Rosca Scott na máquina", "biceps", "gym", 0, "Braços apoiados. Desça devagar até quase estender."],
    ["Preacher_Curl", "Rosca Scott com barra", "biceps", "gym", 0, "Braços no apoio. Desça devagar, sem travar o cotovelo embaixo."],
    ["EZ-Bar_Curl", "Rosca com barra W", "biceps", "gym", 0, "Cotovelos colados ao corpo. A barra W alivia os punhos."],
    ["Overhead_Cable_Curl", "Rosca na polia alta (crossover)", "biceps", "gym", 0, "Braços abertos na altura dos ombros. Traga as mãos até a cabeça."],
    ["Concentration_Curls", "Rosca concentrada", "biceps", "db", 0, "Cotovelo apoiado na parte interna da coxa. Suba devagar."],
    ["Incline_Dumbbell_Curl", "Rosca no banco inclinado", "biceps", "db", 0, "Costas no banco inclinado, braços pendurados. Suba sem mexer os ombros."],
    ["Triceps_Overhead_Extension_with_Rope", "Tríceps francês na polia (corda)", "triceps", "gym", 0, "De costas para a polia, estenda os braços acima da cabeça."],
    ["Machine_Triceps_Extension", "Tríceps na máquina", "triceps", "gym", 0, "Cotovelos apoiados. Estenda os braços por completo."],
    ["Reverse_Grip_Triceps_Pushdown", "Tríceps na polia (pegada invertida)", "triceps", "gym", 0, "Palmas para cima. Cotovelos fixos ao lado do corpo."],
    ["Triceps_Pushdown_-_V-Bar_Attachment", "Tríceps na polia (barra V)", "triceps", "gym", 0, "Cotovelos fixos. Estenda até os braços ficarem retos."],
    ["Dips_-_Triceps_Version", "Mergulho nas paralelas", "triceps", "gym", 1, "Tronco reto. Desça até os cotovelos formarem 90°."],
    ["Close-Grip_Barbell_Bench_Press", "Supino fechado", "triceps", "gym", 1, "Mãos na largura dos ombros, cotovelos rentes ao corpo."],
    ["Seated_Triceps_Press", "Tríceps francês com halter", "triceps", "db", 0, "Sentado. Desça o halter atrás da cabeça e estenda os braços."],
    ["Tricep_Dumbbell_Kickback", "Tríceps coice com halter", "triceps", "db", 0, "Tronco inclinado, braço colado ao corpo. Estenda o cotovelo para trás."],
    ["Smith_Machine_Squat", "Agachamento no Smith", "quad", "gym", 1, "Pés um pouco à frente da barra. Desça até as coxas ficarem paralelas ao chão."],
    ["Front_Barbell_Squat", "Agachamento frontal", "quad", "gym", 1, "Barra apoiada na frente dos ombros, cotovelos altos e tronco ereto."],
    ["Narrow_Stance_Leg_Press", "Leg press com pés juntos", "quad", "gym", 1, "Pés juntos no meio da plataforma. Lombar sempre encostada."],
    ["Smith_Single-Leg_Split_Squat", "Afundo no Smith", "quad", "gym", 1, "Passada longa. Desça o joelho de trás em direção ao chão."],
    ["Barbell_Lunge", "Avanço com barra", "quad", "gym", 1, "Passo à frente e desça até os dois joelhos formarem 90°."],
    ["Single-Leg_Leg_Extension", "Cadeira extensora unilateral", "quad", "gym", 0, "Uma perna de cada vez. Segure 1 segundo com a perna estendida."],
    ["Standing_Leg_Curl", "Flexora em pé", "post", "gym", 0, "Uma perna de cada vez. Traga o calcanhar em direção ao glúteo."],
    ["Stiff-Legged_Barbell_Deadlift", "Stiff com barra", "post", "gym", 1, "Joelhos quase retos e coluna neutra. Desça até alongar atrás da coxa."],
    ["Sumo_Deadlift", "Levantamento terra sumô", "post", "gym", 1, "Pés bem afastados e pontas para fora. Suba empurrando o chão."],
    ["Barbell_Glute_Bridge", "Ponte de glúteo com barra", "post", "gym", 1, "Deitado no chão com a barra no quadril. Suba e contraia os glúteos."],
    ["One-Legged_Cable_Kickback", "Glúteo na polia (coice)", "post", "gym", 0, "Tornozeleira na polia baixa. Leve a perna para trás sem arquear a lombar."],
    ["Pull_Through", "Pull through na polia", "post", "gym", 0, "De costas para a polia baixa. Leve o quadril para trás e estenda contraindo os glúteos."],
    ["Thigh_Abductor", "Cadeira abdutora", "post", "gym", 0, "Abra as pernas contra a resistência e volte devagar."],
    ["Thigh_Adductor", "Cadeira adutora", "post", "gym", 0, "Feche as pernas contra a resistência e volte devagar."],
    ["Calf_Press_On_The_Leg_Press_Machine", "Panturrilha no leg press", "pant", "gym", 0, "Só a ponta dos pés na plataforma. Empurre e desça alongando."],
    ["Smith_Machine_Calf_Raise", "Panturrilha no Smith", "pant", "gym", 0, "Ponta dos pés num degrau. Suba e desça com amplitude total."],
    ["Ab_Crunch_Machine", "Abdominal na máquina", "core", "gym", 0, "Enrole o tronco usando o abdômen, sem puxar com os braços."],
    ["Decline_Crunch", "Abdominal no banco declinado", "core", "gym", 0, "Pés presos. Suba só até tirar as escápulas do banco."],
    ["Pallof_Press", "Pallof press na polia", "core", "gym", 0, "De lado para a polia, empurre o cabo à frente sem deixar o tronco girar."],
    ["Leg_Pull-In", "Abdominal infra (puxada de pernas)", "core", "bw", 0, "Sentado, mãos apoiadas atrás. Traga os joelhos ao peito e estenda."]
  ].map(function (r) { return { id: r[0], nome: r[1], g: r[2], eq: r[3], c: r[4], dica: r[5] }; });

  // Máquinas, polias e Smith (para a preferência de equipamento)
  const MAQ = {};
  ["Butterfly", "Cable_Crossover", "Wide-Grip_Lat_Pulldown", "Seated_Cable_Rows", "Close-Grip_Front_Lat_Pulldown", "Machine_Shoulder_Military_Press", "Face_Pull", "Triceps_Pushdown_-_Rope_Attachment", "Triceps_Pushdown", "Leg_Press", "Hack_Squat", "Leg_Extensions", "Lying_Leg_Curls", "Seated_Leg_Curl", "Standing_Calf_Raises", "Seated_Calf_Raise", "Cable_Crunch", "Machine_Bench_Press", "Leverage_Incline_Chest_Press", "Smith_Machine_Bench_Press", "Smith_Machine_Incline_Bench_Press", "Flat_Bench_Cable_Flyes", "Low_Cable_Crossover", "Incline_Cable_Flye", "Leverage_Iso_Row", "Leverage_High_Row", "Lying_T-Bar_Row", "V-Bar_Pulldown", "Underhand_Cable_Pulldowns", "Smith_Machine_Bent_Over_Row", "Seated_One-arm_Cable_Pulley_Rows", "Straight-Arm_Pulldown", "Leverage_Shoulder_Press", "Smith_Machine_Overhead_Shoulder_Press", "Cable_Seated_Lateral_Raise", "Reverse_Machine_Flyes", "Cable_Rear_Delt_Fly", "Cable_Rope_Rear-Delt_Rows", "Upright_Cable_Row", "Front_Cable_Raise", "Standing_Biceps_Cable_Curl", "Cable_Hammer_Curls_-_Rope_Attachment", "Machine_Preacher_Curls", "Overhead_Cable_Curl", "Triceps_Overhead_Extension_with_Rope", "Machine_Triceps_Extension", "Reverse_Grip_Triceps_Pushdown", "Triceps_Pushdown_-_V-Bar_Attachment", "Smith_Machine_Squat", "Narrow_Stance_Leg_Press", "Smith_Single-Leg_Split_Squat", "Single-Leg_Leg_Extension", "Standing_Leg_Curl", "One-Legged_Cable_Kickback", "Pull_Through", "Thigh_Abductor", "Thigh_Adductor", "Calf_Press_On_The_Leg_Press_Machine", "Smith_Machine_Calf_Raise", "Ab_Crunch_Machine", "Pallof_Press"].forEach(function (id) { MAQ[id] = true; });
  EX.forEach(function (e) { e.maq = !!MAQ[e.id]; });

  const EX_BY_ID = {};
  EX.forEach(function (e) { EX_BY_ID[e.id] = e; });

  const GRUPOS = { peito: 'Peito', costas: 'Costas', ombro: 'Ombros', biceps: 'Bíceps', triceps: 'Tríceps', quad: 'Quadríceps', post: 'Posterior e glúteos', pant: 'Panturrilha', core: 'Abdômen' };

  // Ordem de equipamento: academia libera tudo; halteres libera halteres + peso corporal.
  const EQ_OK = { gym: ['gym', 'db', 'bw'], db: ['db', 'bw'], bw: ['bw'] };
  // Se o grupo não tem exercício para o equipamento, usa um grupo substituto.
  const FALLBACK = { ombro: 'peito', ombro_post: 'costas', biceps: 'costas', triceps: 'peito' };

  // Parte de trás do ombro: entra no treino de puxar (o desenvolvimento é movimento de empurrar)
  const OMBRO_POST = ['Face_Pull', 'Reverse_Flyes'];
  // estilo (só academia): 'maquinas' = máquinas primeiro; 'livres' = pesos livres primeiro; 'misto' = alterna
  function ordenarPorEstilo(lista, estilo) {
    const maq = lista.filter(function (e) { return e.maq; }), liv = lista.filter(function (e) { return !e.maq; });
    if (estilo === 'maquinas') return maq.concat(liv);
    if (estilo === 'livres') return liv.concat(maq);
    const out = [];
    for (let i = 0; i < Math.max(maq.length, liv.length); i++) { if (liv[i]) out.push(liv[i]); if (maq[i]) out.push(maq[i]); }
    return out;
  }
  function pool(grupo, eq, estilo) {
    const ok = EQ_OK[eq] || EQ_OK.gym;
    const list = EX.filter(function (e) {
      const g = grupo === 'ombro_post' ? OMBRO_POST.indexOf(e.id) >= 0 : e.g === grupo;
      return g && ok.indexOf(e.eq) >= 0;
    });
    // Multiarticulares primeiro; dentro de cada parte, a ordem segue a preferência de equipamento
    const comp = list.filter(function (e) { return e.c; }), iso = list.filter(function (e) { return !e.c; });
    if (eq === 'gym' && estilo === 'maquinas') {
      // Máquinas primeiro de verdade: todas as máquinas/polias do grupo antes dos pesos livres
      const m = function (l, v) { return l.filter(function (e) { return e.maq === v; }); };
      return m(comp, true).concat(m(iso, true), m(comp, false), m(iso, false));
    }
    if (eq === 'gym') return ordenarPorEstilo(comp, estilo).concat(ordenarPorEstilo(iso, estilo));
    return comp.concat(iso);
  }

  /* ---------- Modelos de divisão ---------- */
  const DIAS = {
    FB_A: { nome: 'Corpo inteiro A', slots: ['quad', 'peito', 'costas', 'post', 'ombro', 'triceps', 'core', 'biceps'] },
    FB_B: { nome: 'Corpo inteiro B', slots: ['post', 'costas', 'peito', 'quad', 'ombro', 'biceps', 'core', 'triceps'] },
    FB_C: { nome: 'Corpo inteiro C', slots: ['quad', 'ombro', 'costas', 'peito', 'post', 'pant', 'core', 'core'] },
    SUP_A: { nome: 'Superiores A', slots: ['peito', 'costas', 'ombro', 'peito', 'costas', 'biceps', 'triceps', 'ombro'] },
    INF_A: { nome: 'Inferiores A', slots: ['quad', 'post', 'quad', 'post', 'pant', 'core', 'core', 'post'] },
    SUP_B: { nome: 'Superiores B', slots: ['costas', 'peito', 'ombro', 'costas', 'ombro', 'triceps', 'biceps', 'peito'] },
    INF_B: { nome: 'Inferiores B', slots: ['post', 'quad', 'post', 'quad', 'pant', 'core', 'core', 'quad'] },
    PUSH: { nome: 'Empurrar (peito, ombro, tríceps)', slots: ['peito', 'ombro', 'peito', 'ombro', 'triceps', 'triceps', 'core', 'peito'] },
    PULL: { nome: 'Puxar (costas, bíceps)', slots: ['costas', 'costas', 'ombro_post', 'post', 'biceps', 'biceps', 'core', 'costas'] },
    LEGS: { nome: 'Pernas', slots: ['quad', 'post', 'quad', 'post', 'pant', 'core', 'core', 'pant'] }
  };
  const DIVISAO = {
    2: [['FB_A', 0], ['FB_B', 0]],
    3: [['FB_A', 0], ['FB_B', 0], ['FB_C', 0]],
    4: [['SUP_A', 0], ['INF_A', 0], ['SUP_B', 1], ['INF_B', 1]],
    5: [['PUSH', 0], ['PULL', 0], ['LEGS', 0], ['SUP_A', 1], ['INF_A', 1]],
    6: [['PUSH', 0], ['PULL', 0], ['LEGS', 0], ['PUSH', 1], ['PULL', 1], ['LEGS', 1]]
  };
  const N_EX = { 30: 4, 45: 5, 60: 6, 75: 7, 90: 8 };

  /* Objetivos: o perfil pode ter mais de um (ex.: emagrecer + ganhar massa) */
  function listaObjetivos(perfil) {
    const l = Array.isArray(perfil.objetivos) && perfil.objetivos.length ? perfil.objetivos : [perfil.objetivo || 'massa'];
    return l.filter(function (o) { return ['emagrecer', 'definir', 'massa', 'forca'].indexOf(o) >= 0; });
  }
  // Estilo de treino: força > massa > definir > emagrecer (o mais exigente manda)
  function estiloTreino(perfil) {
    const l = listaObjetivos(perfil);
    return ['forca', 'massa', 'definir', 'emagrecer'].find(function (o) { return l.indexOf(o) >= 0; }) || 'massa';
  }
  /* Ajuste calórico combinado:
     - perder (emagrecer/definir) + ganhar (massa/força) = recomposição corporal: déficit leve de 10%
     - só perder: o maior déficit escolhido (emagrecer 20%, definir 10%)
     - só ganhar: o maior superávit escolhido (massa 10%, força 5%) */
  function ajusteCalorico(perfil) {
    const l = listaObjetivos(perfil);
    const perde = l.indexOf('emagrecer') >= 0 || l.indexOf('definir') >= 0;
    const ganha = l.indexOf('massa') >= 0 || l.indexOf('forca') >= 0;
    if (perde && ganha) return { aj: -0.10, tipo: 'recomposição corporal' };
    if (perde) return l.indexOf('emagrecer') >= 0 ? { aj: -0.20, tipo: 'emagrecer' } : { aj: -0.10, tipo: 'definir' };
    return l.indexOf('massa') >= 0 ? { aj: 0.10, tipo: 'ganhar massa' } : { aj: 0.05, tipo: 'força' };
  }

  /* Séries, repetições e descanso por objetivo e nível */
  function prescricao(ex, objetivo, nivel) {
    let s, r, d;
    if (ex.g === 'core') {
      s = 3; r = ex.id === 'Plank' ? '30–45 s' : '15–20'; d = 45;
    } else if (objetivo === 'emagrecer') { s = 3; r = '12–15'; d = 45; }
    else if (objetivo === 'definir') { s = 3; r = '10–12'; d = 60; }
    else if (objetivo === 'forca') {
      if (ex.c) { s = 5; r = '4–6'; d = 150; } else { s = 3; r = '8–10'; d = 90; }
    } else { // massa
      if (ex.c) { s = 4; r = '8–12'; d = 90; } else { s = 3; r = '10–12'; d = 60; }
    }
    // Iniciante: uma série a menos nos exercícios mais pesados, mas nunca menos de 3
    if (nivel === 'iniciante') s = Math.max(3, s - 1);
    return { series: s, reps: r, descanso: d };
  }

  /* Monta o plano de treino a partir do perfil.
     trocas = { 'diaIdx_slotIdx': exId } guarda os exercícios que o usuário trocou. */
  function montarTreino(perfil, trocas) {
    trocas = trocas || {};
    const dias = Math.min(6, Math.max(2, Number(perfil.dias) || 3));
    const trinca = perfil.metodo === 'trinca';
    // Trinca: blocos de 3 exercícios, então o total é múltiplo de 3
    const n = trinca ? ((Number(perfil.tempo) || 60) <= 30 ? 3 : 6) : (N_EX[perfil.tempo] || 6);
    // ABC clássico: A empurrar, B puxar, C pernas (com 6 dias, duas voltas com variação)
    const divisao = perfil.divisao === 'abc' ? (dias >= 6 ? DIVISAO[6] : [['PUSH', 0], ['PULL', 0], ['LEGS', 0]]) : DIVISAO[dias];
    return divisao.map(function (par, di) {
      const modelo = DIAS[par[0]];
      const variante = par[1];
      const usados = {};
      const contGrupo = {};
      const itens = [];
      modelo.slots.forEach(function (g0, si) {
        if (itens.length >= n) return; // slots extras só entram se algum grupo esgotar
        let g = g0;
        let lista = pool(g, perfil.equip, perfil.estilo);
        if (!lista.length && FALLBACK[g]) { g = FALLBACK[g]; lista = pool(g, perfil.equip, perfil.estilo); }
        if (!lista.length) return;
        const k = contGrupo[g] || 0;
        contGrupo[g] = k + 1;
        let ex = null;
        // Escolhe o (variante + k)-ésimo exercício do grupo que ainda não foi usado no dia
        for (let j = 0; j < lista.length; j++) {
          const cand = lista[(variante * 2 + k + j) % lista.length];
          if (!usados[cand.id]) { ex = cand; break; }
        }
        if (!ex) return; // grupo esgotado: não repete exercício no mesmo dia
        const chave = di + '_' + si;
        if (trocas[chave] && EX_BY_ID[trocas[chave]]) ex = EX_BY_ID[trocas[chave]];
        usados[ex.id] = true;
        const p = prescricao(ex, estiloTreino(perfil), perfil.nivel);
        itens.push({ chave: chave, ex: ex.id, series: p.series, reps: p.reps, descanso: p.descanso });
      });
      if (trinca) aplicarTrinca(itens, estiloTreino(perfil));
      return { letra: String.fromCharCode(65 + di), nome: modelo.nome, itens: itens };
    });
  }

  /* Método trinca: agrupa de 3 em 3, iguala as séries do bloco e
     zera o descanso entre os exercícios; o descanso fica só depois do terceiro. */
  function aplicarTrinca(itens, objetivo) {
    const descBloco = objetivo === 'forca' ? 150 : objetivo === 'massa' ? 120 : 90;
    for (let b = 0; b * 3 < itens.length; b++) {
      const bloco = itens.slice(b * 3, b * 3 + 3);
      const series = Math.max.apply(null, bloco.map(function (i) { return i.series; }));
      bloco.forEach(function (it, j) {
        it.bloco = b + 1;
        it.posBloco = j + 1;
        it.tamBloco = bloco.length;
        it.series = series;
        it.descanso = j === bloco.length - 1 ? descBloco : 0;
      });
    }
  }

  /* Alternativas para trocar um exercício: mesmo grupo, equipamento compatível */
  function alternativas(exId, equip, estilo) {
    const ex = EX_BY_ID[exId];
    if (!ex) return [];
    return pool(ex.g, equip, estilo).filter(function (e) { return e.id !== exId; });
  }
  // Todos os exercícios de um grupo para o equipamento (usado em "Adicionar exercício")
  function doGrupo(grupo, equip, estilo) { return pool(grupo, equip, estilo); }

  /* ---------- Alimentos ----------
     Valores aproximados por 100 g (Tabela TACO/UNICAMP, alimento preparado como indicado).
     Whey: média de rótulos comerciais — confira o do seu produto.
     un = peso de 1 unidade em g (quando o alimento é contado em unidades) */
  const ALIM = {
    arroz: { nome: 'Arroz branco cozido', kcal: 128, p: 2.5, c: 28.1, g: 0.2 },
    arroz_int: { nome: 'Arroz integral cozido', kcal: 124, p: 2.6, c: 25.8, g: 1.0 },
    feijao: { nome: 'Feijão carioca cozido', kcal: 76, p: 4.8, c: 13.6, g: 0.5 },
    batata_doce: { nome: 'Batata-doce cozida', kcal: 77, p: 0.6, c: 18.4, g: 0.1 },
    mandioca: { nome: 'Mandioca cozida', kcal: 125, p: 0.6, c: 30.1, g: 0.3 },
    pao: { nome: 'Pão francês', kcal: 300, p: 8.0, c: 58.6, g: 3.1, un: 50, unNome: 'pão' },
    aveia: { nome: 'Aveia em flocos', kcal: 394, p: 13.9, c: 66.6, g: 8.5 },
    banana: { nome: 'Banana prata', kcal: 98, p: 1.3, c: 26.0, g: 0.1 },
    mamao: { nome: 'Mamão papaia', kcal: 40, p: 0.5, c: 10.4, g: 0.1 },
    maca: { nome: 'Maçã fuji', kcal: 56, p: 0.3, c: 15.2, g: 0.0 },
    frango: { nome: 'Peito de frango grelhado', kcal: 159, p: 32.0, c: 0, g: 2.5 },
    patinho: { nome: 'Patinho grelhado', kcal: 219, p: 35.9, c: 0, g: 7.3 },
    ovo: { nome: 'Ovo cozido', kcal: 146, p: 13.3, c: 0.6, g: 9.5, un: 50, unNome: 'ovo' },
    iogurte: { nome: 'Iogurte natural desnatado', kcal: 41, p: 3.8, c: 5.8, g: 0.3 },
    queijo: { nome: 'Queijo minas frescal', kcal: 264, p: 17.4, c: 3.2, g: 20.2 },
    whey: { nome: 'Whey protein (média de rótulos)', kcal: 400, p: 80, c: 10, g: 5 },
    azeite: { nome: 'Azeite de oliva', kcal: 884, p: 0, c: 0, g: 100 },
    amendoim: { nome: 'Amendoim (grão)', kcal: 544, p: 27.2, c: 20.3, g: 43.9 },
    brocolis: { nome: 'Brócolis cozido', kcal: 25, p: 2.1, c: 4.4, g: 0.5 },
    salada: { nome: 'Salada de folhas e tomate', kcal: 15, p: 1.0, c: 3.0, g: 0.2 }
  };

  /* Limites de porção por alimento (g): mínimo, máximo, arredondamento */
  const LIM = {
    ovo: [50, 150, 50], pao: [50, 100, 50], whey: [15, 40, 5], azeite: [0, 20, 5], amendoim: [0, 40, 5],
    aveia: [10, 80, 5], queijo: [20, 60, 10], iogurte: [100, 300, 50], banana: [50, 250, 10], maca: [50, 250, 10],
    frango: [60, 300, 10], patinho: [60, 300, 10]
  };
  function arred(id, gramas) {
    const l = LIM[id] || [30, 500, 10];
    let v = Math.round(gramas / l[2]) * l[2];
    return Math.min(l[1], Math.max(l[0], v));
  }

  /* Modelos de refeição: papel -> opções (a primeira é o padrão). fixo = porção fixa em g */
  const REF = {
    cafe: { nome: 'Café da manhã', prot: ['ovo', 'iogurte', 'queijo', 'whey'], carb: ['pao', 'aveia', 'banana'], fixo: [['fruta', ['mamao', 'banana', 'maca'], 100]] },
    lanche_m: { nome: 'Lanche da manhã', prot: ['iogurte', 'whey', 'ovo', 'queijo'], carb: ['aveia', 'banana', 'maca'], gord: ['amendoim'] },
    almoco: { nome: 'Almoço', prot: ['frango', 'patinho', 'ovo'], carb: ['arroz', 'arroz_int', 'batata_doce', 'mandioca'], fixo: [['feijao', ['feijao'], 100], ['legume', ['salada', 'brocolis'], 100]], gord: ['azeite'] },
    lanche_t: { nome: 'Lanche da tarde', prot: ['iogurte', 'whey', 'ovo', 'queijo'], carb: ['aveia', 'pao', 'banana'], gord: ['amendoim'] },
    jantar: { nome: 'Jantar', prot: ['frango', 'patinho', 'ovo'], carb: ['batata_doce', 'arroz', 'arroz_int', 'mandioca'], fixo: [['legume', ['brocolis', 'salada'], 100]], gord: ['azeite'] },
    ceia: { nome: 'Ceia', prot: ['iogurte', 'queijo', 'ovo', 'whey'] }
  };
  const DIST = {
    3: [['cafe', 0.25], ['almoco', 0.40], ['jantar', 0.35]],
    4: [['cafe', 0.25], ['almoco', 0.35], ['lanche_t', 0.15], ['jantar', 0.25]],
    5: [['cafe', 0.20], ['lanche_m', 0.10], ['almoco', 0.30], ['lanche_t', 0.15], ['jantar', 0.25]],
    6: [['cafe', 0.20], ['lanche_m', 0.10], ['almoco', 0.30], ['lanche_t', 0.15], ['jantar', 0.20], ['ceia', 0.05]]
  };

  function macrosDe(id, gramas) {
    const a = ALIM[id], f = gramas / 100;
    return { kcal: a.kcal * f, p: a.p * f, c: a.c * f, g: a.g * f };
  }
  function soma(lista) {
    return lista.reduce(function (t, m) { return { kcal: t.kcal + m.kcal, p: t.p + m.p, c: t.c + m.c, g: t.g + m.g }; }, { kcal: 0, p: 0, c: 0, g: 0 });
  }

  /* ---------- Metas de energia e macros ---------- */
  function metas(perfil) {
    const peso = Number(perfil.peso), alt = Number(perfil.altura), idade = Number(perfil.idade);
    // 1) Taxa metabólica basal — Mifflin-St Jeor
    const tmb = 10 * peso + 6.25 * alt - 5 * idade + (perfil.sexo === 'M' ? 5 : -161);
    // 2) Fator de atividade: treinos por semana + tipo de trabalho
    const d = Number(perfil.dias) || 0;
    let fator = d <= 1 ? 1.2 : d <= 3 ? 1.375 : d <= 5 ? 1.55 : 1.725;
    fator += ({ sentado: 0, em_pe: 0.1, pesado: 0.2 })[perfil.trabalho] || 0;
    fator = Math.min(1.9, fator);
    const get = tmb * fator;
    // 3) Ajuste pelo objetivo
    const ajc = ajusteCalorico(perfil);
    const aj = ajc.aj;
    let kcal = get * (1 + aj);
    // Ajuste acumulado dos check-ins semanais (limitado a ±500 kcal)
    const ajusteCheckin = Math.max(-500, Math.min(500, Number(perfil.ajusteKcal) || 0));
    kcal += ajusteCheckin;
    // Piso de segurança: nunca abaixo da TMB nem de 1500 (homens) / 1200 (mulheres)
    const piso = Math.max(tmb, perfil.sexo === 'M' ? 1500 : 1200);
    const noPiso = kcal < piso;
    if (noPiso) kcal = piso;
    kcal = Math.round(kcal / 10) * 10;
    // 4) Macros: proteína por kg, gordura 0,8 g/kg (mínimo 20% das kcal), carboidrato = restante
    // Proteína: o maior valor entre os objetivos escolhidos
    const gpk = Math.max.apply(null, listaObjetivos(perfil).map(function (o) { return ({ emagrecer: 2.2, definir: 2.2, massa: 2.0, forca: 1.8 })[o]; }));
    const p = Math.round(gpk * peso);
    const g = Math.round(Math.max(0.8 * peso, (0.20 * kcal) / 9));
    const c = Math.max(0, Math.round((kcal - 4 * p - 9 * g) / 4));
    return { tmb: Math.round(tmb), fator: fator, get: Math.round(get), ajuste: aj, tipoAjuste: ajc.tipo, ajusteCheckin: ajusteCheckin, kcal: kcal, noPiso: noPiso, gpk: gpk, p: p, c: c, g: g };
  }

  /* Calcula uma refeição: porções do alimento de proteína, carboidrato e gordura para bater a meta */
  function montarRefeicao(chave, alvo, trocas) {
    const m = REF[chave];
    const esc = function (papel, opcoes) { const t = trocas[chave + '.' + papel]; return opcoes.indexOf(t) >= 0 ? t : opcoes[0]; };
    const fixos = (m.fixo || []).map(function (f) { const id = esc(f[0], f[1]); return { papel: f[0], id: id, gramas: f[2], opcoes: f[1] }; });
    const base = soma(fixos.map(function (f) { return macrosDe(f.id, f.gramas); }));
    const prot = m.prot ? { papel: 'prot', id: esc('prot', m.prot), opcoes: m.prot } : null;
    const carb = m.carb ? { papel: 'carb', id: esc('carb', m.carb), opcoes: m.carb } : null;
    const gord = m.gord ? { papel: 'gord', id: esc('gord', m.gord), opcoes: m.gord } : null;
    // Duas passadas: a proteína do carboidrato (ex.: aveia, pão) é descontada na segunda
    let gp = 0, gc = 0;
    for (let it = 0; it < 2; it++) {
      if (prot) {
        const pc = carb ? macrosDe(carb.id, gc).p : 0;
        gp = arred(prot.id, Math.max(0, alvo.p - base.p - pc) / (ALIM[prot.id].p / 100));
      }
      if (carb) {
        const cp = prot ? macrosDe(prot.id, gp).c : 0;
        const rest = Math.max(0, alvo.c - base.c - cp);
        gc = arred(carb.id, rest / (ALIM[carb.id].c / 100));
      }
    }
    if (prot) prot.gramas = gp;
    if (carb) carb.gramas = gc;
    if (gord) {
      const ja = base.g + (prot ? macrosDe(prot.id, gp).g : 0) + (carb ? macrosDe(carb.id, gc).g : 0);
      gord.gramas = arred(gord.id, Math.max(0, alvo.g - ja) / (ALIM[gord.id].g / 100));
    }
    const itens = [prot, carb].concat(fixos).concat([gord]).filter(function (x) { return x && x.gramas > 0; });
    itens.forEach(function (x) { x.macros = macrosDe(x.id, x.gramas); });
    return { chave: chave, nome: m.nome, alvo: alvo, itens: itens, total: soma(itens.map(function (x) { return x.macros; })) };
  }

  function montarDieta(perfil, trocas) {
    trocas = trocas || {};
    const mt = metas(perfil);
    const n = Math.min(6, Math.max(3, Number(perfil.refeicoes) || 4));
    const refeicoes = DIST[n].map(function (par) {
      const f = par[1];
      return montarRefeicao(par[0], { kcal: mt.kcal * f, p: mt.p * f, c: mt.c * f, g: mt.g * f }, trocas);
    });
    equilibrar(refeicoes, mt);
    return { metas: mt, refeicoes: refeicoes, total: soma(refeicoes.map(function (r) { return r.total; })) };
  }

  /* Ajuste fino do dia: o arredondamento das porções gera sobras/faltas.
     Corrige proteína, depois carboidrato, depois gordura, mexendo só no almoço e no jantar. */
  function equilibrar(refeicoes, mt) {
    const papelDe = { p: 'prot', c: 'carb', g: 'gord' };
    const principais = refeicoes.filter(function (r) { return r.chave === 'almoco' || r.chave === 'jantar'; });
    ['p', 'c', 'g'].forEach(function (mac) {
      const total = soma(refeicoes.map(function (r) { return r.total; }));
      const diff = mt[mac] - total[mac];
      const itens = [];
      principais.forEach(function (r) { r.itens.forEach(function (i) { if (i.papel === papelDe[mac] && ALIM[i.id][mac] > 0) itens.push(i); }); });
      if (!itens.length) return;
      itens.forEach(function (i) {
        i.gramas = arred(i.id, i.gramas + (diff / itens.length) / (ALIM[i.id][mac] / 100));
        i.macros = macrosDe(i.id, i.gramas);
      });
      refeicoes.forEach(function (r) { r.total = soma(r.itens.map(function (x) { return x.macros; })); });
    });
  }

  /* Texto de porção amigável: "2 ovos (100 g)" ou "150 g" */
  function porcao(id, gramas) {
    const a = ALIM[id];
    if (a.un) {
      const q = Math.round(gramas / a.un);
      return q + ' ' + a.unNome + (q > 1 ? 's' : '') + ' (' + gramas + ' g)';
    }
    return gramas + ' g';
  }

  const api = { doGrupo: doGrupo, prescricao: prescricao, estiloTreino: estiloTreino, listaObjetivos: listaObjetivos, EX: EX, EX_BY_ID: EX_BY_ID, GRUPOS: GRUPOS, ALIM: ALIM, REF: REF, metas: metas, montarTreino: montarTreino, montarDieta: montarDieta, alternativas: alternativas, porcao: porcao, macrosDe: macrosDe };
  if (typeof module !== 'undefined' && module.exports) module.exports = api;
  root.Forja = api;
})(typeof window !== 'undefined' ? window : globalThis);
