/* Forja — interface. Depende de logic.js (window.Forja). */
(function () {
  'use strict';
  const F = window.Forja;
  const $view = document.getElementById('view');
  const $layer = document.getElementById('layer');
  const $tag = document.getElementById('tag');

  /* ---------- Utilidades ---------- */
  const esc = function (s) { return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) { return ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[c]; }); };
  const fmt = function (n, d) { return Number(n).toLocaleString('pt-BR', { minimumFractionDigits: d || 0, maximumFractionDigits: d || 0 }); };
  const hojeISO = function () { const d = new Date(); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); };
  const dataBR = function (iso) { const p = String(iso).slice(0, 10).split('-'); return p[2] + '/' + p[1] + '/' + p[0]; };
  const clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  const ls = {
    get: function (k) { try { return JSON.parse(localStorage.getItem(k)); } catch (e) { return null; } },
    set: function (k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) { /* sem armazenamento local */ } }
  };
  function toast(msg) {
    const t = document.createElement('div');
    t.className = 'toast'; t.textContent = msg; t.setAttribute('role', 'status');
    document.body.appendChild(t);
    setTimeout(function () { t.remove(); }, 2600);
  }
  // Fotos: as do catálogo principal vêm no app; as do catálogo extra, da internet (Free Exercise DB, domínio público)
  const FEDB = 'https://raw.githubusercontent.com/yuhonas/free-exercise-db/main/exercises/';
  function imgs(id, big) {
    const e = window.Forja && window.Forja.EX_BY_ID[id];
    if (e && e.criado) return '<div class="anim criado' + (big ? ' big' : '') + '" aria-hidden="true"><span>' + esc((e.nome || '?').charAt(0)) + '</span></div>';
    const src = function (n) { return e && e.extra ? FEDB + encodeURIComponent(id) + '/' + n + '.jpg' : 'img/' + esc(id) + '_' + n + '.jpg'; };
    return '<div class="anim' + (big ? ' big' : '') + '"><img src="' + src(0) + '" alt="" loading="lazy"><img src="' + src(1) + '" alt="" loading="lazy"></div>';
  }
  // Dica curta para listas: a do catálogo principal, ou o nome original do exercício extra
  function dicaDe(e) { return e.dica || (e.extra ? 'Em inglês: ' + e.nomeEn : ''); }

  /* ---------- Armazenamento: banco do artefato (por pessoa) ou, sem ele, só este navegador ---------- */
  const Store = {
    modo: 'local', db: null, uid: null, fila: Promise.resolve(),
    init: async function () {
      try {
        if (typeof claude === 'undefined' || !claude.use) return;
        const limite = new Promise(function (r) { setTimeout(function () { r(null); }, 10000); });
        const res = await Promise.all([Promise.race([claude.use('db'), limite]), Promise.race([claude.use('user'), limite])]);
        const db = res[0], user = res[1];
        if (!db || !user) return;
        const id = await user.id();
        if (!id) return;
        this.db = db; this.uid = id; this.modo = 'db';
      } catch (e) { /* segue no modo local */ }
    },
    ref: function () { return this.db.doc('data/users/' + this.uid + '/forja'); },
    getPerfil: async function () {
      if (this.modo === 'db') { const s = await this.ref().get(); return s.exists ? clone(s.data()) : null; }
      return ls.get('forja.perfil');
    },
    // Uma gravação por vez no mesmo documento
    savePerfil: function (obj) {
      const dados = clone(obj);
      const self = this;
      this.fila = this.fila.then(function () {
        if (self.modo === 'db') return self.ref().set(dados);
        ls.set('forja.perfil', dados);
      }).catch(function (e) { toast('Não consegui salvar. Tente de novo.'); console.error(e); });
      return this.fila;
    },
    getLogs: async function () {
      if (this.modo === 'db') {
        const q = await this.ref().collection('treinos').orderBy('data', 'desc').limit(300).get();
        return q.docs.map(function (d) { return clone(d.data()); });
      }
      return ls.get('forja.treinos') || [];
    },
    addLog: async function (log) {
      if (this.modo === 'db') return this.ref().collection('treinos').doc(log.id).set(log);
      const l = ls.get('forja.treinos') || []; l.unshift(log); ls.set('forja.treinos', l);
    },
    delLog: async function (id) {
      if (this.modo === 'db') return this.ref().collection('treinos').doc(id).delete();
      ls.set('forja.treinos', (ls.get('forja.treinos') || []).filter(function (x) { return x.id !== id; }));
    }
  };

  /* ---------- Estado ---------- */
  const S = {
    perfil: null, logs: [], aba: 'treino', dia: null, rascunho: ls.get('forja.rascunho') || {},
    abertas: {}, onb: { passo: 0, r: {} }, descanso: null, trocaDieta: null, exSel: null
  };
  function salvarRascunho() { ls.set('forja.rascunho', S.rascunho); }

  /* ---------- Questionário ---------- */
  const PASSOS = [
    { t: 'Sobre você', campos: ['sexo', 'idade', 'altura', 'peso'] },
    { t: 'Seus objetivos', campos: ['objetivos'] },
    { t: 'Sua rotina de treino', campos: ['nivel', 'dias', 'diasSemana', 'tempo'] },
    { t: 'Como você quer treinar', campos: ['divisao', 'metodo', 'estilo'] },
    { t: 'Onde e como você treina', campos: ['equip', 'trabalho'] },
    { t: 'Alimentação', campos: ['refeicoes'] }
  ];
  const OPC = {
    sexo: [['M', 'Masculino'], ['F', 'Feminino']],
    objetivos: [['emagrecer', 'Emagrecer', 'Perder gordura (déficit de 20%)'], ['definir', 'Definir', 'Déficit leve de 10%, mantendo massa'], ['massa', 'Ganhar massa', 'Hipertrofia (superávit de 10%)'], ['forca', 'Ficar mais forte', 'Cargas altas e poucas repetições']],
    nivel: [['iniciante', 'Iniciante', 'Menos de 6 meses treinando'], ['intermediario', 'Intermediário', '6 meses a 2 anos'], ['avancado', 'Avançado', 'Mais de 2 anos']],
    dias: [[2, '2'], [3, '3'], [4, '4'], [5, '5'], [6, '6']],
    tempo: [[30, '30 min'], [45, '45 min'], [60, '60 min'], [75, '75 min'], [90, '90 min']],
    equip: [['gym', 'Academia completa', 'Máquinas, barras, polias e halteres'], ['db', 'Em casa com halteres', 'Halteres e um banco ou cadeira firme'], ['bw', 'Em casa sem equipamento', 'Só o peso do corpo']],
    trabalho: [['sentado', 'Sentado a maior parte do dia'], ['em_pe', 'Em pé ou andando bastante'], ['pesado', 'Trabalho físico pesado']],
    refeicoes: [[3, '3'], [4, '4'], [5, '5'], [6, '6']],
    diasSemana: [['1', 'Seg'], ['2', 'Ter'], ['3', 'Qua'], ['4', 'Qui'], ['5', 'Sex'], ['6', 'Sáb'], ['0', 'Dom']],
    divisao: [['auto', 'Automática', 'O Forja escolhe pela quantidade de dias (3 dias = corpo inteiro)'], ['abc', 'ABC clássico', 'A: peito, ombro e tríceps · B: costas e bíceps · C: pernas']],
    estilo: [['misto', 'Misto', 'Alterna pesos livres e máquinas'], ['maquinas', 'Mais máquinas', 'Máquinas, polias e Smith primeiro'], ['livres', 'Mais pesos livres', 'Barras e halteres primeiro']],
    metodo: [['normal', 'Tradicional', 'Descanso depois de cada série'], ['trinca', 'Trinca', '3 exercícios seguidos, sem descanso entre eles. Descansa só no fim. Treino mais rápido e intenso']]
  };
  const ROT = { idade: 'Idade (anos)', altura: 'Altura (cm)', peso: 'Peso (kg)', sexo: 'Sexo', objetivos: 'Objetivos (escolha um ou mais)', nivel: 'Nível', dias: 'Treinos por semana', tempo: 'Tempo por treino', equip: 'Equipamento', trabalho: 'No dia a dia você fica', refeicoes: 'Refeições por dia', divisao: 'Divisão do treino', diasSemana: 'Em quais dias você treina', metodo: 'Método', estilo: 'Preferência de equipamento (academia)' };
  const LIM_NUM = { idade: [14, 90], altura: [130, 220], peso: [35, 250] };
  const MULTI = { objetivos: true, diasSemana: true }; // campos em que dá para marcar mais de uma opção

  function renderOnb(erro) {
    const p = PASSOS[S.onb.passo], r = S.onb.r;
    let h = '<div class="stack">';
    if (S.onb.passo === 0 && !S.perfil) {
      h += '<div class="card stack"><h2>Vamos montar seu plano</h2><p class="muted" style="margin:0">Cinco perguntas rápidas. Com elas o Forja calcula suas calorias e macros e monta a divisão de treino.</p></div>';
    }
    h += '<div class="card stack"><div class="row between"><h3>' + esc(p.t) + '</h3><span class="muted small num">' + (S.onb.passo + 1) + ' de ' + PASSOS.length + '</span></div>';
    p.campos.forEach(function (c) {
      if (LIM_NUM[c]) {
        h += '<label class="f" for="in-' + c + '">' + ROT[c] + '<input class="in num" id="in-' + c + '" data-campo="' + c + '" type="number" inputmode="decimal" step="' + (c === 'peso' ? '0.1' : '1') + '" value="' + esc(r[c] || '') + '"></label>';
      } else {
        const opts = OPC[c];
        const comDesc = opts[0].length > 2 || c === 'trabalho';
        h += '<div class="stack" style="gap:8px"><span class="small muted" style="font-weight:600">' + ROT[c] + '</span>';
        if (comDesc) {
          opts.forEach(function (o) {
            const on = MULTI[c] ? (r[c] || []).indexOf(o[0]) >= 0 : String(r[c]) === String(o[0]);
            h += '<button type="button" class="opt' + (on ? ' on' : '') + '" data-act="onb-opt" data-campo="' + c + '" data-v="' + o[0] + '" aria-pressed="' + on + '"><b>' + (MULTI[c] ? (on ? '☑ ' : '☐ ') : '') + esc(o[1]) + '</b>' + (o[2] ? '<span>' + esc(o[2]) + '</span>' : '') + '</button>';
          });
        } else {
          h += '<div class="chips">';
          opts.forEach(function (o) { const on = MULTI[c] ? (r[c] || []).indexOf(o[0]) >= 0 : String(r[c]) === String(o[0]); h += '<button type="button" class="chip' + (on ? ' on' : '') + '" data-act="onb-opt" data-campo="' + c + '" data-v="' + o[0] + '" aria-pressed="' + on + '">' + esc(o[1]) + '</button>'; });
          h += '</div>';
        }
        h += '</div>';
      }
    });
    h += '<div class="err" id="onb-err">' + esc(erro || '') + '</div>';
    h += '<div class="row">';
    if (S.onb.passo > 0) h += '<button class="btn" data-act="onb-voltar">Voltar</button>';
    else if (S.perfil) h += '<button class="btn" data-act="onb-cancelar">Cancelar</button>';
    h += '<button class="btn primary grow" data-act="onb-seguir">' + (S.onb.passo === PASSOS.length - 1 ? 'Gerar meu plano' : 'Continuar') + '</button></div></div>';
    h += '<p class="note">O Forja é um app de uso pessoal e educativo. Ele não substitui médico, nutricionista ou profissional de educação física.</p></div>';
    $view.innerHTML = h;
    renderNav();
  }
  function lerNumeros() {
    document.querySelectorAll('input[data-campo]').forEach(function (i) { S.onb.r[i.dataset.campo] = i.value === '' ? '' : Number(String(i.value).replace(',', '.')); });
  }
  function validarPasso() {
    lerNumeros();
    const p = PASSOS[S.onb.passo];
    for (let i = 0; i < p.campos.length; i++) {
      const c = p.campos[i], v = S.onb.r[c];
      if (c === 'diasSemana') {
        if (!v || v.length !== Number(S.onb.r.dias)) return 'Escolha ' + S.onb.r.dias + ' dias da semana (você disse que treina ' + S.onb.r.dias + ' vezes).';
        continue;
      }
      if (v === '' || v == null || (MULTI[c] && !v.length)) return MULTI[c] ? 'Escolha pelo menos um objetivo.' : 'Preencha: ' + ROT[c].toLowerCase() + '.';
      if (LIM_NUM[c] && (v < LIM_NUM[c][0] || v > LIM_NUM[c][1])) return ROT[c] + ' deve ficar entre ' + LIM_NUM[c][0] + ' e ' + LIM_NUM[c][1] + '.';
    }
    return '';
  }
  async function concluirOnb() {
    const r = clone(S.onb.r);
    ['dias', 'tempo', 'refeicoes', 'idade', 'altura', 'peso'].forEach(function (k) { r[k] = Number(r[k]); });
    r.objetivo = r.objetivos[0]; // compatibilidade com versões antigas
    if (!r.diasSemana || r.diasSemana.length !== r.dias) r.diasSemana = diasPadrao(r.dias);
    if (S.perfil && String(F.listaObjetivos(S.perfil.resp)) !== String(r.objetivos)) r.ajusteKcal = 0; // objetivo novo: zera ajustes do check-in
    const novo = !S.perfil;
    const p = S.perfil || { pesos: [], trocasTreino: {}, trocasDieta: {}, criado: hojeISO() };
    // Mudou a divisão ou o equipamento: as trocas de exercício antigas deixam de valer
    if (!novo && (p.resp.dias !== r.dias || p.resp.equip !== r.equip || p.resp.tempo !== r.tempo || p.resp.divisao !== r.divisao || p.resp.metodo !== r.metodo || p.resp.estilo !== r.estilo || String(F.listaObjetivos(p.resp)) !== String(r.objetivos))) p.trocasTreino = {};
    p.resp = r;
    if (!p.pesos.length || p.pesos[p.pesos.length - 1].kg !== r.peso) registrarPesoNoPerfil(p, r.peso);
    S.perfil = p; S.dia = null; S.wdSel = null;
    await Store.savePerfil(p);
    S.aba = novo ? 'treino' : 'perfil';
    toast(novo ? 'Plano criado. Bora treinar!' : 'Plano atualizado');
    render();
  }
  function registrarPesoNoPerfil(p, kg) {
    const d = hojeISO();
    p.pesos = (p.pesos || []).filter(function (x) { return x.d !== d; });
    p.pesos.push({ d: d, kg: kg });
    p.pesos.sort(function (a, b) { return a.d < b.d ? -1 : 1; });
    p.pesos = p.pesos.slice(-400);
  }

  /* ---------- Navegação ---------- */
  const ICON = {
    treino: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><path d="M6 8v8M3 10v4M18 8v8M21 10v4M6 12h12"/></svg>',
    dieta: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="13" r="7"/><path d="M12 6V3M9 3h6"/></svg>',
    progresso: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 19h16M5 15l4-4 3 3 6-7"/></svg>',
    perfil: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round"><circle cx="12" cy="8" r="4"/><path d="M4 21c1.5-4 4.5-6 8-6s6.5 2 8 6"/></svg>',
    coach: '<svg viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" stroke-linecap="round" stroke-linejoin="round"><path d="M4 5h16v11H9l-5 4z"/><path d="M8 9h8M8 12h5"/></svg>'
  };
  const NOMES_ABA = { treino: 'Treino', dieta: 'Dieta', coach: 'Treinador', progresso: 'Progresso', perfil: 'Perfil' };
  function renderNav() {
    let nav = document.getElementById('tabs');
    if (!S.perfil || S.aba === 'onb') { if (nav) nav.remove(); return; }
    if (!nav) { nav = document.createElement('nav'); nav.id = 'tabs'; nav.className = 'tabs'; nav.setAttribute('aria-label', 'Seções'); document.body.appendChild(nav); }
    nav.innerHTML = '<div class="in">' + Object.keys(NOMES_ABA).map(function (k) {
      return '<button data-act="aba" data-aba="' + k + '" class="' + (S.aba === k ? 'on' : '') + '"' + (S.aba === k ? ' aria-current="page"' : '') + '>' + ICON[k] + NOMES_ABA[k] + '</button>';
    }).join('') + '</div>';
  }

  /* ---------- Treino ---------- */
  // Plano do app + exercícios que o usuário adicionou em cada dia
  /* ---------- Fichas da academia e número das máquinas ----------
     Números das máquinas da academia (tickets de 17/11/2026). O usuário pode editar em cada exercício. */
  const MAQ_PADRAO = { Butterfly: '4 ou 5', Reverse_Machine_Flyes: '4 ou 5', 'V-Bar_Pulldown': '8, 9 ou 11', Leverage_Iso_Row: '13', Standing_Biceps_Cable_Curl: '1, 2 ou 3' };
  // Fichas impressas pela academia, prontas para adicionar (sem nomes de pessoas). INT 1' = 60 s.
  const FICHAS_PRONTAS = [
    { id: 'm2', letra: '2', nome: 'Treino 2 adaptativo masculino', validade: '26/01/2027', itens: [
      ['Butterfly', 'Peck deck', '4 ou 5', 3, '10'], ['Reverse_Machine_Flyes', 'Crucifixo inverso máquina', '4 ou 5', 3, '10'],
      ['V-Bar_Pulldown', 'Puxador frente pegada neutra', '8, 9 ou 11', 3, '12'], ['Leverage_Iso_Row', 'Remada sentada máquina', '13', 3, '12'],
      ['Side_Lateral_Raise', 'Elevação lateral halteres', '', 3, '12–15'], ['Standing_Biceps_Cable_Curl', 'Rosca direta cross', '', 3, '12'],
      ['Triceps_Pushdown', 'Tríceps polia barra reta', '', 3, '12']] },
    { id: 'f2', letra: '2', nome: 'Treino 2 adaptativo feminino', validade: '26/01/2027', itens: [
      ['V-Bar_Pulldown', 'Puxador frente pegada neutra', '8, 9 ou 11', 3, '12–15'], ['Butterfly', 'Crucifixo máquina', '4 ou 5', 3, '12–15'],
      ['Side_Lateral_Raise', 'Elevação lateral halteres', '', 3, '12–15'], ['Triceps_Pushdown', 'Tríceps polia barra', '', 3, '12–15'],
      ['Standing_Biceps_Cable_Curl', 'Rosca na polia baixa', '1, 2 ou 3', 3, '12–15'], ['Crunches', 'Abd supra curto solo', '', 3, '12–15']] }
  ];
  function fichasAtivas() { return (S.perfil.fichas || []).filter(function (f) { return f.ativa !== false; }); }
  /* ---------- Exercícios criados (quando o catálogo não tem o da ficha) ---------- */
  function registrarCriados() {
    (S.perfil && S.perfil.exCriados || []).forEach(function (e) {
      if (F.EX_BY_ID[e.id]) return;
      const x = { id: e.id, nome: e.nome, g: e.g, eq: e.eq, c: 0, maq: !!e.maq, dica: e.dica || 'Exercício criado por você. Peça ao professor da academia para mostrar a execução.', extra: true, criado: true };
      F.EX.push(x); F.EX_BY_ID[x.id] = x;
    });
  }
  // Nome do ticket costuma vir em maiúsculas: deixa só a primeira letra maiúscula
  function nomeBonito(t) { t = String(t || '').trim().replace(/\s+/g, ' '); if (t && t === t.toUpperCase()) t = t.toLowerCase(); return t.charAt(0).toUpperCase() + t.slice(1); }
  const EQUIP_FICHA = { maquina: ['gym', 1], polia: ['gym', 1], barra: ['gym', 0], halteres: ['db', 0], corpo: ['bw', 0] };
  function criarExercicio(nome, g, equip) {
    S.perfil.exCriados = S.perfil.exCriados || [];
    const n = nomeBonito(nome).slice(0, 60);
    const igual = S.perfil.exCriados.find(function (e) { return norm(e.nome) === norm(n) && e.g === g; });
    if (igual) return igual.id; // mesmo exercício já criado antes
    const q = EQUIP_FICHA[equip] || ['gym', /polia|maquina|máquina|cross|puxador|leg|cadeira|mesa|smith/i.test(n) ? 1 : 0];
    const e = { id: 'u_' + Date.now().toString(36) + Math.floor(Math.random() * 1e4).toString(36), nome: n, g: F.GRUPOS[g] ? g : 'core', eq: q[0], maq: !!q[1] };
    S.perfil.exCriados.push(e);
    registrarCriados();
    return e.id;
  }
  function usaFichas() { return !!(S.perfil.usarFichas && fichasAtivas().length); }
  // Número da máquina: o que o usuário digitou > o da ficha > o padrão da academia
  function maquinaDe(it) {
    const m = S.perfil.maquinas || {};
    if (Object.prototype.hasOwnProperty.call(m, it.ex)) return m[it.ex];
    return it.maquina || MAQ_PADRAO[it.ex] || maqPorTipo(it.ex);
  }
  // Regra da academia: tudo que é na polia fica nas máquinas 1, 2 e 3; as puxadas, no puxador 8, 9 ou 11
  const PUXADOR = { 'Wide-Grip_Lat_Pulldown': 1, 'Close-Grip_Front_Lat_Pulldown': 1, Underhand_Cable_Pulldowns: 1, 'V-Bar_Pulldown': 1 };
  const NAO_POLIA = { Seated_Cable_Rows: 1 }; // remada baixa: estação própria, número ainda não informado
  function maqPorTipo(id) {
    if (PUXADOR[id]) return '8, 9 ou 11';
    const e = F.EX_BY_ID[id];
    if (!e || NAO_POLIA[id]) return '';
    if (/polia|pulley|crossover/i.test(e.nome) || /Cable|Pushdown|Pulley|Face_Pull|Pull_Through/.test(id)) return '1, 2 ou 3';
    return '';
  }
  function fichaParaDias(lista) {
    const tr = S.perfil.trocasTreino || {};
    return (lista || fichasAtivas()).map(function (f) {
      return { letra: f.letra, nome: f.nome, ficha: f.id, itens: f.itens.filter(function (x) { return F.EX_BY_ID[x.ex]; }).map(function (x, i) {
        const chave = 'f' + f.id + '_' + i;
        return { chave: chave, ex: tr[chave] && F.EX_BY_ID[tr[chave]] ? tr[chave] : x.ex, series: x.series, reps: x.reps, descanso: x.descanso, maquina: x.maquina, nomeFicha: x.nomeFicha };
      }) };
    });
  }
  // Fichas da academia nos dias delas; os outros dias o app monta, alternando parte de cima e pernas
  function semanaComFichas() {
    const r = S.perfil.resp;
    const n = (r.diasSemana && r.diasSemana.length) ? r.diasSemana.length : (Number(r.dias) || 3);
    // A primeira ficha fica no dia da semana em que foi adicionada (o dia em que você fez com o ticket na mão)
    const f0 = fichasAtivas()[0];
    let wd = f0.wd;
    if (wd == null) { const t = parseInt(String(f0.id).split('_').pop(), 36); wd = isFinite(t) ? new Date(t).getDay() : null; }
    const pos = agenda(new Array(n).fill(0)).findIndex(function (a) { return a.wd === wd; });
    return F.completarSemana(r, S.perfil.trocasTreino, fichaParaDias(), n, pos < 0 ? 0 : pos);
  }
  // Número livre para a ficha nova (o "2" do "Treino 2"; se já existir, usa o próximo)
  function letraLivre(pref) {
    const usadas = (S.perfil.fichas || []).map(function (f) { return f.letra; });
    let l = String(pref || '').match(/\d+/); l = l ? l[0] : '';
    if (l && usadas.indexOf(l) < 0) return l;
    for (let n = 1; n < 50; n++) if (usadas.indexOf(String(n)) < 0) return String(n);
    return String(Date.now() % 1000);
  }
  async function adicionarFicha(f) {
    S.perfil.fichas = S.perfil.fichas || [];
    f.id = f.id + '_' + Date.now().toString(36);
    f.letra = letraLivre(f.letra || f.nome);
    f.wd = new Date().getDay();
    S.perfil.fichas.push(f);
    S.perfil.usarFichas = true;
    S.perfil.maquinas = S.perfil.maquinas || {};
    f.itens.forEach(function (x) { if (x.maquina && !Object.prototype.hasOwnProperty.call(S.perfil.maquinas, x.ex)) S.perfil.maquinas[x.ex] = x.maquina; });
    await Store.savePerfil(S.perfil);
    S.wdSel = null;
  }

  function plano() {
    registrarCriados();
    const pl = usaFichas() ? semanaComFichas() : F.montarTreino(S.perfil.resp, S.perfil.trocasTreino);
    const emUso = {}; pl.forEach(function (d) { if (d.ficha) emUso[d.ficha] = 1; });
    const fora = fichaParaDias((S.perfil.fichas || []).filter(function (f) { return !emUso[f.id]; }));
    (S.perfil.treinosIA || []).forEach(function (t) {
      fora.push({ letra: 'IA', nome: t.nome, ia: t.id, itens: t.itens.map(function (x, k) { return { chave: 'i' + t.id + '_' + k, ex: x.ex, series: x.series, reps: x.reps, descanso: x.descanso }; }).filter(function (x) { return F.EX_BY_ID[x.ex]; }) });
    });
    fora.forEach(function (d) { d.fora = true; });
    pl.nRot = pl.length; // só os primeiros entram no rodízio da semana
    Array.prototype.push.apply(pl, fora);
    const ext = S.perfil.extrasTreino || {};
    pl.forEach(function (d) {
      // Reserva de hoje (máquina ocupada): troca o exercício só nesta sessão, mantendo séries e repetições
      const ht = (S.rascunho[d.letra] || {})._reserva || {};
      d.itens.forEach(function (it) { if (ht[it.chave] && F.EX_BY_ID[ht[it.chave]]) { it.exOriginal = it.ex; it.ex = ht[it.chave]; it.reserva = true; it.maquina = ''; it.nomeFicha = ''; } });
      (ext[d.letra] || []).forEach(function (id, i) {
        const ex = F.EX_BY_ID[id];
        if (!ex) return;
        const p = F.prescricao(ex, F.estiloTreino(S.perfil.resp), S.perfil.resp.nivel);
        d.itens.push({ chave: 'x' + d.letra + '_' + i, ex: id, series: p.series, reps: p.reps, descanso: p.descanso, extra: true });
      });
      d.itens.forEach(function (it) { if (it.extra && ht[it.chave] && !it.reserva && F.EX_BY_ID[ht[it.chave]]) { it.exOriginal = it.ex; it.ex = ht[it.chave]; it.reserva = true; } });
      // Exercícios que o usuário tirou do treino (até restaurar)
      const rem = S.perfil.removidosTreino || {};
      d.removidos = d.itens.filter(function (it) { return rem[d.letra + ':' + it.chave]; });
      d.itens = d.itens.filter(function (it) { return !rem[d.letra + ':' + it.chave]; });
      // Séries a mais ou a menos que o usuário escolheu em cada exercício
      const aj = S.perfil.seriesAjuste || {};
      d.itens.forEach(function (it) {
        const k = d.letra + ':' + it.chave;
        if (aj[k]) it.series = Math.min(8, Math.max(1, it.series + aj[k]));
        it.ajusteKey = k;
      });
    });
    return pl;
  }
  /* ---------- Agenda da semana ----------
     Os dias escolhidos, em ordem de segunda a domingo, recebem os treinos A, B, C… em sequência
     (se houver mais dias que treinos, a sequência recomeça). */
  const NOME_DIA = ['Domingo', 'Segunda', 'Terça', 'Quarta', 'Quinta', 'Sexta', 'Sábado'];
  const CURTO_DIA = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  function diasPadrao(n) {
    return ({ 1: ['3'], 2: ['2', '4'], 3: ['1', '3', '5'], 4: ['1', '2', '4', '5'], 5: ['1', '2', '3', '4', '5'], 6: ['1', '2', '3', '4', '5', '6'], 7: ['1', '2', '3', '4', '5', '6', '0'] })[n] || ['1', '3', '5'];
  }
  function agenda(pl) {
    const r = S.perfil.resp;
    let ds = (r.diasSemana && r.diasSemana.length) ? r.diasSemana : diasPadrao(Number(r.dias) || 3);
    ds = ds.map(Number).sort(function (a, b) { return ((a + 6) % 7) - ((b + 6) % 7); }); // segunda primeiro
    const n = pl.nRot || pl.length;
    const ag = ds.map(function (wd, i) { return { wd: wd, idx: i % n }; });
    // Troca do dia: num dia específico (falta, mudança), outro treino no lugar do previsto
    const tr = S.perfil.trocaDia || {};
    ag.forEach(function (a) { const k = tr[dataDoDia(a.wd)]; const i = k ? pl.findIndex(function (d) { return chaveDia(d) === k; }) : -1; if (i >= 0) { a.idxOriginal = a.idx; a.idx = i; a.trocado = true; } });
    return ag;
  }
  // Identificador estável de um treino: a ficha pelo id; os do app pela letra
  function chaveDia(d) { return d.ficha ? 'f:' + d.ficha : d.ia ? 'i:' + d.ia : 'a:' + d.letra; }
  // Data (AAAA-MM-DD) do dia da semana wd na semana atual (segunda a domingo)
  function dataDoDia(wd) {
    const d = new Date(); d.setHours(12, 0, 0, 0);
    d.setDate(d.getDate() - ((d.getDay() + 6) % 7) + ((wd + 6) % 7));
    return d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
  }
  // Sábado e domingo fora da agenda viram dias opcionais: aparecem para treinar se quiser
  function agendaTela(pl) {
    const ag = agenda(pl);
    const n = pl.nRot || pl.length;
    const ult = ag.length ? (ag[ag.length - 1].idxOriginal != null ? ag[ag.length - 1].idxOriginal : ag[ag.length - 1].idx) : -1;
    const esc_ = S.perfil.extraFds || {}, tr = S.perfil.trocaDia || {};
    [6, 0].forEach(function (wd) {
      if (ag.some(function (a) { return a.wd === wd; })) return;
      const k = tr[dataDoDia(wd)], it = k ? pl.findIndex(function (d) { return chaveDia(d) === k; }) : -1;
      const i = Number(esc_[wd]);
      ag.push({ wd: wd, idx: it >= 0 ? it : (i >= 0 && i < pl.length ? i : (ult + 1) % n), opcional: true, trocado: it >= 0 });
    });
    return ag;
  }
  function hojeWd() { return new Date().getDay(); }
  // Treino de hoje; num dia de descanso, o próximo da semana
  function proximoDia(pl) {
    const ag = agenda(pl), w = hojeWd();
    const hoje = ag.find(function (a) { return a.wd === w; });
    if (hoje) return hoje.idx;
    for (let k = 1; k <= 7; k++) { const a = ag.find(function (x) { return x.wd === (w + k) % 7; }); if (a) return a.idx; }
    return 0;
  }
  // Última vez que o exercício foi feito: série com mais carga
  function ultimaVez(exId) {
    for (let i = 0; i < S.logs.length; i++) {
      const it = (S.logs[i].itens || []).find(function (x) { return x.ex === exId; });
      if (it && it.series && it.series.length) {
        const best = it.series.reduce(function (a, b) { return (Number(b.kg) || 0) > (Number(a.kg) || 0) ? b : a; });
        return { data: S.logs[i].data, kg: Number(best.kg) || 0, reps: best.reps, series: it.series };
      }
    }
    return null;
  }
  // Últimas n sessões do exercício (mais recente primeiro), só séries com repetições
  function historico(exId, n) {
    const out = [];
    for (let i = 0; i < S.logs.length && out.length < n; i++) {
      const it = (S.logs[i].itens || []).find(function (x) { return x.ex === exId; });
      if (it && it.series && it.series.length) out.push({ data: S.logs[i].data, series: it.series });
    }
    return out;
  }
  // Faixa de repetições da prescrição: "8–12" -> {min:8,max:12}; "12" -> {min:12,max:12}
  function faixa(reps) {
    const n = String(reps || '').match(/\d+/g);
    if (!n) return null;
    const a = Number(n[0]), b = Number(n[n.length - 1]);
    return { min: Math.min(a, b), max: Math.max(a, b) };
  }
  /* Dupla progressão: sobe as repetições até o topo da faixa em todas as séries; aí sobe a carga e volta
     para o começo da faixa. Se ficar abaixo da faixa duas sessões seguidas com a mesma carga, reduz 10%.
     Devolve {kg, reps, motivo} ou null quando não há histórico. */
  function sugestao(it) {
    const h = historico(it.ex, 2), fx = faixa(it.reps);
    if (!h.length || !fx) return null;
    const ss = h[0].series;
    const kg = ss.reduce(function (m, x) { return Math.max(m, Number(x.kg) || 0); }, 0);
    const doPeso = ss.filter(function (x) { return (Number(x.kg) || 0) === kg; });
    const repsMin = doPeso.reduce(function (m, x) { return Math.min(m, Number(x.reps) || 0); }, 99);
    const ex = F.EX_BY_ID[it.ex] || {};
    const passo = ex.eq === 'db' ? 2 : 2.5;
    const fmtKg = function (v) { return fmt(v, v % 1 ? 1 : 0) + ' kg'; };
    if (kg <= 0) { // peso corporal: só repetições
      const alvo = Math.min(fx.max + 5, repsMin + 1);
      return { kg: '', reps: alvo, motivo: 'Peso do corpo: tente ' + alvo + ' repetições por série.' };
    }
    if (doPeso.length >= Math.min(ss.length, it.series) && repsMin >= fx.max) {
      const onde = ' (ou o próximo peso do aparelho)';
      return { kg: kg + passo, reps: fx.min, motivo: 'Fez ' + fx.max + (fx.max > fx.min ? '+' : '') + ' repetições em todas com ' + fmtKg(kg) + (ex.eq === 'db' ? ': pegue os halteres de ' + fmtKg(kg + passo) : ': suba para ' + fmtKg(kg + passo) + onde) + (fx.max > fx.min ? ' e volte para ' + fx.min + '.' : ' e mantenha ' + fx.min + '.') };
    }
    if (repsMin < fx.min) {
      const ant = h[1] && h[1].series.reduce(function (m, x) { return Math.max(m, Number(x.kg) || 0); }, 0) === kg &&
        h[1].series.some(function (x) { return (Number(x.kg) || 0) === kg && (Number(x.reps) || 0) < fx.min; });
      if (ant) {
        const novo = Math.max(passo, Math.round(kg * 0.9 / passo) * passo);
        return { kg: novo, reps: fx.min, motivo: 'Ficou abaixo de ' + fx.min + ' repetições duas vezes com ' + fmtKg(kg) + ': baixe para ' + fmtKg(novo) + ' e reconstrua.' };
      }
      return { kg: kg, reps: fx.min, motivo: 'Mesma carga (' + fmtKg(kg) + '): tente chegar a ' + fx.min + ' repetições em todas.' };
    }
    const alvo = Math.min(fx.max, repsMin + 1);
    return { kg: kg, reps: alvo, motivo: 'Mesma carga (' + fmtKg(kg) + '): tente ' + alvo + ' repetições por série. Ao fazer ' + fx.max + ' em todas, a carga sobe.' };
  }
  function rascunhoDia(letra) { S.rascunho[letra] = S.rascunho[letra] || {}; return S.rascunho[letra]; }

  function renderTreino() {
    const pl = plano();
    const sug = proximoDia(pl), ag = agendaTela(pl), w = hojeWd();
    const treinaHoje = ag.some(function (a) { return a.wd === w && !a.opcional; });
    if (S.wdSel == null) S.wdSel = treinaHoje ? w : (ag.find(function (a) { return !a.opcional && a.idx === sug; }) || ag[0]).wd;
    const sel = ag.find(function (a) { return a.wd === S.wdSel; }) || ag[0];
    S.dia = sel.idx;
    const dia = pl[S.dia];
    const rd = rascunhoDia(dia.letra);
    let h = '<div class="stack">';
    h += '<div class="days" role="tablist">' + ag.map(function (a) {
      const d = pl[a.idx], on = a.wd === S.wdSel;
      return '<button class="day' + (on ? ' on' : '') + '" data-act="dia-sem" data-w="' + a.wd + '" role="tab" aria-selected="' + on + '">' + (a.wd === w ? '<div class="next">Hoje</div>' : '<div class="next" style="visibility:hidden">.</div>') + '<b>' + CURTO_DIA[a.wd] + '</b><span>' + (a.opcional ? 'Opcional' : 'Treino ' + d.letra) + '</span></button>';
    }).join('') + '</div>';
    if (sel.opcional) {
      h += '<div class="card stack" style="border-color:var(--ember)"><b>' + NOME_DIA[sel.wd] + ' é opcional</b><span class="small muted">Não está na sua semana de treino, mas dá para treinar. ' + (pl.length > 1 ? 'Para escolher outro treino, toque em Trocar treino do dia.' : '') + '</span>' +
        '</div>';
    }
    const feitoHoje = S.logs.some(function (l) { return l.data.slice(0, 10) === hojeISO(); });
    if (!treinaHoje && !sel.opcional) {
      const prox = ag.find(function (a) { return !a.opcional && a.idx === sug && a.wd !== w; }) || ag[0];
      h += '<div class="card stack" style="border-color:var(--ok)"><h3>Hoje (' + NOME_DIA[w].toLowerCase() + ') é dia de descanso</h3><p class="small muted" style="margin:0">Próximo treino: <b>' + NOME_DIA[prox.wd] + ' · Treino ' + pl[prox.idx].letra + '</b>. Um cardio leve ou caminhada ajuda na recuperação. Se quiser treinar mesmo assim, escolha o dia acima.</p></div>';
    } else if (feitoHoje && S.wdSel === w) {
      h += '<div class="card" style="border-color:var(--ok)"><b>Treino de hoje concluído.</b> <span class="small muted">Bom trabalho! O próximo aparece no dia dele.</span></div>';
    }
    // Trocar o treino deste dia (faltou, quer adiantar, quer fazer uma ficha salva)
    if (S.trocandoDia) {
      h += '<div class="card stack" style="border-color:var(--ember)"><div class="row between"><b>Qual treino fazer ' + (S.wdSel === w ? 'hoje' : 'na ' + NOME_DIA[S.wdSel].toLowerCase()) + '?</b><button class="btn sm ghost" data-act="trocadia-fechar">Fechar</button></div>';
      pl.forEach(function (d, i) {
        const prev = sel.idxOriginal != null ? sel.idxOriginal : (sel.trocado ? -1 : sel.idx);
        h += '<button class="alt" data-act="trocadia" data-k="' + esc(chaveDia(d)) + '" data-orig="' + (i === prev ? '1' : '') + '"' + (i === S.dia ? ' style="border-color:var(--ember)"' : '') + '><span><b>Treino ' + esc(d.letra) + '</b> · ' + esc(d.nome) + (i === prev ? ' <span class="small" style="color:var(--ember)">(previsto)</span>' : '') + (d.fora ? ' <span class="small muted">(' + (d.ia ? 'montado pelo treinador' : 'ficha salva, fora da semana') + ')</span>' : '') + '<br><span class="small muted">' + d.itens.length + ' exercícios · ' + esc(d.itens.slice(0, 3).map(function (it) { return F.EX_BY_ID[it.ex].nome; }).join(', ')) + (d.itens.length > 3 ? '…' : '') + '</span></span></button>';
      });
      h += '<p class="note">A troca vale só para ' + (S.wdSel === w ? 'hoje' : 'esta ' + NOME_DIA[S.wdSel].toLowerCase()) + '. O resto da semana continua igual.</p></div>';
    }
    const pulados = rd._pulados || {};
    const totalSeries = dia.itens.reduce(function (a, it) { return a + (pulados[it.chave] ? 0 : it.series); }, 0);
    const feitas = dia.itens.reduce(function (a, it) { return a + ((rd[it.chave] || []).filter(function (s) { return s && s.ok; }).length); }, 0);
    h += '<div class="card"><div class="row between"><div class="row" style="gap:10px;align-items:center">' + corpoSVG(niveisRelativos(cargaMusculos(dia.itens.filter(function (it) { return !pulados[it.chave]; }))), true, false) + '<div><h2>' + NOME_DIA[S.wdSel] + ' · Treino ' + dia.letra + '</h2><div class="muted">' + esc(dia.nome) + '</div></div></div><div style="text-align:right"><div class="big num">' + feitas + '<span class="muted" style="font-size:18px">/' + totalSeries + '</span></div><div class="small muted">séries feitas</div></div></div>';
    h += '<div class="bar" style="margin-top:12px"><i style="width:' + (totalSeries ? Math.round(feitas / totalSeries * 100) : 0) + '%"></i></div>';
    h += '<div class="row between" style="margin-top:10px">' + (sel.trocado ? '<span class="small" style="color:var(--ember)">Treino trocado para este dia</span>' : '<span></span>') + '<button class="btn sm" data-act="trocadia-abrir">' + (S.trocandoDia ? 'Escolhendo…' : 'Trocar treino do dia') + '</button></div></div>';
    dia.itens.forEach(function (it) {
      if (it.bloco && it.posBloco === 1) {
        const ultimo = dia.itens.filter(function (x) { return x.bloco === it.bloco; }).slice(-1)[0];
        h += '<div class="card" style="border-color:var(--ember);background:var(--ember-soft)"><h3 style="color:var(--ember)">' + (it.tamBloco === 3 ? 'Trinca ' : 'Bloco ') + it.bloco + '</h3><div class="small">Faça 1 série de cada exercício em sequência, sem descanso. Depois do último, descanse ' + ultimo.descanso + ' s e repita. ' + it.series + ' voltas no total.</div></div>';
      }
      const ex = F.EX_BY_ID[it.ex];
      if (pulados[it.chave]) {
        h += '<article class="card" style="opacity:.6"><div class="row between"><div><b>' + esc(ex.nome) + '</b><div class="small muted">Pulado hoje</div></div><button class="btn sm" data-act="despular-ex" data-k="' + it.chave + '">Desfazer</button></div></article>';
        return;
      }
      const ult = ultimaVez(it.ex);
      const sug = sugestao(it);
      const linhas = rd[it.chave] || [];
      h += '<article class="card ex"><div class="head">' + imgs(it.ex) + '<div class="stack" style="gap:2px"><h3>' + esc(ex.nome) + '</h3>' + linhaMaquina(it) + '<div class="meta">' + esc(F.GRUPOS[ex.g]) + (it.nomeFicha && it.nomeFicha.toLowerCase() !== ex.nome.toLowerCase() ? ' · na ficha: ' + esc(it.nomeFicha) : '') + '</div><div class="pres num">' + it.series + ' × ' + esc(it.reps) + '</div><div class="meta">' + (it.bloco ? it.posBloco + 'º da trinca · ' : '') + (it.descanso ? 'Descanso ' + it.descanso + ' s' : 'Sem descanso: vá direto ao próximo') + '</div>' + (ult ? '<div class="last num">Última vez (' + dataBR(ult.data) + '): ' + fmt(ult.kg, 1) + ' kg × ' + esc(ult.reps) + '</div>' : '') + (sug ? '<div class="sug"><b>Hoje: ' + (sug.kg !== '' ? fmt(sug.kg, sug.kg % 1 ? 1 : 0) + ' kg × ' : '') + sug.reps + '</b> · ' + esc(sug.motivo) + '</div>' : '') + (it.reserva ? '<div class="small" style="color:var(--ember)">Reserva de hoje no lugar de ' + esc(F.EX_BY_ID[it.exOriginal].nome) + '</div>' : '') + '</div></div>';
      h += '<div class="sets"><div class="lbl"><span>Série</span><span>Kg</span><span>Reps</span><span>Feita</span></div>';
      for (let s = 0; s < it.series; s++) {
        const v = linhas[s] || {};
        // Em cinza: a sugestão de hoje (ou, sem sugestão, o que foi feito da última vez). Marcar ✓ com o campo vazio usa esse valor.
        const phKg = sug ? sug.kg : (ult && ult.series[s] ? ult.series[s].kg : '');
        const phRp = sug ? sug.reps : (ult && ult.series[s] ? ult.series[s].reps : '');
        h += '<div class="set' + (v.ok ? ' done' : '') + '"><span class="n num">' + (s + 1) + '</span>' +
          '<input class="num" id="kg-' + it.chave + '-' + s + '" aria-label="Carga da série ' + (s + 1) + ' em kg" type="number" inputmode="decimal" step="0.5" data-set="kg" data-k="' + it.chave + '" data-s="' + s + '" value="' + esc(v.kg != null ? v.kg : '') + '" placeholder="' + esc(phKg) + '">' +
          '<input class="num" id="rp-' + it.chave + '-' + s + '" aria-label="Repetições da série ' + (s + 1) + '" type="number" inputmode="numeric" data-set="reps" data-k="' + it.chave + '" data-s="' + s + '" value="' + esc(v.reps != null ? v.reps : '') + '" placeholder="' + esc(phRp) + '">' +
          '<button class="ok' + (v.ok ? ' on' : '') + '" data-act="serie" data-k="' + it.chave + '" data-s="' + s + '" data-d="' + it.descanso + '" aria-label="Marcar série ' + (s + 1) + ' como feita" aria-pressed="' + (!!v.ok) + '"><svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="3" stroke-linecap="round" stroke-linejoin="round"><path d="M5 12l5 5 9-10"/></svg></button></div>';
      }
      h += '<div class="row" style="gap:6px;justify-content:flex-end"><button class="btn sm ghost" data-act="serie-menos" data-a="' + esc(it.ajusteKey) + '"' + (it.series <= 1 ? ' disabled' : '') + ' aria-label="Uma série a menos">− série</button><button class="btn sm ghost" data-act="serie-mais" data-a="' + esc(it.ajusteKey) + '"' + (it.series >= 8 ? ' disabled' : '') + ' aria-label="Uma série a mais">+ série</button></div>';
      h += '</div><div class="tools"><button class="btn sm" data-act="como" data-k="' + it.chave + '">' + (S.abertas[it.chave] ? 'Fechar dica' : 'Como fazer') + '</button><button class="btn sm" data-act="trocar-ex" data-k="' + it.chave + '" data-ex="' + it.ex + '">Trocar</button><button class="btn sm" data-act="ocupada" data-k="' + it.chave + '" data-ex="' + (it.exOriginal || it.ex) + '">' + (it.reserva ? 'Voltar ao original' : 'Máquina ocupada') + '</button><button class="btn sm" data-act="pular-ex" data-k="' + it.chave + '">Pular hoje</button>' + (it.extra ? '<button class="btn sm ghost" data-act="remover-ex" data-k="' + it.chave + '">Remover</button>' : '<button class="btn sm ghost" data-act="tirar-ex" data-k="' + it.chave + '">Tirar do treino</button>') + '</div>';
      if (S.abertas[it.chave]) h += '<div class="dica">' + imgs(it.ex, true) + comoFazer(ex) + '</div>';
      h += '</article>';
    });
    if (dia.removidos && dia.removidos.length) h += '<div class="card stack"><div class="small muted">Tirados deste treino:</div>' + dia.removidos.map(function (it) { return '<div class="row between"><span>' + esc(F.EX_BY_ID[it.ex].nome) + '</span><button class="btn sm ghost" data-act="restaurar-ex" data-k="' + it.chave + '">Restaurar</button></div>'; }).join('') + '</div>';
    h += '<div class="row"><button class="btn grow" data-act="add-ex">+ Adicionar exercício</button><button class="btn grow" data-act="foto-aparelho">Foto do aparelho</button></div><input type="file" id="aparelho-in" accept="image/*" capture="environment" hidden>';
    h += renderAparelho(dia.letra);
    h += '<button class="btn primary block" data-act="finalizar"' + (feitas ? '' : ' disabled') + '>Finalizar treino ' + dia.letra + '</button>';
    if (feitas || Object.keys(rd).length) h += '<button class="btn ghost block" data-act="descartar-treino">Descartar marcações deste treino</button>';
    if (S.logs.length) h += '<p class="note">Salvou um treino por engano? Apague em Progresso → Treinos → Apagar.</p>';
    h += renderFichas();
    h += renderCardio();
    h += '<p class="note">Imagens: Free Exercise DB (domínio público). Os campos em cinza mostram o que você fez da última vez.</p></div>';
    $view.innerHTML = h;
  }

  function marcarSerie(k, s, descanso) {
    const pl = plano(), dia = pl[S.dia], rd = rascunhoDia(dia.letra);
    rd[k] = rd[k] || [];
    const v = rd[k][s] || {};
    if (!rd._inicio) rd._inicio = Date.now(); // hora em que o treino começou (para a duração no Strava)
    // Campos vazios herdam o que foi feito da última vez (o valor em cinza)
    const kgIn = document.getElementById('kg-' + k + '-' + s), rpIn = document.getElementById('rp-' + k + '-' + s);
    if (!v.ok) {
      if (kgIn && kgIn.value === '' && kgIn.placeholder !== '') v.kg = Number(kgIn.placeholder);
      if (rpIn && rpIn.value === '' && rpIn.placeholder !== '') v.reps = Number(rpIn.placeholder);
    }
    v.ok = !v.ok;
    rd[k][s] = v;
    salvarRascunho();
    if (v.ok && descanso > 0) iniciarDescanso(descanso);
    render();
  }

  async function finalizarTreino() {
    const pl = plano(), dia = pl[S.dia], rd = rascunhoDia(dia.letra);
    const itens = [];
    dia.itens.forEach(function (it) {
      const ss = (rd[it.chave] || []).filter(function (x) { return x && x.ok; }).map(function (x) { return { kg: Number(x.kg) || 0, reps: Number(x.reps) || 0 }; });
      if (ss.length) itens.push({ ex: it.ex, series: ss });
    });
    if (!itens.length) return;
    const vol = itens.reduce(function (a, it) { return a + it.series.reduce(function (b, s) { return b + s.kg * s.reps; }, 0); }, 0);
    const nSeries = itens.reduce(function (a, it) { return a + it.series.length; }, 0);
    // Duração: da primeira série marcada até agora; sem esse registro, ~2,5 min por série
    const inicio = rd._inicio && Date.now() - rd._inicio < 5 * 3600e3 ? rd._inicio : Date.now() - nSeries * 150e3;
    const log = { id: Date.now().toString(36), data: new Date().toISOString(), inicio: new Date(inicio).toISOString(), letra: dia.letra, nome: dia.nome, itens: itens, volume: Math.round(vol) };
    try {
      await Store.addLog(log);
      S.logs.unshift(log);
      delete S.rascunho[dia.letra]; salvarRascunho();
      pararDescanso();
      S.wdSel = null;
      toast('Treino ' + dia.letra + ' salvo. Volume: ' + fmt(vol) + ' kg');
      render();
    } catch (e) { toast('Não consegui salvar o treino. Tente de novo.'); return; }
    if (stravaLigado() && (S.perfil.strava || {}).autoTreino !== false) enviarTreinoStrava(log, true);
  }

  /* Cronômetro de descanso */
  function iniciarDescanso(seg) {
    pararDescanso();
    S.descanso = { fim: Date.now() + seg * 1000 };
    S.descanso.timer = setInterval(desenharDescanso, 250);
    desenharDescanso();
  }
  function pararDescanso() {
    if (S.descanso) clearInterval(S.descanso.timer);
    S.descanso = null;
    const el = document.getElementById('rest'); if (el) el.remove();
  }
  function desenharDescanso() {
    if (!S.descanso) return;
    const rest = Math.max(0, Math.ceil((S.descanso.fim - Date.now()) / 1000));
    let el = document.getElementById('rest');
    if (!el) { el = document.createElement('div'); el.id = 'rest'; el.className = 'rest'; document.body.appendChild(el); }
    if (rest === 0) {
      el.innerHTML = '<div class="in" role="status"><span class="t">0:00</span><span class="grow" style="font-weight:700">Descanso acabou. Próxima série!</span><button class="btn sm" data-act="desc-fim">Ok</button></div>';
      clearInterval(S.descanso.timer);
      if (navigator.vibrate) { try { navigator.vibrate([200, 100, 200]); } catch (e) { /* sem vibração */ } }
      return;
    }
    el.innerHTML = '<div class="in" role="timer"><span class="t num">' + Math.floor(rest / 60) + ':' + String(rest % 60).padStart(2, '0') + '</span><span class="grow" style="font-weight:700">Descansando</span><button class="btn sm" data-act="desc-mais">+15 s</button><button class="btn sm" data-act="desc-fim">Pular</button></div>';
  }

  // Máquina ocupada: mostra opções do mesmo músculo em outro aparelho ou com peso livre
  function abrirReserva(k, exId) {
    const orig = F.EX_BY_ID[exId];
    const mOrig = maquinaDe({ ex: exId });
    const alts = F.alternativas(exId, S.perfil.resp.equip, 'misto').map(function (e) { return { e: e, m: maquinaDe({ ex: e.id }) }; })
      .filter(function (x) { return !mOrig || x.m !== mOrig; })
      .sort(function (a, b) { return (a.e.eq === 'gym' ? 1 : 0) - (b.e.eq === 'gym' ? 1 : 0); }); // peso livre primeiro: costuma estar livre
    let h = '<div class="sheet-bg" data-act="fechar-sheet"><div class="sheet stack" role="dialog" aria-modal="true" aria-label="Máquina ocupada"><div class="row between"><h3>' + esc(orig.nome) + ' ocupada</h3><button class="btn sm" data-act="fechar-sheet">Fechar</button></div><p class="small muted" style="margin:0">Troca só no treino de hoje, com as mesmas séries e repetições. Amanhã volta o original.</p>';
    if (!alts.length) h += '<p class="muted">Não achei outro exercício deste músculo em outro aparelho.</p>';
    alts.slice(0, 12).forEach(function (x) {
      h += '<button class="alt" data-act="reserva-ex" data-k="' + k + '" data-ex="' + x.e.id + '">' + imgs(x.e.id) + '<span><b>' + esc(x.e.nome) + '</b><br><span class="small muted">' + (x.m ? 'Máquina ' + esc(x.m) : (x.e.eq === 'db' ? 'Halteres' : x.e.eq === 'bw' ? 'Peso do corpo' : 'Aparelho')) + '</span></span></button>';
    });
    h += '</div></div>';
    $layer.innerHTML = h;
  }

  function abrirTrocaEx(k, exId) {
    const alts = F.alternativas(exId, S.perfil.resp.equip, S.perfil.resp.estilo);
    let h = '<div class="sheet-bg" data-act="fechar-sheet"><div class="sheet stack" role="dialog" aria-modal="true" aria-label="Trocar exercício"><div class="row between"><h3>Trocar ' + esc(F.EX_BY_ID[exId].nome) + '</h3><button class="btn sm" data-act="fechar-sheet">Fechar</button></div>';
    if (!alts.length) h += '<p class="muted">Não há outro exercício deste grupo para o seu equipamento.</p>';
    alts.forEach(function (e) {
      h += '<button class="alt" data-act="escolher-ex" data-k="' + k + '" data-ex="' + e.id + '">' + imgs(e.id) + '<span><b>' + esc(e.nome) + '</b><br><span class="small muted">' + esc(dicaDe(e)) + '</span></span></button>';
    });
    h += '</div></div>';
    $layer.innerHTML = h;
  }

  /* Como fazer: dica pronta (catálogo principal) ou passos do catálogo extra, traduzidos pela IA na primeira vez e guardados no aparelho */
  function comoFazer(ex) {
    if (!ex.extra) return '<p style="margin:10px 0 0">' + esc(ex.dica) + '</p>';
    let pt = null;
    try { pt = JSON.parse(localStorage.getItem('forja.passos.' + ex.id) || 'null'); } catch (e) { pt = null; }
    const passos = pt || ex.passos;
    let h = '<ol class="small" style="margin:10px 0 0;padding-left:20px">' + passos.map(function (p) { return '<li>' + esc(p) + '</li>'; }).join('') + '</ol>';
    if (!pt) h += S.traduzindo === ex.id ? '<p class="small muted">Traduzindo…</p>' : '<button class="btn sm" style="margin-top:8px" data-act="traduzir-passos" data-ex="' + ex.id + '">Traduzir para português</button>';
    return h;
  }
  async function traduzirPassos(id) {
    const ex = F.EX_BY_ID[id];
    S.traduzindo = id; render();
    try {
      const r = await X.traduzir(ex.passos);
      if (r && r.length) localStorage.setItem('forja.passos.' + id, JSON.stringify(r));
    } catch (e) { toast(e.message || 'Não consegui traduzir agora.'); }
    S.traduzindo = null; render();
  }
  // Número da máquina no card do exercício (toque para editar)
  function linhaMaquina(it) {
    if (S.maqEdit === it.chave) {
      return '<div class="row" style="gap:6px;margin:2px 0"><input id="maq-in" aria-label="Número da máquina" maxlength="30" value="' + esc(maquinaDe(it)) + '" placeholder="ex.: 4 ou 5" style="max-width:130px"><button class="btn sm primary" data-act="maq-salvar" data-ex="' + it.ex + '">Salvar</button><button class="btn sm ghost" data-act="maq-cancelar" aria-label="Cancelar">×</button></div>';
    }
    const m = maquinaDe(it);
    return '<button class="maq' + (m ? ' on' : '') + '" data-act="maq-editar" data-k="' + it.chave + '" aria-label="' + (m ? 'Máquina ' + esc(m) + ', toque para editar' : 'Adicionar número da máquina') + '">' + (m ? 'Máquina ' + esc(m) : '+ nº da máquina') + '</button>';
  }

  /* ---------- Fichas da academia ---------- */
  function renderFichas() {
    const fs = S.perfil.fichas || [];
    let h = '<div class="card stack"><div class="row between"><h3>Ficha da academia</h3>' + (fs.length ? '<label class="row small" style="gap:6px"><input type="checkbox" data-act="fichas-usar"' + (S.perfil.usarFichas ? ' checked' : '') + '> Usar no treino</label>' : '') + '</div>';
    if (!fs.length) h += '<p class="small muted" style="margin:0">Treina com a ficha impressa da academia? Tire uma foto do ticket e o app monta o treino com os números das máquinas.</p>';
    fs.forEach(function (f) {
      const on = f.ativa !== false;
      h += '<div class="row between" style="gap:8px"><div' + (on ? '' : ' style="opacity:.6"') + '><b>Treino ' + esc(f.letra) + '</b> <span class="small muted">' + esc(f.nome) + ' · ' + f.itens.length + ' exercícios' + (f.validade ? ' · até ' + esc(f.validade) : '') + (on ? '' : ' · guardada') + '</span></div><div class="row" style="gap:6px"><button class="btn sm' + (on ? ' primary' : '') + '" data-act="ficha-ativa" data-id="' + esc(f.id) + '" aria-pressed="' + on + '">' + (on ? 'Na semana' : 'Guardada') + '</button><button class="btn sm ghost" data-act="ficha-del" data-id="' + esc(f.id) + '">Apagar</button></div></div>';
    });
    if (fs.length && !S.perfil.usarFichas) h += '<p class="small muted" style="margin:0">Desligado: o treino mostrado é o montado pelo app.</p>';
    h += '<button class="btn block" data-act="ficha-foto">Importar ficha (foto do ticket)</button><input type="file" id="ficha-in" accept="image/*" capture="environment" hidden>';
    const faltam = FICHAS_PRONTAS.filter(function (p) { return !fs.some(function (f) { return f.id.split('_')[0] === p.id; }); });
    if (faltam.length) h += '<div class="small muted">Fichas de 17/11 já digitadas:</div><div class="row" style="flex-wrap:wrap;gap:6px">' + faltam.map(function (p) { return '<button class="btn sm" data-act="ficha-pronta" data-id="' + p.id + '">+ ' + esc(p.nome.replace(' adaptativo', '')) + '</button>'; }).join('') + '</div>';
    h += renderImportFicha();
    h += '</div>';
    return h;
  }
  function renderImportFicha() {
    const a = S.fichaImp;
    if (!a) return '';
    if (a.estado === 'carregando') return '<div class="card">Lendo o ticket… pode levar até um minuto.</div>';
    if (a.estado === 'erro') return '<div class="card warnbox stack" style="white-space:pre-line">' + esc(a.erro) + '<div class="row"><button class="btn" data-act="ficha-repetir">Tentar de novo</button><button class="btn ghost" data-act="ficha-fechar">Fechar</button></div></div>';
    const r = a.res;
    if (!r.legivel) return '<div class="card warnbox stack">Não consegui ler uma ficha nessa foto. Tire a foto de perto, reta e com boa luz.<div class="row"><button class="btn" data-act="ficha-foto">Tirar outra foto</button><button class="btn ghost" data-act="ficha-fechar">Fechar</button></div></div>';
    const cat = F.EX.slice().sort(function (x, y) { return x.nome.localeCompare(y.nome, 'pt-BR'); });
    let h = '<div class="card stack" style="border-color:var(--ember)"><h3>Confira a ficha lida</h3>';
    h += '<label class="small stack" style="gap:4px">Nome<input id="fi-nome" maxlength="60" value="' + esc(r.treino || 'Ficha da academia') + '"></label>';
    r.exercicios.forEach(function (e, i) {
      h += '<div class="stack" style="gap:4px;border-top:1px solid var(--line);padding-top:8px"><div class="small"><b>' + (i + 1) + '. ' + esc(e.nomeFicha) + '</b></div>' +
        '<select id="fi-ex-' + i + '" data-fi-sel="' + i + '" aria-label="Exercício do app para ' + esc(e.nomeFicha) + '"><option value="__novo"' + (e.ex ? '' : ' selected') + '>➕ Criar exercício: ' + esc(nomeBonito(e.nomeFicha)) + '</option><option value="">— não incluir —</option>' + cat.map(function (c) { return '<option value="' + c.id + '"' + (c.id === e.ex ? ' selected' : '') + '>' + esc(c.nome) + '</option>'; }).join('') + '</select>' +
        '<label class="small row" id="fi-gwrap-' + i + '" style="gap:6px;' + (e.ex ? 'display:none' : '') + '">Músculo principal <select id="fi-g-' + i + '">' + Object.keys(F.GRUPOS).map(function (g) { return '<option value="' + g + '"' + (g === (e.grupo || 'peito') ? ' selected' : '') + '>' + esc(F.GRUPOS[g]) + '</option>'; }).join('') + '</select></label>' +
        '<div class="row" style="gap:6px"><input id="fi-maq-' + i + '" aria-label="Máquina" placeholder="Máquina" maxlength="30" value="' + esc(e.maquina) + '" style="flex:2;min-width:0"><input id="fi-ser-' + i + '" aria-label="Séries" type="number" min="1" max="8" value="' + e.series + '" style="flex:1;min-width:0"><input id="fi-rep-' + i + '" aria-label="Repetições" maxlength="12" value="' + esc(e.reps) + '" style="flex:1.4;min-width:0"><input id="fi-int-' + i + '" aria-label="Descanso em segundos" type="number" min="0" max="600" value="' + e.descanso + '" style="flex:1;min-width:0"></div>' +
        (e.ex ? '' : '<div class="small" style="color:var(--ember)">Não achei no catálogo: vou criar este exercício (ou escolha um da lista).</div>') + '</div>';
    });
    h += '<div class="small muted">Campos: máquina · séries · repetições · descanso (s).</div>';
    if ((S.perfil.fichas || []).length) h += '<label class="row small" style="gap:6px"><input type="checkbox" id="fi-subst"> Substituir as fichas atuais (deixe desmarcado para somar: cada ficha ocupa um dia)</label>';
    h += '<div class="row"><button class="btn primary grow" data-act="ficha-salvar">Salvar ficha</button><button class="btn ghost" data-act="ficha-fechar">Cancelar</button></div>';
    h += '<p class="note">Leitura feita por IA: confira os números antes de salvar.</p></div>';
    return h;
  }
  async function lerFicha(arquivo) {
    S.ultimaFicha = arquivo;
    S.fichaImp = { estado: 'carregando' }; render();
    try {
      const cat = F.EX.filter(function (e) { return !e.extra; }).map(function (e) { return { id: e.id, nome: e.nome }; });
      S.fichaImp = { estado: 'ok', res: await X.importarFicha(arquivo, cat) };
    } catch (e) { S.fichaImp = { estado: 'erro', erro: e.message || String(e) }; }
    render();
  }

  /* ---------- Foto do aparelho ---------- */
  function renderAparelho(letra) {
    const a = S.aparelho;
    if (!a) return '';
    if (a.estado === 'carregando') return '<div class="card">Identificando o aparelho… pode levar até um minuto.</div>';
    if (a.estado === 'erro') return '<div class="card warnbox stack" style="white-space:pre-line">' + esc(a.erro) + '<div class="row"><button class="btn" data-act="aparelho-repetir">Tentar de novo</button><button class="btn ghost" data-act="aparelho-fechar">Fechar</button></div></div>';
    const r = a.res;
    if (!r.reconhecido) return '<div class="card warnbox stack">Não consegui identificar um aparelho nessa foto.' + (r.dica ? ' ' + esc(r.dica) : '') + '<div class="row"><button class="btn" data-act="foto-aparelho">Tirar outra foto</button><button class="btn ghost" data-act="aparelho-fechar">Fechar</button></div></div>';
    const lista = function (t, l, num) { return l.length ? '<div><b>' + t + '</b>' + (num ? '<ol style="margin:4px 0 0;padding-left:20px">' : '<ul style="margin:4px 0 0;padding-left:20px">') + l.map(function (x) { return '<li>' + esc(x) + '</li>'; }).join('') + (num ? '</ol>' : '</ul>') + '</div>' : ''; };
    let h = '<div class="card stack" style="border-color:var(--ember)"><div class="row between"><h3>' + esc(r.aparelho) + '</h3><button class="btn sm ghost" data-act="aparelho-fechar">Fechar</button></div>';
    if (r.exercicio_id) h += imgs(r.exercicio_id, true);
    if (r.musculos.length) h += '<div class="small"><b>Trabalha:</b> ' + r.musculos.map(esc).join(', ') + '</div>';
    h += lista('Como ajustar', r.ajustes, false) + lista('Como fazer', r.execucao, true) + lista('Erros comuns', r.erros, false);
    if (r.seguranca) h += '<div class="small" style="color:var(--warn)"><b>Cuidado:</b> ' + esc(r.seguranca) + '</div>';
    const ids = (r.exercicio_id ? [r.exercicio_id] : []).concat(r.outros_ids);
    if (ids.length) {
      h += '<div class="stack" style="gap:6px"><b>Adicionar ao treino ' + letra + '</b>' + ids.map(function (id) {
        const e = F.EX_BY_ID[id];
        return e ? '<button class="btn" data-act="add-escolher" data-ex="' + id + '">+ ' + esc(e.nome) + '</button>' : '';
      }).join('') + '</div>';
    }
    h += '<p class="note">Orientação gerada por IA a partir da foto. Comece com carga leve e, na dúvida, peça ajuda ao professor da academia.</p></div>';
    return h;
  }
  async function analisarAparelho(arquivo) {
    S.ultimoAparelho = arquivo;
    S.aparelho = { estado: 'carregando' }; render();
    try {
      const cat = F.EX.filter(function (e) { return !e.extra && (e.eq === 'gym' || e.eq === 'db'); }).map(function (e) { return { id: e.id, nome: e.nome }; });
      S.aparelho = { estado: 'ok', res: await X.identificarAparelho(arquivo, cat) };
    } catch (e) { S.aparelho = { estado: 'erro', erro: e.message || String(e) }; }
    render();
  }

  function abrirAdicionarEx() {
    const r = S.perfil.resp, g = S.addGrupo || 'peito';
    let h = '<div class="sheet-bg" data-act="fechar-sheet"><div class="sheet stack" role="dialog" aria-modal="true" aria-label="Adicionar exercício"><div class="row between"><h3>Adicionar exercício</h3><button class="btn sm" data-act="fechar-sheet">Fechar</button></div>';
    h += '<input id="add-busca" type="search" placeholder="Nome ou nº da máquina (ex.: rosca, 13)" aria-label="Buscar exercício" value="' + esc(S.addBusca || '') + '">';
    h += '<div class="chips">' + Object.keys(F.GRUPOS).map(function (k) { return '<button class="chip' + (k === g && !S.addBusca ? ' on' : '') + '" data-act="add-grupo" data-v="' + k + '">' + esc(F.GRUPOS[k]) + '</button>'; }).join('') + '</div>';
    h += '<div id="add-lista" class="stack" style="gap:8px">' + listaAdicionar() + '</div>';
    h += '</div></div>';
    $layer.innerHTML = h;
  }
  // Sem acento e minúsculo, para a busca achar "triceps" em "Tríceps"
  function norm(t) { return String(t || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
  function listaAdicionar() {
    const r = S.perfil.resp, g = S.addGrupo || 'peito', q = norm(S.addBusca).trim();
    let lista;
    if (q) {
      const ok = r.equip === 'db' ? ['db', 'bw'] : r.equip === 'bw' ? ['bw'] : ['gym', 'db', 'bw'];
      const termos = q.split(/\s+/);
      lista = F.EX.filter(function (e) {
        if (ok.indexOf(e.eq) < 0) return false;
        const t = norm(e.nome + ' ' + (e.nomeEn || '') + ' ' + F.GRUPOS[e.g]);
        const maqs = (maquinaDe({ ex: e.id }).match(/\d+/g) || []);
        // número sozinho (ou "maq 13"): procura pelo número da máquina
        return termos.every(function (w) { const n = w.replace(/^(maq|maquina|m)\.?/, ''); return /^\d+$/.test(n) ? maqs.indexOf(String(Number(n))) >= 0 : t.indexOf(w) >= 0; });
      })
        .sort(function (a, b) { return (a.extra ? 1 : 0) - (b.extra ? 1 : 0) || a.nome.localeCompare(b.nome, 'pt-BR'); }).slice(0, 60);
    } else lista = F.doGrupo(g, r.equip, r.estilo);
    if (!lista.length) {
      if (!q || /^\d+$/.test(q)) return '<p class="muted">Nada encontrado. Tente outra palavra.</p>';
      return '<p class="muted">Não achei "' + esc(S.addBusca) + '".</p><div class="row" style="gap:6px;flex-wrap:wrap"><span class="small">Criar no músculo:</span>' + Object.keys(F.GRUPOS).map(function (g) { return '<button class="chip" data-act="add-criar" data-g="' + g + '">' + esc(F.GRUPOS[g]) + '</button>'; }).join('') + '</div>';
    }
    let h = '';
    lista.forEach(function (e) {
      h += '<button class="alt" data-act="add-escolher" data-ex="' + e.id + '">' + imgs(e.id) + '<span><b>' + esc(e.nome) + '</b>' + (maquinaDe({ ex: e.id }) ? ' <span class="small" style="color:var(--ember)">Máq. ' + esc(maquinaDe({ ex: e.id })) + '</span>' : e.maq ? ' <span class="small" style="color:var(--ember)">máquina/polia</span>' : '') + '<br><span class="small muted">' + esc(dicaDe(e)) + '</span></span></button>';
    });
    return h;
  }

  /* ---------- Dieta ---------- */
  /* ---------- Diário alimentar com foto do prato ---------- */
  const X = window.ForjaExtras;
  function diarioHoje() { S.perfil.diario = S.perfil.diario || {}; return S.perfil.diario[hojeISO()] || []; }
  function renderDiario(m) {
    const itens = diarioHoje();
    const t = X.totalItens(itens.map(function (e) { return e.total; }));
    const pct = function (a, b) { return b ? Math.min(100, Math.round(a / b * 100)) : 0; };
    const resta = m.kcal - t.kcal;
    let h = '<div class="card stack"><div class="row between"><h3>Diário de hoje</h3><span class="small muted num">' + fmt(t.kcal) + ' de ' + fmt(m.kcal) + ' kcal</span></div>';
    h += '<div class="bar"><i style="width:' + pct(t.kcal, m.kcal) + '%' + (t.kcal > m.kcal ? ';background:var(--warn)' : '') + '"></i></div>';
    h += '<div class="small ' + (resta < 0 ? '' : 'muted') + ' num" style="' + (resta < 0 ? 'color:var(--warn)' : '') + '">' + (resta >= 0 ? 'Faltam ' + fmt(resta) + ' kcal' : 'Passou ' + fmt(-resta) + ' kcal da meta') + ' · P ' + fmt(t.p) + '/' + fmt(m.p) + ' g · C ' + fmt(t.c) + '/' + fmt(m.c) + ' g · G ' + fmt(t.g) + '/' + fmt(m.g) + ' g</div>';
    const cardioHoje = (S.perfil.cardio || []).filter(function (x) { return x.d.slice(0, 10) === hojeISO(); }).reduce(function (a, x) { return a + x.kcal; }, 0);
    if (cardioHoje) h += '<div class="small muted num">Cardio hoje: ≈ ' + fmt(cardioHoje) + ' kcal gastas (não somadas à meta; os treinos já entram no cálculo do gasto diário)</div>';
    h += '<div class="row wrap"><button class="btn primary grow" data-act="foto">Foto do prato</button><button class="btn grow" data-act="galeria">Escolher da galeria</button><button class="btn grow" data-act="descrever">Descrever</button></div>';
    h += '<input type="file" id="foto-in" accept="image/*" capture="environment" hidden><input type="file" id="galeria-in" accept="image/*" hidden>';
    if (S.descrever) h += '<label class="f" for="desc-txt">' + (S.refAlvo ? 'O que você comeu no ' + esc(nomeRef(S.refAlvo)) + '?' : 'O que você comeu?') + ' Inclua quantidades se souber<textarea class="in" id="desc-txt" rows="3" placeholder="2 conchas de arroz, 1 concha de feijão, 1 filé de frango grelhado e salada">' + esc(S.descTxt || '') + '</textarea></label><button class="btn" data-act="analisar-texto">Calcular</button>';
    const a = S.analise;
    if (a && a.estado === 'carregando') h += '<div class="card" style="background:var(--surface-2)">Analisando a refeição… pode levar até um minuto.</div>';
    if (a && a.estado === 'erro') h += '<div class="card warnbox stack" style="white-space:pre-line">' + esc(a.erro) + (S.ultimoPedido ? '<button class="btn" data-act="tentar-de-novo">Tentar de novo</button>' : '') + '</div>';
    if (a && a.estado === 'resultado') {
      const r = a.res, tt = X.totalItens(r.itens);
      h += '<div class="card stack" style="background:var(--surface-2)"><div class="row between"><b>' + esc(r.titulo) + '</b><span class="small muted">' + (r.confianca ? 'confiança ' + esc(r.confianca) : '') + '</span></div>';
      if (!r.itens.length) h += '<div class="small">' + esc(r.observacao || 'Não encontrei comida nessa imagem.') + '</div>';
      r.itens.forEach(function (i, k) {
        h += '<div class="food"><div><b>' + esc(i.nome) + '</b><div class="q num">' + fmt(i.kcal) + ' kcal · P ' + fmt(i.p, 1) + ' · C ' + fmt(i.c, 1) + ' · G ' + fmt(i.g, 1) + '</div></div><label class="row small muted" style="gap:4px"><input class="in num" style="width:76px;padding:6px" type="number" inputmode="numeric" data-res-g="' + k + '" value="' + i.gramas + '" aria-label="Gramas de ' + esc(i.nome) + '">g</label></div>';
      });
      if (r.itens.length) {
        h += '<div class="small num"><b>Total: ' + fmt(tt.kcal) + ' kcal</b> · P ' + fmt(tt.p) + ' g · C ' + fmt(tt.c) + ' g · G ' + fmt(tt.g) + ' g</div>';
        if (r.observacao) h += '<div class="note">' + esc(r.observacao) + '</div>';
        h += '<div class="note">Estimativa da IA. Ajuste as gramas se souber a quantidade certa: as calorias se recalculam.</div>';
      }
      if (r.itens.length) {
        const fx = refeicoesFechadasHoje(), n = Math.min(6, Math.max(3, Number(S.perfil.resp.refeicoes) || 4));
        const ops = dietaDoDia(hojeISO()).refeicoes.filter(function (x) { return fx.todas.indexOf(x.chave) < 0 || x.chave === S.refAlvo; });
        h += '<div class="small muted">Registrar como:</div><div class="chips">' + ops.map(function (x) { return '<button class="chip' + (S.refAlvo === x.chave ? ' on' : '') + '" data-act="ref-alvo" data-r="' + x.chave + '">' + esc(x.nome) + '</button>'; }).join('') + '<button class="chip' + (!S.refAlvo ? ' on' : '') + '" data-act="ref-alvo" data-r="">Extra</button></div>';
      }
      h += '<div class="row">' + (r.itens.length ? '<button class="btn primary grow" data-act="res-add">Adicionar ao diário</button>' : '') + '<button class="btn" data-act="res-descartar">Descartar</button></div></div>';
    }
    if (itens.length) {
      h += '<div class="hist">' + itens.map(function (e) {
        return '<div class="it"><div><b>' + esc(e.titulo) + '</b> <span class="small muted">' + esc(e.hora) + (e.refeicao ? ' · ' + esc(nomeRef(e.refeicao)) : '') + '</span><div class="small muted num">' + fmt(e.total.kcal) + ' kcal · ' + e.itens.map(function (i) { return esc(i.nome) + ' ' + i.gramas + ' g'; }).join(', ') + '</div></div><button class="btn sm ghost" data-act="diario-del" data-id="' + esc(e.id) + '" aria-label="Apagar ' + esc(e.titulo) + '">Apagar</button></div>';
      }).join('') + '</div>';
    } else if (!a) h += '<p class="small muted" style="margin:0">Tire uma foto do prato ou descreva o que comeu. A IA estima as calorias e soma no seu dia.</p>';
    h += '</div>';
    return h;
  }
  function nomeRef(chave) { return (F.REF[chave] || {}).nome || chave; }
  async function analisarRefeicao(arquivo, nota) {
    S.ultimoPedido = { arquivo: arquivo, nota: nota }; // para o botão Tentar de novo
    S.analise = { estado: 'carregando' }; render();
    try {
      const r = await X.analisar(arquivo, nota);
      S.analise = { estado: 'resultado', res: r };
    } catch (e) { S.analise = { estado: 'erro', erro: e.message || String(e) }; }
    render();
  }
  async function adicionarAoDiario() {
    const r = S.analise.res, d = hojeISO(), agora = new Date();
    S.perfil.diario = S.perfil.diario || {};
    const lista = S.perfil.diario[d] || [];
    lista.push({ id: Date.now().toString(36), hora: String(agora.getHours()).padStart(2, '0') + ':' + String(agora.getMinutes()).padStart(2, '0'), titulo: r.titulo, refeicao: S.refAlvo || undefined, itens: r.itens.map(function (i) { return { nome: i.nome, gramas: i.gramas }; }), total: X.totalItens(r.itens) });
    S.perfil.diario[d] = lista;
    // Guarda só os últimos 45 dias
    const corte = new Date(Date.now() - 45 * 864e5).toISOString().slice(0, 10);
    Object.keys(S.perfil.diario).forEach(function (k) { if (k < corte) delete S.perfil.diario[k]; });
    S.analise = null; S.descrever = false; S.descTxt = ''; S.refAlvo = '';
    await Store.savePerfil(S.perfil);
    render(); toast('Refeição adicionada ao diário');
  }

  /* Dia do cardápio: hoje + 6 dias à frente. O número do dia faz o cardápio girar. */
  function dataMais(n) { const d = new Date(Date.now() + n * 864e5); return new Date(d.getTime() - d.getTimezoneOffset() * 60000).toISOString().slice(0, 10); }
  function numeroDia(iso) { return Math.floor(Date.parse(iso + 'T12:00:00Z') / 864e5); }
  const DIAS_SEM = ['Dom', 'Seg', 'Ter', 'Qua', 'Qui', 'Sex', 'Sáb'];
  function refeicoesFechadasHoje() {
    const d = hojeISO();
    const feitas = diarioHoje().filter(function (e) { return e.refeicao; }).map(function (e) { return e.refeicao; });
    const pulas = ((S.perfil.pulas || {})[d]) || [];
    return { feitas: feitas, pulas: pulas, todas: feitas.concat(pulas) };
  }
  function dietaDoDia(iso) {
    const trocas = ((S.perfil.trocasDia || {})[iso]) || {};
    if (iso !== hojeISO()) return F.montarDieta(S.perfil.resp, trocas, { rot: numeroDia(iso) });
    const fx = refeicoesFechadasHoje();
    const cons = X.totalItens(diarioHoje().map(function (e) { return e.total; }));
    return F.montarDieta(S.perfil.resp, trocas, { rot: numeroDia(iso), consumido: cons, fechadas: fx.todas });
  }
  function podarDatas(obj) {
    const corte = dataMais(-45);
    Object.keys(obj || {}).forEach(function (k) { if (k < corte) delete obj[k]; });
  }

  function renderDieta() {
    const off = S.diaDieta || 0, iso = dataMais(off), ehHoje = off === 0;
    const d = dietaDoDia(iso);
    const m = d.metas, t = d.total;
    const pct = function (a, b) { return b ? Math.min(100, Math.round(a / b * 100)) : 0; };
    let h = '<div class="stack">' + renderDiario(m);
    // Escolha do dia
    h += '<div class="days" role="tablist">' + [0, 1, 2, 3, 4, 5, 6].map(function (n) {
      const di = dataMais(n), dt = new Date(di + 'T12:00:00');
      return '<button class="day' + (n === off ? ' on' : '') + '" data-act="dia-dieta" data-n="' + n + '" role="tab" aria-selected="' + (n === off) + '"><div class="next">' + (n === 0 ? 'Hoje' : n === 1 ? 'Amanhã' : '&nbsp;') + '</div><b>' + dt.getDate() + '</b><span>' + DIAS_SEM[dt.getDay()] + '</span></button>';
    }).join('') + '</div>';
    h += '<div class="card stack"><h3>Cardápio ' + (ehHoje ? 'de hoje' : 'de ' + dataBR(iso).slice(0, 5)) + '</h3><div class="row between"><div><div class="small muted">Meta diária</div><div class="kcal num">' + fmt(m.kcal) + '<span style="font-size:20px"> kcal</span></div></div><div style="text-align:right" class="small muted num">' + (d.resto ? 'Falta para fechar o dia:<br><b style="color:var(--text)">' + fmt(d.resto.kcal) + ' kcal</b>' : 'Cardápio abaixo:<br>' + fmt(t.kcal) + ' kcal') + '</div></div>';
    if (d.resto) h += '<div class="small muted">As refeições que faltam foram recalculadas para fechar a meta com o que você já comeu e pulou.</div>';
    else h += '<div class="mac">' + [['Proteína', t.p, m.p], ['Carboidrato', t.c, m.c], ['Gordura', t.g, m.g]].map(function (x) {
      return '<div><div class="small muted">' + x[0] + '</div><div class="v num">' + fmt(x[1]) + '<span class="muted" style="font-size:14px"> / ' + fmt(x[2]) + ' g</span></div><div class="bar"><i style="width:' + pct(x[1], x[2]) + '%"></i></div></div>';
    }).join('') + '</div>';
    if (m.noPiso) h += '<div class="card warnbox">A meta ficou no piso de segurança (sua taxa basal ou ' + (S.perfil.resp.sexo === 'M' ? '1.500' : '1.200') + ' kcal). O Forja não sugere menos que isso.</div>';
    h += '<details class="calc"><summary>Como esse número foi calculado</summary><table class="num"><tbody>' +
      '<tr><td>Taxa metabólica basal (Mifflin-St Jeor)</td><td>' + fmt(m.tmb) + ' kcal</td></tr>' +
      '<tr><td>Fator de atividade (dia a dia + 0,03 por treino na semana)</td><td>× ' + fmt(m.fator, 3) + '</td></tr>' +
      '<tr><td>Gasto diário estimado</td><td>' + fmt(m.get) + ' kcal</td></tr>' +
      '<tr><td>Ajuste do objetivo (' + esc(m.tipoAjuste) + ')</td><td>' + (m.ajuste > 0 ? '+' : '') + fmt(m.ajuste * 100) + '%</td></tr>' +
      (m.ajusteCheckin ? '<tr><td>Ajuste dos check-ins semanais</td><td>' + (m.ajusteCheckin > 0 ? '+' : '') + m.ajusteCheckin + ' kcal</td></tr>' : '') +
      '<tr><td>' + (m.manual ? 'Meta definida por você' : 'Meta (arredondada)') + '</td><td>' + fmt(m.kcal) + ' kcal</td></tr>' +
      '<tr><td>Proteína: ' + fmt(m.gpk, 1) + ' g por kg</td><td>' + fmt(m.p) + ' g</td></tr>' +
      '<tr><td>Gordura: 0,8 g/kg (mínimo 20% das kcal)</td><td>' + fmt(m.g) + ' g</td></tr>' +
      '<tr><td>Carboidrato: o que sobra das kcal</td><td>' + fmt(m.c) + ' g</td></tr></tbody></table>' +
      '<form class="row" data-form="meta-manual" style="margin-top:8px"><label class="f grow" for="meta-in">Definir minha meta (kcal)' + (m.manual ? '' : ' — deixe vazio para usar o cálculo') + '<input class="in num" id="meta-in" type="number" inputmode="numeric" min="1000" max="6000" step="10" value="' + (S.perfil.resp.kcalManual || '') + '" placeholder="' + fmt(m.kcal) + '"></label><button class="btn" type="submit" style="align-self:flex-end">Salvar</button></form>' +
      (m.manual ? '<button class="btn sm ghost" data-act="meta-auto" style="margin-top:6px">Voltar ao cálculo automático</button>' : '') +
      '<p class="note">Use a meta manual se um nutricionista passou um valor para você.</p></details></div>';
    const fx = ehHoje ? refeicoesFechadasHoje() : { feitas: [], pulas: [] };
    d.refeicoes.forEach(function (r) {
      const feita = fx.feitas.indexOf(r.chave) >= 0, pulada = fx.pulas.indexOf(r.chave) >= 0;
      h += '<div class="card"' + (feita || pulada ? ' style="opacity:.75"' : '') + '><div class="row between" style="margin-bottom:6px"><h3>' + esc(r.nome) + '</h3>';
      if (feita) {
        const e = diarioHoje().filter(function (x) { return x.refeicao === r.chave; });
        const k = X.totalItens(e.map(function (x) { return x.total; })).kcal;
        h += '<span class="pill down num">Feita · ' + fmt(k) + ' kcal</span></div><div class="small muted">' + e.map(function (x) { return esc(x.titulo); }).join(', ') + '</div><button class="btn sm ghost" data-act="ref-desfazer" data-r="' + r.chave + '" style="margin-top:6px">Desfazer</button></div>';
        return;
      }
      if (pulada) {
        h += '<span class="pill up">Pulada</span></div><div class="small muted">As calorias dela foram divididas entre as próximas refeições.</div><button class="btn sm ghost" data-act="ref-despular" data-r="' + r.chave + '" style="margin-top:6px">Desfazer</button></div>';
        return;
      }
      h += '<span class="small muted num">' + fmt(r.total.kcal) + ' kcal · P ' + fmt(r.total.p) + ' · C ' + fmt(r.total.c) + ' · G ' + fmt(r.total.g) + '</span></div>';
      r.itens.forEach(function (i) {
        const chave = r.chave + '.' + i.papel;
        h += '<div class="food"><div><b>' + esc(F.ALIM[i.id].nome) + '</b><div class="q num">' + esc(F.porcao(i.id, i.gramas)) + '</div></div><div class="k num">' + fmt(i.macros.kcal) + ' kcal' + (i.opcoes.length > 1 ? '<br><button class="btn sm ghost" data-act="troca-dieta" data-c="' + chave + '" style="margin-top:4px">Trocar</button>' : '') + '</div>';
        if (S.trocaDieta === chave) {
          h += '<div class="swap">' + i.opcoes.map(function (o) { return '<button class="chip' + (o === i.id ? ' on' : '') + '" data-act="escolher-alim" data-c="' + chave + '" data-v="' + o + '">' + esc(F.ALIM[o].nome) + '</button>'; }).join('') + '</div>';
        }
        h += '</div>';
      });
      if (ehHoje) h += '<div class="row wrap" style="margin-top:8px"><button class="btn sm grow" data-act="ref-comi" data-r="' + r.chave + '">Comi isto</button><button class="btn sm grow" data-act="ref-outra" data-r="' + r.chave + '">Comi outra coisa</button><button class="btn sm ghost" data-act="ref-pular" data-r="' + r.chave + '">Pular</button></div>';
      h += '</div>';
    });
    h += '<p class="note">O cardápio muda a cada dia. Valores aproximados por 100 g com base na Tabela TACO (UNICAMP); whey pela média de rótulos. Confira o rótulo dos seus produtos. Conteúdo educativo: não substitui um nutricionista.</p></div>';
    $view.innerHTML = h;
  }

  async function registrarRefeicaoDoPlano(chave) {
    const d = dietaDoDia(hojeISO()), r = d.refeicoes.find(function (x) { return x.chave === chave; });
    if (!r) return;
    const agora = new Date(), dia = hojeISO();
    S.perfil.diario = S.perfil.diario || {};
    S.perfil.diario[dia] = (S.perfil.diario[dia] || []).concat([{ id: Date.now().toString(36), hora: String(agora.getHours()).padStart(2, '0') + ':' + String(agora.getMinutes()).padStart(2, '0'), titulo: r.nome + ' (cardápio)', refeicao: chave, itens: r.itens.map(function (i) { return { nome: F.ALIM[i.id].nome, gramas: i.gramas }; }), total: r.total }]);
    await Store.savePerfil(S.perfil); render(); toast(r.nome + ' registrado · +10 XP');
  }

  /* ---------- Progresso ---------- */
  // Ritmo de mudança do peso: compara o último registro com o de ~4 semanas antes
  function ritmoPeso(pesos) {
    if (pesos.length < 2) return '';
    const ult = pesos[pesos.length - 1], tU = new Date(ult.d).getTime();
    let base = pesos[0];
    for (let i = pesos.length - 2; i >= 0; i--) { if (tU - new Date(pesos[i].d).getTime() >= 28 * 864e5) { base = pesos[i]; break; } }
    const dias = (tU - new Date(base.d).getTime()) / 864e5;
    if (dias < 6) return '';
    const porSem = (ult.kg - base.kg) / dias * 7;
    return '<div class="small muted num">Ritmo: ' + (porSem > 0 ? '+' : '') + fmt(porSem, 2) + ' kg por semana (últimas ' + Math.round(dias / 7) + ' semanas)</div>';
  }
  function graficoPeso(pesos) {
    const pts = pesos.slice(-60);
    if (pts.length < 2) return '<p class="muted small">Registre o peso em dias diferentes para ver o gráfico.</p>';
    const W = 340, H = 150, pl = 34, pr = 12, pt = 12, pb = 24;
    const kgs = pts.map(function (p) { return p.kg; });
    let min = Math.min.apply(null, kgs), max = Math.max.apply(null, kgs);
    if (max - min < 2) { min -= 1; max += 1; }
    min = Math.floor(min); max = Math.ceil(max);
    const x = function (i) { return pl + (W - pl - pr) * (i / (pts.length - 1)); };
    const y = function (v) { return pt + (H - pt - pb) * (1 - (v - min) / (max - min)); };
    const linha = pts.map(function (p, i) { return (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(p.kg).toFixed(1); }).join(' ');
    const area = linha + ' L' + x(pts.length - 1).toFixed(1) + ' ' + (H - pb) + ' L' + x(0).toFixed(1) + ' ' + (H - pb) + ' Z';
    const ult = pts[pts.length - 1];
    let g = '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="Peso de ' + fmt(pts[0].kg, 1) + ' a ' + fmt(ult.kg, 1) + ' kg">';
    [min, (min + max) / 2, max].forEach(function (v) { g += '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + y(v) + '" y2="' + y(v) + '" stroke="#31363F" stroke-width="1"/><text x="' + (pl - 6) + '" y="' + (y(v) + 4) + '" fill="#9AA1AD" font-size="11" text-anchor="end">' + fmt(v, v % 1 ? 1 : 0) + '</text>'; });
    g += '<path d="' + area + '" fill="#FF6B2C" fill-opacity=".12"/><path d="' + linha + '" fill="none" stroke="#FF6B2C" stroke-width="2.5" stroke-linejoin="round"/>';
    g += '<circle cx="' + x(pts.length - 1) + '" cy="' + y(ult.kg) + '" r="4.5" fill="#FF6B2C"/>';
    g += '<text x="' + pl + '" y="' + (H - 6) + '" fill="#9AA1AD" font-size="11">' + dataBR(pts[0].d).slice(0, 5) + '</text><text x="' + (W - pr) + '" y="' + (H - 6) + '" fill="#9AA1AD" font-size="11" text-anchor="end">' + dataBR(ult.d).slice(0, 5) + '</text></svg>';
    return g;
  }
  /* ---------- Estatísticas ----------
     Força estimada (1RM) pela fórmula de Epley: carga × (1 + repetições ÷ 30), válida até ~10-12 repetições. */
  function e1rm(kg, reps) { kg = Number(kg) || 0; reps = Number(reps) || 0; if (!kg || !reps) return 0; return reps === 1 ? kg : kg * (1 + Math.min(reps, 12) / 30); }
  function graficoLinha(pts, rotulo, unidade) {
    // pts: [{d:'AAAA-MM-DD', v:número}]
    if (pts.length < 2) return '<p class="muted small">Faça este exercício em dois dias diferentes para ver a evolução.</p>';
    const W = 340, H = 140, pl = 34, pr = 12, pt = 12, pb = 24;
    const vs = pts.map(function (p) { return p.v; });
    let min = Math.min.apply(null, vs), max = Math.max.apply(null, vs);
    if (max - min < 2) { min -= 1; max += 1; }
    min = Math.floor(min); max = Math.ceil(max);
    const x = function (i) { return pl + (W - pl - pr) * (i / (pts.length - 1)); };
    const y = function (v) { return pt + (H - pt - pb) * (1 - (v - min) / (max - min)); };
    const linha = pts.map(function (q, i) { return (i ? 'L' : 'M') + x(i).toFixed(1) + ' ' + y(q.v).toFixed(1); }).join(' ');
    const ult = pts[pts.length - 1];
    let g = '<svg class="chart" viewBox="0 0 ' + W + ' ' + H + '" role="img" aria-label="' + esc(rotulo) + ' de ' + fmt(pts[0].v, 1) + ' a ' + fmt(ult.v, 1) + ' ' + unidade + '">';
    [min, (min + max) / 2, max].forEach(function (v) { g += '<line x1="' + pl + '" x2="' + (W - pr) + '" y1="' + y(v) + '" y2="' + y(v) + '" stroke="#31363F" stroke-width="1"/><text x="' + (pl - 6) + '" y="' + (y(v) + 4) + '" fill="#9AA1AD" font-size="11" text-anchor="end">' + fmt(v, v % 1 ? 1 : 0) + '</text>'; });
    g += '<path d="' + linha + '" fill="none" stroke="#FF6B2C" stroke-width="2.5" stroke-linejoin="round"/>';
    pts.forEach(function (q, i) { g += '<circle cx="' + x(i).toFixed(1) + '" cy="' + y(q.v).toFixed(1) + '" r="' + (i === pts.length - 1 ? 4.5 : 2.5) + '" fill="#FF6B2C"/>'; });
    g += '<text x="' + pl + '" y="' + (H - 6) + '" fill="#9AA1AD" font-size="11">' + dataBR(pts[0].d).slice(0, 5) + '</text><text x="' + (W - pr) + '" y="' + (H - 6) + '" fill="#9AA1AD" font-size="11" text-anchor="end">' + dataBR(ult.d).slice(0, 5) + '</text></svg>';
    return g;
  }
  /* ---------- Mapa do corpo (geometria MuscleMap, MIT; ver corpo.js) ---------- */
  const NOME_MUSC = { chest: 'Peito', abs: 'Abdômen', obliques: 'Oblíquos', serratus: 'Serrátil', 'hip-flexors': 'Flexores do quadril', biceps: 'Bíceps', triceps: 'Tríceps', deltoids: 'Ombros', forearm: 'Antebraço', trapezius: 'Trapézio', 'upper-back': 'Meio das costas', lats: 'Dorsais', 'lower-back': 'Lombar', gluteal: 'Glúteos', hamstring: 'Posterior de coxa', quadriceps: 'Quadríceps', adductors: 'Adutores', calves: 'Panturrilhas', tibialis: 'Tibial' };
  const INERTE = { head: 1, neck: 1, hands: 1, feet: 1, knees: 1, ankles: 1 };
  const MUSC_GRUPO = { peito: [['chest'], ['triceps', 'deltoids']], costas: [['lats', 'upper-back'], ['biceps']], ombro: [['deltoids'], ['trapezius']], biceps: [['biceps'], ['forearm']], triceps: [['triceps'], []], quad: [['quadriceps'], ['gluteal']], post: [['hamstring', 'gluteal'], ['lower-back']], pant: [['calves'], []], core: [['abs'], ['obliques']], antebraco: [['forearm'], []] };
  // Séries efetivas por músculo: músculo principal conta 1, secundário conta 0,5
  function cargaMusculos(itens) {
    const c = {};
    (itens || []).forEach(function (it) {
      let m = (window.ForjaMusculosEx || {})[it.ex];
      if (!m && F.EX_BY_ID[it.ex]) m = MUSC_GRUPO[F.EX_BY_ID[it.ex].g];
      if (!m) return;
      const n = Array.isArray(it.series) ? it.series.length : (Number(it.series) || 0);
      m[0].forEach(function (k) { c[k] = (c[k] || 0) + n; });
      m[1].forEach(function (k) { c[k] = (c[k] || 0) + n * 0.5; });
    });
    return c;
  }
  // Níveis 0–4 relativos ao músculo mais trabalhado (mostra o equilíbrio entre eles)
  function niveisRelativos(c) {
    const max = Math.max.apply(null, [0].concat(Object.keys(c).map(function (k) { return c[k]; })));
    const lv = {};
    Object.keys(c).forEach(function (k) { const r = max ? c[k] / max : 0; lv[k] = r <= 0 ? 0 : r < 0.25 ? 1 : r < 0.5 ? 2 : r < 0.8 ? 3 : 4; });
    return lv;
  }
  function corpoSVG(niveis, mini, clicavel) {
    const C = window.ForjaCorpo; if (!C) return '';
    const g = C[S.perfil.resp.sexo === 'F' ? 'female' : 'male'];
    let h = '<div class="bodymap' + (mini ? ' mini' : '') + '">';
    ['front', 'back'].forEach(function (lado) {
      const v = g[lado];
      h += '<svg class="bm-v" viewBox="' + v.vb + '" role="img" aria-label="Corpo ' + (lado === 'front' ? 'de frente' : 'de costas') + '">';
      Object.keys(v.p).forEach(function (k) {
        if (INERTE[k]) v.p[k].forEach(function (d) { h += '<path class="bm-sil" d="' + d + '"/>'; });
      });
      Object.keys(v.p).forEach(function (k) {
        if (INERTE[k]) return;
        const l = niveis[k] || 0, sel = !mini && S.mmSel === k;
        v.p[k].forEach(function (d) { h += '<path class="bm-m l' + l + (sel ? ' sel' : '') + '" d="' + d + '"' + (clicavel ? ' data-act="musc" data-m="' + k + '"' : '') + '><title>' + esc(NOME_MUSC[k] || k) + '</title></path>'; });
      });
      h += '</svg>';
    });
    return h + '</div>';
  }
  function legendaCorpo(menos, mais) {
    return '<div class="bm-leg"><span>' + esc(menos) + '</span>' + [0, 1, 2, 3, 4].map(function (l) { return '<i class="l' + l + '"></i>'; }).join('') + '<span>' + esc(mais) + '</span></div>';
  }
  function renderMapaMuscular(logs) {
    const modo = S.mmModo || 'volume';
    const agora = Date.now();
    let niveis = {}, valor = {}, leg = ['Menos', 'Mais'], texto;
    if (modo === 'volume') {
      const c = cargaMusculos([].concat.apply([], logs.filter(function (l) { return agora - new Date(l.data).getTime() < 7 * 864e5; }).map(function (l) { return l.itens || []; })));
      niveis = niveisRelativos(c);
      Object.keys(c).forEach(function (k) { valor[k] = fmt(c[k], c[k] % 1 ? 1 : 0) + ' séries efetivas nos últimos 7 dias'; });
      texto = 'Quanto mais forte a cor, mais séries o músculo recebeu nos últimos 7 dias (principal conta 1, secundário conta meia série).';
    } else {
      // Última vez que cada músculo trabalhou como principal ou secundário
      const ult = {};
      logs.forEach(function (l) {
        const t = new Date(l.data).getTime();
        (l.itens || []).forEach(function (it) { const m = (window.ForjaMusculosEx || {})[it.ex]; if (!m) return; m[0].concat(m[1]).forEach(function (k) { ult[k] = Math.max(ult[k] || 0, t); }); });
      });
      Object.keys(NOME_MUSC).forEach(function (k) {
        const hs = ult[k] ? (agora - ult[k]) / 36e5 : Infinity;
        if (modo === 'recuperacao') {
          niveis[k] = hs < 24 ? 4 : hs < 48 ? 3 : hs < 72 ? 2 : hs < 96 ? 1 : 0;
          valor[k] = ult[k] ? (hs < 72 ? 'Recuperando: treinado há ' + Math.round(hs) + ' h' : 'Recuperado: treinado há ' + Math.round(hs / 24) + ' dias') : 'Ainda não treinado';
        } else {
          const d = hs / 24;
          niveis[k] = !ult[k] ? 4 : d > 14 ? 4 : d > 10 ? 3 : d > 7 ? 2 : d > 4 ? 1 : 0;
          valor[k] = ult[k] ? 'Último treino há ' + Math.floor(d) + ' dia' + (Math.floor(d) === 1 ? '' : 's') : 'Ainda não treinado';
        }
      });
      if (modo === 'recuperacao') { leg = ['Pronto', 'Recuperando']; texto = 'Cor forte: treinado nas últimas 24 h. Some aos poucos até 4 dias. Considera principal e secundário.'; }
      else { leg = ['Em dia', 'Parado há mais tempo']; texto = 'Cor forte: músculo sem treino há mais de 2 semanas (ou nunca treinado).'; }
    }
    let h = '<div class="card stack"><h3>Mapa muscular</h3><div class="chips">' +
      [['volume', 'Volume'], ['recuperacao', 'Recuperação'], ['parados', 'Sem treino']].map(function (m) { return '<button class="chip' + (modo === m[0] ? ' on' : '') + '" data-act="mm-modo" data-v="' + m[0] + '">' + m[1] + '</button>'; }).join('') + '</div>';
    h += corpoSVG(niveis, false, true) + legendaCorpo(leg[0], leg[1]);
    h += '<div class="small" style="min-height:20px;text-align:center">' + (S.mmSel ? '<b>' + esc(NOME_MUSC[S.mmSel] || S.mmSel) + '</b>: ' + esc(valor[S.mmSel] || 'sem treino nos últimos 7 dias') : '<span class="muted">Toque num músculo para ver os detalhes.</span>') + '</div>';
    h += '<p class="note">' + texto + '</p></div>';
    return h;
  }

  function renderEstat() {
    if (!S.logs.length) return '';
    const logs = S.logs.slice().reverse(); // mais antigo primeiro
    const pesoAtual = (S.perfil.pesos || []).length ? S.perfil.pesos[S.perfil.pesos.length - 1].kg : Number(S.perfil.resp.peso) || 0;
    let h = '';

    // 1) Resumo geral
    let totalKg = 0, totalSeries = 0, totalReps = 0;
    logs.forEach(function (l) { (l.itens || []).forEach(function (it) { it.series.forEach(function (x) { totalKg += (Number(x.kg) || 0) * (Number(x.reps) || 0); totalSeries++; totalReps += Number(x.reps) || 0; }); }); });
    // Semanas seguidas com pelo menos 1 treino (contando a atual)
    const semanaDe = function (iso) { const d = new Date(iso); d.setHours(0, 0, 0, 0); d.setDate(d.getDate() - ((d.getDay() + 6) % 7)); return d.getTime(); };
    const semanas = {}; logs.forEach(function (l) { semanas[semanaDe(l.data)] = 1; });
    let seq = 0, ref = semanaDe(new Date().toISOString());
    if (!semanas[ref]) ref -= 7 * 864e5; // semana atual ainda sem treino não quebra a sequência
    while (semanas[ref]) { seq++; ref -= 7 * 864e5; }
    const ton = totalKg >= 1000 ? fmt(totalKg / 1000, 1) + ' t' : fmt(totalKg) + ' kg';
    h += '<div class="card stack"><h3>Estatísticas</h3><div class="estat-grid">' +
      '<div><div class="big num">' + ton + '</div><div class="small muted">levantados no total</div></div>' +
      '<div><div class="big num">' + logs.length + '</div><div class="small muted">treinos</div></div>' +
      '<div><div class="big num">' + fmt(totalSeries) + '</div><div class="small muted">séries · ' + fmt(totalReps) + ' reps</div></div>' +
      '<div><div class="big num">' + seq + '</div><div class="small muted">semana' + (seq === 1 ? '' : 's') + ' seguida' + (seq === 1 ? '' : 's') + ' treinando</div></div></div>';

    // 2) Mapa de atividade: últimas 20 semanas (colunas) × dias (linhas, segunda no topo)
    const porDia = {};
    logs.forEach(function (l) { const d = l.data.slice(0, 10); porDia[d] = (porDia[d] || 0) + (l.itens || []).reduce(function (a, it) { return a + it.series.length; }, 0); });
    (S.perfil.cardio || []).forEach(function (c) { const d = c.d.slice(0, 10); porDia[d] = porDia[d] || 0.5; });
    const N = 20, cel = 13, gap = 3;
    const hoje = new Date(); hoje.setHours(0, 0, 0, 0);
    const inicio = new Date(hoje); inicio.setDate(inicio.getDate() - ((hoje.getDay() + 6) % 7) - (N - 1) * 7);
    let mapa = '<svg class="chart" viewBox="0 0 ' + (24 + N * (cel + gap)) + ' ' + (7 * (cel + gap) + 2) + '" role="img" aria-label="Dias treinados nas últimas ' + N + ' semanas">';
    ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'].forEach(function (t, i) { if (i % 2 === 0) mapa += '<text x="0" y="' + (i * (cel + gap) + 10) + '" fill="#9AA1AD" font-size="9">' + t + '</text>'; });
    for (let c = 0; c < N; c++) for (let r = 0; r < 7; r++) {
      const d = new Date(inicio); d.setDate(d.getDate() + c * 7 + r);
      if (d > hoje) continue;
      const iso = d.getFullYear() + '-' + String(d.getMonth() + 1).padStart(2, '0') + '-' + String(d.getDate()).padStart(2, '0');
      const v = porDia[iso] || 0;
      const op = v === 0 ? 0 : v < 1 ? 0.3 : v < 10 ? 0.55 : v < 20 ? 0.8 : 1;
      mapa += '<rect x="' + (20 + c * (cel + gap)) + '" y="' + (r * (cel + gap)) + '" width="' + cel + '" height="' + cel + '" rx="3" fill="' + (v ? '#FF6B2C' : '#2A2F37') + '"' + (v ? ' fill-opacity="' + op + '"' : '') + '><title>' + dataBR(iso) + (v >= 1 ? ': ' + v + ' séries' : v ? ': cardio' : '') + '</title></rect>';
    }
    mapa += '</svg>';
    h += '<div class="small muted">Dias treinados (últimas ' + N + ' semanas)</div>' + mapa + '</div>';
    h += renderMapaMuscular(logs);

    // 3) Séries por músculo nos últimos 7 dias, com a faixa de 10 a 20 séries por semana como referência
    const corte = Date.now() - 7 * 864e5;
    const porGrupo = {}, ultimo = {};
    logs.forEach(function (l) {
      const t = new Date(l.data).getTime();
      (l.itens || []).forEach(function (it) {
        const e = F.EX_BY_ID[it.ex]; if (!e) return;
        ultimo[e.g] = Math.max(ultimo[e.g] || 0, t);
        if (t >= corte) porGrupo[e.g] = (porGrupo[e.g] || 0) + it.series.length;
      });
    });
    const grupos = ['peito', 'costas', 'ombro', 'biceps', 'triceps', 'quad', 'post', 'pant', 'core'];
    const maxS = Math.max(24, Math.max.apply(null, grupos.map(function (g) { return porGrupo[g] || 0; })));
    h += '<div class="card stack"><div class="row between"><h3>Séries por músculo</h3><span class="small muted">últimos 7 dias</span></div>';
    grupos.forEach(function (g) {
      const n = porGrupo[g] || 0, w = Math.round(n / maxS * 100);
      const cor = n === 0 ? 'var(--line)' : n < 10 ? '#B8743F' : n <= 20 ? 'var(--ember)' : '#E0A030';
      h += '<div class="musc"><span class="small">' + esc(F.GRUPOS[g]) + '</span><div class="mbar"><i style="width:' + w + '%;background:' + cor + '"></i><b style="left:' + (10 / maxS * 100) + '%"></b><b style="left:' + (20 / maxS * 100) + '%"></b></div><span class="small num" style="text-align:right">' + n + '</span></div>';
    });
    const parados = grupos.filter(function (g) { return !ultimo[g] || Date.now() - ultimo[g] > 10 * 864e5; }).map(function (g) { return F.GRUPOS[g]; });
    if (parados.length) h += '<p class="small" style="margin:0;color:var(--ember)">Sem treino há mais de 10 dias: ' + esc(parados.join(', ')) + '.</p>';
    h += '<p class="note">Linhas finas: faixa de 10 a 20 séries por semana, referência comum para ganhar massa. Conta só o músculo principal de cada exercício.</p></div>';

    // 4) Força estimada por exercício
    const porEx = {};
    logs.forEach(function (l) {
      (l.itens || []).forEach(function (it) {
        let best = 0, melhor = null;
        it.series.forEach(function (x) { const v = e1rm(x.kg, x.reps); if (v > best) { best = v; melhor = x; } });
        if (!best) return;
        porEx[it.ex] = porEx[it.ex] || [];
        porEx[it.ex].push({ d: l.data.slice(0, 10), v: Math.round(best * 10) / 10, kg: melhor.kg, reps: melhor.reps });
      });
    });
    const exs = Object.keys(porEx).filter(function (k) { return F.EX_BY_ID[k]; }).sort(function (a, b) { return porEx[b].length - porEx[a].length || F.EX_BY_ID[a].nome.localeCompare(F.EX_BY_ID[b].nome, 'pt-BR'); });
    if (exs.length) {
      const sel = exs.indexOf(S.estEx) >= 0 ? S.estEx : exs[0];
      const serie = porEx[sel];
      const rec = serie.reduce(function (a, b) { return b.v > a.v ? b : a; });
      const prim = serie[0], ult = serie[serie.length - 1];
      const ganho = prim.v ? Math.round((ult.v - prim.v) / prim.v * 100) : 0;
      h += '<div class="card stack"><h3>Força estimada (1RM)</h3><select id="est-ex" aria-label="Exercício">' + exs.map(function (k) { return '<option value="' + k + '"' + (k === sel ? ' selected' : '') + '>' + esc(F.EX_BY_ID[k].nome) + ' (' + porEx[k].length + ')</option>'; }).join('') + '</select>';
      h += '<div class="estat-grid">' +
        '<div><div class="big num">' + fmt(rec.v, rec.v % 1 ? 1 : 0) + ' kg</div><div class="small muted">melhor 1RM estimado (' + fmt(rec.kg, rec.kg % 1 ? 1 : 0) + ' kg × ' + rec.reps + ')</div></div>' +
        (pesoAtual ? '<div><div class="big num">' + fmt(rec.v / pesoAtual * 100) + '%</div><div class="small muted">do seu peso corporal</div></div>' : '') +
        (serie.length > 1 ? '<div><div class="big num">' + (ganho > 0 ? '+' : '') + ganho + '%</div><div class="small muted">desde ' + dataBR(prim.d).slice(0, 5) + '</div></div>' : '') + '</div>';
      h += graficoLinha(serie, '1RM estimado', 'kg');
      h += '<p class="note">Estimativa pela fórmula de Epley: carga × (1 + repetições ÷ 30). Não é para testar a carga máxima.</p></div>';
    }

    // 5) Volume por treino (últimos 12)
    const vols = logs.slice(-12).map(function (l) { return { d: l.data.slice(0, 10), v: Number(l.volume) || 0 }; });
    if (vols.length > 1) h += '<div class="card stack"><h3>Volume por treino</h3>' + graficoLinha(vols, 'Volume', 'kg') + '<p class="note">Volume = soma de carga × repetições de todas as séries.</p></div>';
    return h;
  }

  function renderProgresso() {
    const pesos = S.perfil.pesos || [];
    const ini = pesos[0], atual = pesos[pesos.length - 1];
    const dif = ini && atual ? atual.kg - ini.kg : 0;
    let h = '<div class="stack">' + renderXP() + '<div class="card stack"><div class="row between"><div><div class="small muted">Peso atual</div><div class="big num">' + (atual ? fmt(atual.kg, 1) : '–') + ' <span style="font-size:18px">kg</span></div></div>' +
      (pesos.length > 1 ? '<span class="pill ' + (dif <= 0 ? 'down' : 'up') + ' num">' + (dif > 0 ? '+' : '') + fmt(dif, 1) + ' kg desde ' + dataBR(ini.d).slice(0, 5) + '</span>' : '') + '</div>' + ritmoPeso(pesos) + graficoPeso(pesos) +
      '<form class="row" data-form="peso"><label class="f grow" for="in-peso-hoje">Peso de hoje (kg)<input class="in num" id="in-peso-hoje" type="number" inputmode="decimal" step="0.1" min="35" max="250"></label><button class="btn primary" type="submit" style="align-self:flex-end">Registrar</button></form><div class="err" id="peso-err"></div></div>';
    h += renderCheckin();
    const cds = (S.perfil.cardio || []).slice(-10).reverse();
    if (cds.length) h += '<div class="card"><h3 style="margin-bottom:6px">Cardio recente</h3><div class="hist">' + cds.map(function (c) { return '<div class="it"><div>' + esc(c.nome || (M.CARDIO_BY_ID[c.mod] ? M.CARDIO_BY_ID[c.mod].nome : c.mod)) + (c.km ? ' · ' + fmt(c.km, 1) + ' km' : '') + '<div class="small muted num">' + dataBR(c.d.slice(0, 10)) + '</div></div><div class="num">' + c.min + ' min · ≈ ' + fmt(c.kcal) + ' kcal</div></div>'; }).join('') + '</div></div>';
    // Recordes por exercício (maior carga)
    const rec = {};
    S.logs.slice().reverse().forEach(function (l) { (l.itens || []).forEach(function (it) { it.series.forEach(function (s) { if (!rec[it.ex] || s.kg > rec[it.ex].kg) rec[it.ex] = { kg: s.kg, reps: s.reps, data: l.data }; }); }); });
    const recs = Object.keys(rec).filter(function (k) { return rec[k].kg > 0; });
    const semana = S.logs.filter(function (l) { return Date.now() - new Date(l.data).getTime() < 7 * 864e5; }).length;
    h += renderEstat();
    h += '<div class="card"><div class="row between"><h3>Treinos</h3><span class="small muted num">' + semana + ' nos últimos 7 dias · ' + S.logs.length + ' no total</span></div>';
    if (!S.logs.length) h += '<p class="muted small">Quando você finalizar um treino, ele aparece aqui.</p>';
    h += '<div class="hist">' + S.logs.slice(0, 30).map(function (l) {
      const ns = l.itens.reduce(function (a, i) { return a + i.series.length; }, 0);
      return '<div class="it"><div><b>Treino ' + esc(l.letra) + '</b> <span class="muted small">' + esc(l.nome) + '</span><div class="small muted num">' + dataBR(l.data.slice(0, 10)) + ' · ' + ns + ' séries · ' + fmt(l.volume) + ' kg de volume</div></div><button class="btn sm ghost" data-act="del-log" data-id="' + esc(l.id) + '" aria-label="Apagar treino de ' + dataBR(l.data.slice(0, 10)) + '">Apagar</button></div>';
    }).join('') + '</div></div>';
    if (recs.length) {
      h += '<div class="card"><h3 style="margin-bottom:6px">Recordes de carga</h3><div class="hist">' + recs.map(function (k) {
        return '<div class="it"><div>' + esc(F.EX_BY_ID[k] ? F.EX_BY_ID[k].nome : k) + '<div class="small muted num">' + dataBR(rec[k].data.slice(0, 10)) + '</div></div><div class="num" style="font-weight:700">' + fmt(rec[k].kg, 1) + ' kg × ' + rec[k].reps + '</div></div>';
      }).join('') + '</div></div>';
    }
    h += '</div>';
    $view.innerHTML = h;
  }


  /* ---------- Cardio ---------- */
  const M = window.ForjaMais;
  S.cardio = ls.get('forja.cardio.atual') || { mod: 'caminhada_rapida', inicio: null, acumulado: 0 };
  function cardioSegundos() { const c = S.cardio; return Math.floor((c.acumulado || 0) + (c.inicio ? (Date.now() - c.inicio) / 1000 : 0)); }
  function salvarCardioAtual() { ls.set('forja.cardio.atual', S.cardio); }
  function fmtTempo(seg) { return Math.floor(seg / 60) + ':' + String(seg % 60).padStart(2, '0'); }
  function renderCardio() {
    const c = S.cardio, seg = cardioSegundos(), peso = Number(S.perfil.resp.peso);
    let h = '<div class="card stack"><div class="row between"><h3>Cardio</h3><span class="small muted">calorias estimadas</span></div>';
    h += '<div class="chips">' + M.CARDIO.map(function (m) { return '<button class="chip' + (c.mod === m.id ? ' on' : '') + '" data-act="cardio-mod" data-v="' + m.id + '"' + (c.inicio || c.acumulado ? ' disabled' : '') + '>' + esc(m.nome) + '</button>'; }).join('') + '</div>';
    h += '<div class="cardio-t num" id="cardio-t">' + fmtTempo(seg) + '</div><div class="small muted num" style="text-align:center" id="cardio-k">≈ ' + fmt(M.kcalCardio(c.mod, peso, seg / 60)) + ' kcal</div>';
    h += '<div class="row">';
    if (c.inicio) h += '<button class="btn grow" data-act="cardio-pausar">Pausar</button>';
    else h += '<button class="btn primary grow" data-act="cardio-iniciar">' + (c.acumulado ? 'Continuar' : 'Iniciar') + '</button>';
    if (seg > 0) h += '<button class="btn grow" data-act="cardio-salvar">Concluir</button><button class="btn" data-act="cardio-cancelar">Zerar</button>';
    h += '</div>';
    h += '<form class="row" data-form="cardio-manual"><label class="f grow" for="cardio-min">Ou registre os minutos que já fez<input class="in num" id="cardio-min" type="number" inputmode="numeric" min="1" max="300"></label><button class="btn" type="submit" style="align-self:flex-end">Registrar</button></form>';
    const hoje = (S.perfil.cardio || []).filter(function (x) { return x.d.slice(0, 10) === hojeISO(); });
    if (hoje.length) h += '<div class="small muted num">Hoje: ' + hoje.reduce(function (a, x) { return a + x.min; }, 0) + ' min · ≈ ' + fmt(hoje.reduce(function (a, x) { return a + x.kcal; }, 0)) + ' kcal</div>';
    h += '<p class="note">Estimativa por MET (Compêndio de Atividades Físicas) × seu peso × tempo. Varia com o ritmo.</p></div>';
    return h;
  }
  setInterval(function () {
    const t = document.getElementById('cardio-t');
    if (!t || !S.cardio.inicio) return;
    const seg = cardioSegundos();
    t.textContent = fmtTempo(seg);
    const k = document.getElementById('cardio-k');
    if (k) k.textContent = '≈ ' + fmt(M.kcalCardio(S.cardio.mod, Number(S.perfil.resp.peso), seg / 60)) + ' kcal';
  }, 1000);
  async function registrarCardio(min) {
    const m = Math.round(min);
    if (m < 1) return;
    S.perfil.cardio = (S.perfil.cardio || []).concat([{ id: Date.now().toString(36), d: new Date().toISOString(), mod: S.cardio.mod, min: m, kcal: Math.round(M.kcalCardio(S.cardio.mod, Number(S.perfil.resp.peso), m)) }]).slice(-300);
    S.cardio = { mod: S.cardio.mod, inicio: null, acumulado: 0 }; salvarCardioAtual();
    await Store.savePerfil(S.perfil);
    render(); toast('Cardio salvo: ' + m + ' min · +' + Math.min(120, 2 * m) + ' XP');
    if (stravaLigado() && (S.perfil.strava || {}).autoCardio !== false) enviarCardioStrava(S.perfil.cardio[S.perfil.cardio.length - 1]);
  }

  /* ---------- Strava ---------- */
  function stravaLigado() { return X.ehAndroid() && !!X.stravaTok(); }
  function stravaEnviados() { S.perfil.stravaEnviados = S.perfil.stravaEnviados || {}; return S.perfil.stravaEnviados; }
  async function enviarTreinoStrava(log, silencioso) {
    if (stravaEnviados()[log.id]) { if (!silencioso) toast('Este treino já está no Strava.'); return; }
    const linhas = log.itens.map(function (it) {
      const e = F.EX_BY_ID[it.ex];
      return (e ? e.nome : it.ex) + ': ' + it.series.map(function (x) { return (x.kg ? fmt(x.kg, x.kg % 1 ? 1 : 0) + ' kg × ' : '') + x.reps; }).join(', ');
    });
    const ini = new Date(log.inicio || log.data).getTime(), fim = new Date(log.data).getTime();
    try {
      const id = await X.stravaCriar({ nome: 'Musculação · Treino ' + log.letra, tipo: 'WeightTraining', inicioMs: ini, segundos: (fim - ini) / 1000, descricao: linhas.join('\n') + '\nVolume: ' + fmt(log.volume) + ' kg\n(registrado no Forja)' });
      stravaEnviados()[log.id] = String(id || 1);
      await Store.savePerfil(S.perfil);
      toast('Treino enviado ao Strava.');
    } catch (e) { toast('Strava: ' + (e.message || 'não consegui enviar.')); }
  }
  const STRAVA_TIPO = { caminhada: 'Walk', corrida: 'Run', bike: 'Ride', bicicleta: 'Ride', eliptico: 'Elliptical', escada: 'StairStepper', remo: 'Rowing', natacao: 'Swim', pular: 'Workout', hiit: 'HighIntensityIntervalTraining' };
  async function enviarCardioStrava(c) {
    if (!c || c.strava || stravaEnviados()['c' + c.id]) return;
    const chave = Object.keys(STRAVA_TIPO).find(function (k) { return String(c.mod).indexOf(k) === 0; });
    const nome = M.CARDIO_BY_ID[c.mod] ? M.CARDIO_BY_ID[c.mod].nome : 'Cardio';
    try {
      const id = await X.stravaCriar({ nome: nome, tipo: chave ? STRAVA_TIPO[chave] : 'Workout', inicioMs: new Date(c.d).getTime() - c.min * 60e3, segundos: c.min * 60, descricao: '≈ ' + fmt(c.kcal) + ' kcal (estimativa do Forja)' });
      stravaEnviados()['c' + c.id] = String(id || 1);
      await Store.savePerfil(S.perfil);
      toast('Cardio enviado ao Strava.');
    } catch (e) { toast('Strava: ' + (e.message || 'não consegui enviar o cardio.')); }
  }
  // Traz atividades do Strava (que não vieram do Forja) para o cardio
  async function importarStrava() {
    const st = S.perfil.strava = S.perfil.strava || {};
    const desde = st.importadoAte || Date.now() - 30 * 864e5;
    S.stravaOcupado = true; render();
    try {
      const enviados = {}; Object.keys(stravaEnviados()).forEach(function (k) { enviados[stravaEnviados()[k]] = 1; });
      const ja = {}; (S.perfil.cardio || []).forEach(function (c) { if (c.strava) ja[c.strava] = 1; });
      const lista = (await X.stravaListar(desde)).filter(function (a) { return !enviados[String(a.id)] && !ja[String(a.id)]; });
      let novos = 0, ultimo = desde;
      for (let i = 0; i < lista.length; i++) {
        const a = lista[i];
        const ini = new Date(a.start_date).getTime();
        ultimo = Math.max(ultimo, ini + 1000);
        let kcal = 0;
        try { const d = await X.stravaDetalhe(a.id); kcal = Math.round(Number(d.calories) || 0); } catch (e) { kcal = 0; }
        if (!kcal && a.kilojoules) kcal = Math.round(a.kilojoules); // pedal com potência: kJ ≈ kcal gastas
        const min = Math.max(1, Math.round((a.moving_time || a.elapsed_time || 60) / 60));
        S.perfil.cardio = (S.perfil.cardio || []).concat([{ id: 's' + a.id, d: new Date(ini + min * 60e3).toISOString(), mod: 'strava', nome: 'Strava · ' + (a.name || a.sport_type || 'Atividade'), min: min, kcal: kcal, strava: String(a.id), km: a.distance ? Math.round(a.distance / 100) / 10 : 0 }]).slice(-300);
        novos++;
      }
      st.importadoAte = ultimo;
      await Store.savePerfil(S.perfil);
      toast(novos ? novos + ' atividade' + (novos > 1 ? 's' : '') + ' do Strava importada' + (novos > 1 ? 's' : '') + '.' : 'Nada novo no Strava.');
    } catch (e) { toast('Strava: ' + (e.message || 'não consegui importar.')); }
    S.stravaOcupado = false; render();
  }
  function renderStrava() {
    let h = '<div class="card stack"><h3>Strava</h3>';
    if (!X.ehAndroid()) return h + '<p class="small muted" style="margin:0">A conexão com o Strava funciona só no app do celular.</p></div>';
    const t = X.stravaTok(), st = S.perfil.strava || {};
    if (!t) {
      h += '<p class="small muted" style="margin:0">1. Em strava.com/settings/api crie a aplicação "Forja". 2. Em <b>Authorization Callback Domain</b> coloque <b>forja</b>. 3. Copie o Client ID e o Client Secret aqui.</p>';
      h += '<label class="f" for="st-id">Client ID<input class="in num" id="st-id" inputmode="numeric" autocomplete="off" value="' + esc(X.StravaId.get()) + '"></label>';
      h += '<label class="f" for="st-secret">Client Secret<input class="in" id="st-secret" type="password" autocomplete="off" placeholder="' + (X.StravaSecret.get() ? 'já salvo (deixe vazio para manter)' : '') + '"></label>';
      h += '<button class="btn primary" data-act="strava-conectar">Conectar ao Strava</button><div class="err" id="st-err"></div>';
      h += '<p class="note">O Client Secret fica só neste celular, fora do backup. Pelas regras do Strava, os dados que vêm de lá não vão para a IA do app.</p></div>';
      return h;
    }
    h += '<div class="small">Conectado' + (t.nome ? ' como <b>' + esc(t.nome) + '</b>' : '') + '.</div>';
    h += '<label class="row small" style="gap:8px"><input type="checkbox" data-act="strava-auto" data-k="autoTreino"' + (st.autoTreino !== false ? ' checked' : '') + '> Enviar cada treino finalizado como Musculação</label>';
    h += '<label class="row small" style="gap:8px"><input type="checkbox" data-act="strava-auto" data-k="autoCardio"' + (st.autoCardio !== false ? ' checked' : '') + '> Enviar o cardio registrado no Forja</label>';
    h += '<div class="row wrap"><button class="btn grow" data-act="strava-importar"' + (S.stravaOcupado ? ' disabled' : '') + '>' + (S.stravaOcupado ? 'Importando…' : 'Importar atividades do Strava') + '</button>' + (S.logs.length ? '<button class="btn grow" data-act="strava-ultimo">Enviar último treino</button>' : '') + '</div>';
    h += '<button class="btn ghost" data-act="strava-sair">Desconectar</button>';
    h += '<p class="note">Importa corridas, pedais e caminhadas dos últimos 30 dias (depois, só as novas) para o cardio, com as calorias do Strava. Os dados do Strava não vão para a IA do app.</p></div>';
    return h;
  }

  /* ---------- XP, liga e conquistas (topo da aba Progresso) ---------- */
  function renderXP() {
    const x = M.resumoXP(S.perfil, S.logs), n = x.nivel, lg = x.liga;
    const pct = Math.round((x.total - n.base) / (n.proximo - n.base) * 100);
    let h = '<div class="card stack"><div class="row between"><div><div class="small muted">Nível</div><div class="big num">' + n.nivel + '</div></div><div style="text-align:right"><div class="small muted">Liga da semana</div><div class="big" style="color:var(--ember)">' + lg.nome + '</div></div></div>';
    h += '<div class="bar"><i style="width:' + pct + '%"></i></div><div class="small muted num">' + fmt(x.total) + ' XP · faltam ' + fmt(n.proximo - x.total) + ' para o nível ' + (n.nivel + 1) + ' · ' + fmt(x.semana) + ' XP nos últimos 7 dias' + (lg.prox ? ' (' + lg.prox[0] + ' com ' + fmt(lg.prox[1]) + ')' : '') + '</div>';
    h += '<details class="calc"><summary>Conquistas (' + x.conquistas.filter(function (c) { return c.ok; }).length + ' de ' + x.conquistas.length + ')</summary><div class="conq" style="margin-top:8px">' + x.conquistas.map(function (c) {
      return '<div class="' + (c.ok ? 'on' : 'off') + '"><b>' + (c.ok ? '★ ' : '☆ ') + esc(c.nome) + '</b><br><span class="muted">' + esc(c.como) + '</span></div>';
    }).join('') + '</div><p class="note">XP: treino 100 + 5 por série · cardio 2 por minuto · refeição 10 · peso 10 por dia · check-in 50.</p></details></div>';
    return h;
  }

  /* ---------- Check-in semanal ---------- */
  function renderCheckin() {
    const mt = F.metas(S.perfil.resp);
    const sg = M.sugerirCheckin(S.perfil, mt.tipoAjuste, mt.noPiso);
    let h = '<div class="card stack"><div class="row between"><h3>Check-in semanal</h3>' + (mt.ajusteCheckin ? '<span class="small muted num">ajuste atual ' + (mt.ajusteCheckin > 0 ? '+' : '') + mt.ajusteCheckin + ' kcal</span>' : '') + '</div>';
    if (!sg.pode) h += '<p class="small muted" style="margin:0">' + esc(sg.motivo) + '</p>';
    else {
      h += '<div class="small num">Média desta semana: <b>' + fmt(sg.mediaAtual, 1) + ' kg</b> · semana anterior: ' + fmt(sg.mediaAntes, 1) + ' kg</div><p class="small" style="margin:0">' + esc(sg.texto) + '</p>';
      h += '<button class="btn primary" data-act="checkin" data-delta="' + sg.delta + '" data-pct="' + sg.pct.toFixed(3) + '" data-media="' + sg.mediaAtual.toFixed(2) + '">' + (sg.delta ? 'Aplicar ' + (sg.delta > 0 ? '+' : '') + sg.delta + ' kcal e concluir' : 'Concluir check-in') + '</button>';
      if (sg.delta) h += '<button class="btn" data-act="checkin" data-delta="0" data-pct="' + sg.pct.toFixed(3) + '" data-media="' + sg.mediaAtual.toFixed(2) + '">Concluir sem mudar as calorias</button>';
    }
    if (mt.ajusteCheckin) h += '<button class="btn sm ghost" data-act="checkin-zerar" style="align-self:flex-start">Desfazer ajustes de calorias</button>';
    h += '</div>';
    return h;
  }

  /* ---------- Treinador (chat) ---------- */
  S.chat = ls.get('forja.chat') || [];
  function catalogoTreinador() {
    const r = S.perfil.resp, ok = r.equip === 'db' ? ['db', 'bw'] : r.equip === 'bw' ? ['bw'] : ['gym', 'db', 'bw'];
    const ids = {};
    F.EX.forEach(function (e) { if (!e.extra) ids[e.id] = 1; });
    (S.perfil.fichas || []).forEach(function (f) { f.itens.forEach(function (x) { ids[x.ex] = 1; }); });
    S.logs.slice(0, 10).forEach(function (l) { (l.itens || []).forEach(function (x) { ids[x.ex] = 1; }); });
    return Object.keys(ids).map(function (id) { return F.EX_BY_ID[id]; }).filter(function (e) { return e && ok.indexOf(e.eq) >= 0; })
      .map(function (e) { const m = maquinaDe({ ex: e.id }); return e.id + '|' + e.nome + '|' + F.GRUPOS[e.g] + (m ? '|' + m : ''); }).join('\n');
  }
  // Treino montado pelo treinador: <treino>{json}</treino> no fim da resposta
  function treinoDaResposta(txt) {
    const m = /<treino>([\s\S]*?)<\/treino>/i.exec(String(txt || ''));
    if (!m) return null;
    let j; try { j = JSON.parse(m[1].trim().replace(/^```(json)?|```$/g, '')); } catch (e) { return null; }
    const itens = (Array.isArray(j.exercicios) ? j.exercicios : []).filter(function (x) { return x && F.EX_BY_ID[x.id]; }).slice(0, 10).map(function (x) {
      const ser = Math.round(Number(x.series)), d = Math.round(Number(x.descanso));
      return { ex: x.id, series: ser >= 1 && ser <= 8 ? ser : 3, reps: String(x.reps || '10–12').replace('-', '–').slice(0, 12), descanso: d >= 0 && d <= 300 ? d : 60 };
    });
    return itens.length ? { nome: String(j.nome || 'Treino do treinador').slice(0, 60), itens: itens } : null;
  }
  function textoSemTreino(txt) { return String(txt || '').replace(/<treino>[\s\S]*?<\/treino>/gi, '').replace(/<treino>[\s\S]*$/i, '').trim(); }
  function contextoTreinador() {
    const r = S.perfil.resp, mt = F.metas(r), pl = plano(), prox = pl[proximoDia(pl)];
    const hoje = diarioHoje();
    return {
      perfil: { sexo: r.sexo, idade: r.idade, altura_cm: r.altura, peso_kg: r.peso, objetivos: F.listaObjetivos(r), nivel: r.nivel, treinos_por_semana: r.dias, minutos_por_treino: r.tempo, equipamento: rotulo('equip', r.equip), metodo: r.metodo },
      metas_dia: { kcal: mt.kcal, proteina_g: mt.p, carbo_g: mt.c, gordura_g: mt.g },
      hoje: { data: hojeISO(), kcal_consumidas: Math.round(X.totalItens(hoje.map(function (e) { return e.total; })).kcal), refeicoes: hoje.map(function (e) { return e.titulo; }) },
      proximo_treino: { nome: prox.nome, exercicios: prox.itens.map(function (i) { return F.EX_BY_ID[i.ex].nome + ' ' + i.series + 'x' + i.reps; }) },
      ultimos_treinos: S.logs.slice(0, 5).map(function (l) { return { data: l.data.slice(0, 10), treino: l.nome, series: l.itens.reduce(function (a, i) { return a + i.series.length; }, 0), volume_kg: l.volume }; }),
      pesos_recentes: (S.perfil.pesos || []).slice(-8),
      catalogo_exercicios: catalogoTreinador(),
      fichas: (S.perfil.fichas || []).map(function (f) { return { nome: f.nome, exercicios: f.itens.map(function (x) { return x.ex; }) }; }),
      cardio_recente: (S.perfil.cardio || []).filter(function (c) { return !c.strava; }).slice(-5).map(function (c) { return { data: c.d.slice(0, 10), tipo: M.CARDIO_BY_ID[c.mod] ? M.CARDIO_BY_ID[c.mod].nome : c.mod, min: c.min }; })
    };
  }
  function renderCoach() {
    let h = '<div class="stack"><div class="card stack"><div class="row between"><h3>Treinador</h3>' + (S.chat.length ? '<button class="btn sm ghost" data-act="chat-limpar">Limpar conversa</button>' : '') + '</div>';
    h += '<p class="small muted" style="margin:0">Pergunte sobre treino, cargas, alimentação ou sua semana. O treinador vê seu plano, metas, diário e últimos treinos. Não substitui médico ou nutricionista.</p></div>';
    h += '<div class="chat">' + S.chat.map(function (m, i) {
      if (m.role === 'user') return '<div class="msg eu">' + esc(m.content) + '</div>';
      const t = treinoDaResposta(m.content);
      let x = '<div class="msg ia">' + esc(textoSemTreino(m.content) || (t ? 'Montei este treino:' : '')) + '</div>';
      if (t) x += '<div class="card stack" style="border-color:var(--ember)"><b>' + esc(t.nome) + '</b>' + t.itens.map(function (it) { const mq = maquinaDe({ ex: it.ex }); return '<div class="row between small"><span>' + esc(F.EX_BY_ID[it.ex].nome) + (mq ? ' <span style="color:var(--ember)">· Máq. ' + esc(mq) + '</span>' : '') + '</span><span class="num">' + it.series + ' × ' + esc(it.reps) + '</span></div>'; }).join('') + '<button class="btn primary" data-act="ia-treino-usar" data-i="' + i + '">Usar como treino de hoje</button></div>';
      return x;
    }).join('');
    if (S.chatEstado === 'pensando') h += '<div class="msg ia muted">Pensando…</div>';
    if (S.chatErro) h += '<div class="card warnbox stack" style="white-space:pre-line">' + esc(S.chatErro) + (S.chatUltima ? '<button class="btn" data-act="chat-repetir">Tentar de novo</button>' : '') + '</div>';
    h += '</div>';
    if (!S.chat.length) h += '<div class="chips">' + ['Hoje quero treinar superiores com foco em empurrar e puxar', 'Analise minha semana', 'O que comer antes do treino?', 'Monte um lanche com 30 g de proteína'].map(function (q) { return '<button class="chip" data-act="chat-sug" data-v="' + esc(q) + '">' + esc(q) + '</button>'; }).join('') + '</div>';
    h += '<form class="stack" data-form="chat"><label class="f" for="chat-in">Sua mensagem<textarea class="in" id="chat-in" rows="2" placeholder="Escreva ou use o microfone do teclado"></textarea></label><button class="btn primary" type="submit"' + (S.chatEstado === 'pensando' ? ' disabled' : '') + '>Enviar</button></form></div>';
    $view.innerHTML = h;
    window.scrollTo(0, document.body.scrollHeight);
  }
  async function enviarChat(texto) {
    const t = String(texto || '').trim();
    if (!t || S.chatEstado === 'pensando') return;
    S.chat.push({ role: 'user', content: t.slice(0, 2000) });
    S.chatEstado = 'pensando'; S.chatErro = ''; render();
    try {
      const r = await X.conversar(S.chat, contextoTreinador());
      S.chat.push({ role: 'assistant', content: String(r || '').trim() || '(sem resposta)' });
      S.chatUltima = '';
    } catch (e) { S.chat.pop(); S.chatUltima = t; S.chatErro = e.message || 'Não consegui responder agora.'; }
    S.chat = S.chat.slice(-40); ls.set('forja.chat', S.chat);
    S.chatEstado = ''; render();
  }

  /* ---------- Perfil ---------- */
  function rotulo(c, v) {
    if (LIM_NUM[c]) return fmt(v, c === 'peso' ? 1 : 0);
    if (MULTI[c]) return (v || []).map(function (x) { const o = OPC[c].find(function (y) { return y[0] === x; }); return o ? o[1] : x; }).join(' + ');
    const o = (OPC[c] || []).find(function (x) { return String(x[0]) === String(v); });
    return o ? o[1] + (c === 'dias' ? ' por semana' : c === 'refeicoes' ? ' por dia' : '') : v;
  }
  function renderPerfil() {
    const r = S.perfil.resp;
    let h = '<div class="stack"><div class="card"><h3 style="margin-bottom:6px">Suas respostas</h3><div class="hist">' + ['sexo', 'idade', 'altura', 'peso', 'objetivos', 'nivel', 'dias', 'diasSemana', 'tempo', 'divisao', 'metodo', 'estilo', 'equip', 'trabalho', 'refeicoes'].map(function (c) {
      return '<div class="it"><span class="muted">' + ROT[c] + '</span><b class="num">' + esc(rotulo(c, c === 'diasSemana' ? (r.diasSemana || diasPadrao(Number(r.dias))) : r[c])) + '</b></div>';
    }).join('') + '</div><button class="btn block" data-act="refazer" style="margin-top:12px">Refazer questionário</button><p class="note">Seu histórico de treinos e de peso é mantido.</p></div>';
    h += '<div class="card stack"><h3>Onde seus dados ficam</h3><p class="small muted" style="margin:0">' + (Store.modo === 'db' ? 'Salvos na sua conta Claude, numa área privada deste app. Você acessa de qualquer aparelho em que estiver logado.' : (window.Capacitor ? 'Salvos neste celular. Faça um backup de vez em quando e guarde em um lugar seguro.' : 'Salvos só neste navegador. Abra o app logado na sua conta Claude para guardar na nuvem.')) + '</p></div>';
    h += '<div class="card stack"><h3>Backup</h3><p class="small muted" style="margin:0">Use para levar seus dados entre a versão web e o app no celular.</p><button class="btn" data-act="bk-copiar">Copiar backup</button><label class="f" for="bk-txt">Restaurar: cole aqui o backup<textarea class="in" id="bk-txt" rows="3" style="font-size:13px"></textarea></label><div class="err" id="bk-err"></div><button class="btn" data-act="bk-restaurar">Restaurar backup</button></div>';
    h += '<div class="card stack"><h3>Inteligência artificial (foto do prato)</h3>';
    { const u = X.ultimaIA(); if (u) h += '<div class="small muted">Última resposta: ' + fmt(u.s, 1) + ' s (' + esc(u.prov) + ' · ' + esc(u.modelo) + ')</div>'; }
    if (X.ehAndroid()) {
      const g = X.ChaveGemini.get(), c = X.Chave.get();
      h += '<p class="small muted" style="margin:0">Cadastre pelo menos uma chave. O app tenta na ordem Gemini → GitHub → Claude: se um falhar ou estiver sobrecarregado, passa para o próximo. As chaves ficam só neste celular: não vão para o backup.</p>';
      h += '<div class="stack" style="gap:6px"><b>Gemini (grátis)</b>' + (g ? '<div class="row"><span class="grow small">Chave cadastrada: ••••' + esc(g.slice(-4)) + '</span><button class="btn sm" data-act="ia-remover" data-q="gemini">Remover</button></div>'
        : '<label class="f" for="ia-gemini">Chave do Google AI Studio (começa com AQ. ou AIza)<input class="in" id="ia-gemini" type="password" autocomplete="off" placeholder="AQ.Ab..."></label><button class="btn" data-act="ia-salvar" data-q="gemini">Salvar chave do Gemini</button><p class="note">Crie em aistudio.google.com → Get API key. Na faixa grátis o Google pode usar as fotos para melhorar os produtos dele.</p>') + '</div>';
      const gh = X.ChaveGitHub.get();
      h += '<div class="stack" style="gap:6px"><b>GitHub Models (grátis, reserva)</b>' + (gh ? '<div class="row"><span class="grow small">Token cadastrado: ••••' + esc(gh.slice(-4)) + '</span><button class="btn sm" data-act="ia-remover" data-q="github">Remover</button></div>'
        : '<label class="f" for="ia-github">Token do GitHub (começa com github_pat_)<input class="in" id="ia-github" type="password" autocomplete="off" placeholder="github_pat_..."></label><button class="btn" data-act="ia-salvar" data-q="github">Salvar token do GitHub</button><p class="note">Crie em github.com → Settings → Developer settings → Fine-grained tokens, só com a permissão Models (leitura).</p>') + '</div>';
      h += '<div class="stack" style="gap:6px"><b>Claude (pago)</b>' + (c ? '<div class="row"><span class="grow small">Chave cadastrada: ••••' + esc(c.slice(-4)) + '</span><button class="btn sm" data-act="ia-remover" data-q="claude">Remover</button></div>'
        : '<label class="f" for="ia-chave">Chave de API (começa com sk-ant-)<input class="in" id="ia-chave" type="password" autocomplete="off" placeholder="sk-ant-..."></label><button class="btn" data-act="ia-salvar" data-q="claude">Salvar chave do Claude</button><p class="note">Crie em platform.claude.com → API Keys. Precisa de créditos pré-pagos.</p>') + '</div>';
      h += '<div class="err" id="ia-err"></div>';
    } else {
      h += '<p class="small muted" style="margin:0">Nesta versão web, a IA usa a sua conta Claude: não precisa de chave. Na primeira foto, o Claude pede sua autorização.</p>';
    }
    h += '</div>';
    h += renderStrava();
    if (X.ehAndroid()) {
      const u = S.atualizacao;
      h += '<div class="card stack"><div class="row between"><h3>Atualização do app</h3><span class="small muted num">versão ' + X.VERSAO_WEB + '</span></div>';
      if (u && u.temNova) h += '<div class="small"><b>Versão ' + u.nova + ' disponível.</b>' + (u.novidades.length ? '<br>' + u.novidades.map(esc).join('<br>') : '') + '</div><button class="btn primary" data-act="upd-instalar">Atualizar agora</button><p class="note">Seus dados ficam guardados. O app reinicia sozinho no final.</p>';
      else h += '<div class="small muted">' + (u ? (u.erro ? esc(u.erro) : 'Você está na versão mais recente.') : 'Toque para ver se há novidades.') + '</div><button class="btn" data-act="upd-procurar">Procurar atualização</button>';
      h += '</div>';
    }
    h += '<div class="card stack"><h3>Registro por voz</h3><p class="small muted" style="margin:0">Em Dieta → Descrever e no Treinador, toque no microfone do teclado do celular e fale. O texto entra no campo e a IA calcula.</p></div>';
    h += '<p class="note">Forja · criado por Elenilton Siqueira · (11) 94335-8761<br>Uso pessoal e educativo. Não substitui médico, nutricionista ou profissional de educação física. Imagens de exercícios: Free Exercise DB (domínio público).</p></div>';
    $view.innerHTML = h;
  }

  /* ---------- Widget (só no APK Android) ---------- */
  let ultimoWidget = '';
  function atualizarWidget() {
    const cap = window.Capacitor;
    if (!cap || !cap.nativePromise || !cap.getPlatform || cap.getPlatform() !== 'android' || !S.perfil) return;
    try {
      const pl = plano(), d = pl[proximoDia(pl)], m = F.metas(S.perfil.resp);
      const semana = S.logs.filter(function (l) { return Date.now() - new Date(l.data).getTime() < 7 * 864e5; }).length;
      const rd = S.rascunho[d.letra] || {};
      const sTotal = d.itens.reduce(function (a, it) { return a + ((rd._pulados || {})[it.chave] ? 0 : it.series); }, 0);
      const sFeitas = d.itens.reduce(function (a, it) { return a + ((rd[it.chave] || []).filter(function (x) { return x && x.ok; }).length); }, 0);
      const kHoje = Math.round(X.totalItens(diarioHoje().map(function (e) { return e.total; })).kcal);
      const xp = window.ForjaMais ? window.ForjaMais.resumoXP(S.perfil, S.logs) : null;
      const dados = JSON.stringify({
        letra: d.letra, nome: d.nome, exercicios: d.itens.length,
        seriesFeitas: sFeitas, seriesTotal: sTotal, kcalHoje: kHoje, kcalMeta: m.kcal,
        kcalTexto: fmt(kHoje) + ' de ' + fmt(m.kcal) + ' kcal hoje',
        liga: xp ? 'Nível ' + xp.nivel.nivel + ' · Liga ' + xp.liga.nome : '',
        kcal: fmt(m.kcal) + ' kcal', macros: 'P ' + m.p + ' g · C ' + m.c + ' g · G ' + m.g + ' g',
        semana: semana + (semana === 1 ? ' treino' : ' treinos') + ' nos últimos 7 dias'
      });
      if (dados === ultimoWidget) return;
      ultimoWidget = dados;
      cap.nativePromise('WidgetBridge', 'update', { dados: dados }).catch(function () { /* widget opcional */ });
    } catch (e) { /* widget opcional */ }
  }

  /* Botões do widget: Treino, Foto do prato e Peso abrem o app na tela certa */
  async function acaoDoWidget() {
    const cap = window.Capacitor;
    if (!cap || !cap.nativePromise || !X.ehAndroid() || !S.perfil) return;
    let a = '', url = '';
    try { const r = (await cap.nativePromise('WidgetBridge', 'acao', {})) || {}; a = r.acao || ''; url = r.url || ''; } catch (e) { return; }
    if (url.indexOf('forja://forja') === 0) {
      try { const nome = await X.stravaRetorno(url); S.aba = 'perfil'; render(); toast('Strava conectado' + (nome ? ': ' + nome : '') + '.'); }
      catch (e) { S.aba = 'perfil'; render(); toast('Strava: ' + e.message); }
    }
    if (!a) return;
    if (a === 'treino') { S.aba = 'treino'; S.wdSel = null; render(); window.scrollTo(0, 0); }
    else if (a === 'foto') {
      S.aba = 'dieta'; render(); window.scrollTo(0, 0);
      const f = document.getElementById('foto-in');
      try { if (f) f.click(); } catch (e) { /* se o Android bloquear, o botão Foto do prato está no topo */ }
    } else if (a === 'peso') {
      S.aba = 'progresso'; render();
      const i = document.getElementById('in-peso-hoje');
      if (i) { i.scrollIntoView({ block: 'center' }); try { i.focus(); } catch (e) { /* teclado abre ao tocar */ } }
    }
  }

  /* ---------- Backup (levar dados entre web e APK) ---------- */
  async function copiarBackup() {
    const txt = JSON.stringify({ forja: 1, perfil: S.perfil, treinos: S.logs });
    try { await navigator.clipboard.writeText(txt); toast('Backup copiado. Cole no outro aparelho.'); }
    catch (e) { const t = document.getElementById('bk-txt'); if (t) { t.value = txt; t.select(); } toast('Copie o texto que apareceu na caixa.'); }
  }
  async function restaurarBackup() {
    const t = document.getElementById('bk-txt'), err = document.getElementById('bk-err');
    let o;
    try { o = JSON.parse(t.value); } catch (e) { err.textContent = 'O texto colado não é um backup do Forja.'; return; }
    if (!o || o.forja !== 1 || !o.perfil || !o.perfil.resp) { err.textContent = 'O texto colado não é um backup do Forja.'; return; }
    S.perfil = o.perfil;
    S.perfil.trocasTreino = S.perfil.trocasTreino || {}; S.perfil.trocasDieta = S.perfil.trocasDieta || {}; S.perfil.pesos = S.perfil.pesos || [];
    await Store.savePerfil(S.perfil);
    const ids = {}; S.logs.forEach(function (l) { ids[l.id] = 1; });
    const novos = (o.treinos || []).filter(function (l) { return l && l.id && !ids[l.id]; });
    for (let i = 0; i < novos.length; i++) await Store.addLog(novos[i]);
    S.logs = S.logs.concat(novos).sort(function (a, b) { return a.data < b.data ? 1 : -1; });
    toast('Backup restaurado: ' + novos.length + ' treinos importados');
    render();
  }

  /* ---------- Render ---------- */
  function render() {
    $layer.innerHTML = $layer.innerHTML && S.sheetAberta ? $layer.innerHTML : '';
    if (!S.perfil || S.aba === 'onb') { $tag.textContent = 'Seu plano'; renderOnb(); return; }
    const r = S.perfil.resp;
    $tag.textContent = rotulo('objetivos', F.listaObjetivos(r)) + ' · ' + rotulo('dias', r.dias);
    if (S.aba === 'treino') renderTreino();
    else if (S.aba === 'dieta') renderDieta();
    else if (S.aba === 'progresso') renderProgresso();
    else if (S.aba === 'coach') renderCoach();
    else renderPerfil();
    renderNav();
    atualizarWidget();
  }

  /* ---------- Eventos ---------- */
  document.addEventListener('click', async function (ev) {
    const b = ev.target.closest('[data-act]');
    if (!b) return;
    const a = b.dataset.act;
    if (a === 'fechar-sheet' && ev.target !== b) return; // clique dentro da janela não fecha
    switch (a) {
      case 'aba': S.aba = b.dataset.aba; S.trocaDieta = null; window.scrollTo(0, 0); render(); break;
      case 'onb-opt': {
        lerNumeros();
        const c = b.dataset.campo, v = b.dataset.v;
        if (MULTI[c]) {
          const l = (S.onb.r[c] || []).slice(), i = l.indexOf(v);
          if (i >= 0) l.splice(i, 1); else l.push(v);
          S.onb.r[c] = l;
        } else S.onb.r[c] = v;
        if (c === 'dias' && (S.onb.r.diasSemana || []).length !== Number(v)) S.onb.r.diasSemana = diasPadrao(Number(v));
        renderOnb(); break;
      }
      case 'onb-voltar': lerNumeros(); S.onb.passo--; renderOnb(); break;
      case 'onb-cancelar': S.aba = 'perfil'; render(); break;
      case 'onb-seguir': {
        const e = validarPasso();
        if (e) { renderOnb(e); return; }
        if (S.onb.passo < PASSOS.length - 1) { S.onb.passo++; renderOnb(); window.scrollTo(0, 0); }
        else await concluirOnb();
        break;
      }
      case 'refazer': S.onb = { passo: 0, r: clone(S.perfil.resp) }; if (!S.onb.r.diasSemana) S.onb.r.diasSemana = diasPadrao(Number(S.onb.r.dias)); S.aba = 'onb'; render(); break;
      case 'dia-sem': S.wdSel = Number(b.dataset.w); render(); break;
      case 'serie': marcarSerie(b.dataset.k, Number(b.dataset.s), Number(b.dataset.d)); break;
      case 'como': S.abertas[b.dataset.k] = !S.abertas[b.dataset.k]; render(); break;
      case 'strava-conectar': {
        const id = (document.getElementById('st-id').value || '').trim(), sec = (document.getElementById('st-secret').value || '').trim();
        const err = document.getElementById('st-err');
        if (!/^\d{3,10}$/.test(id)) { err.textContent = 'O Client ID é só números.'; break; }
        if (sec && !/^[0-9a-f]{30,64}$/i.test(sec)) { err.textContent = 'O Client Secret parece incompleto. Copie de novo do Strava.'; break; }
        if (!sec && !X.StravaSecret.get()) { err.textContent = 'Cole o Client Secret.'; break; }
        X.StravaId.set(id); if (sec) X.StravaSecret.set(sec);
        try { await X.stravaConectar(); } catch (e) { err.textContent = e.message; }
        break;
      }
      case 'strava-importar': importarStrava(); break;
      case 'strava-ultimo': enviarTreinoStrava(S.logs[0], false); break;
      case 'strava-sair': {
        if (b.dataset.confirm !== '1') { b.dataset.confirm = '1'; b.textContent = 'Confirmar desconexão'; return; }
        X.stravaDesconectar(); render(); toast('Strava desconectado neste celular.'); break;
      }
      case 'ia-treino-usar': {
        const t = treinoDaResposta((S.chat[Number(b.dataset.i)] || {}).content);
        if (!t) break;
        t.id = Date.now().toString(36);
        // rascunho do treino de IA usa a letra 'IA': limpa marcações antigas
        delete S.rascunho.IA; salvarRascunho();
        S.perfil.treinosIA = (S.perfil.treinosIA || []).concat([t]).slice(-3);
        const tr = S.perfil.trocaDia = S.perfil.trocaDia || {};
        tr[dataDoDia(hojeWd())] = 'i:' + t.id;
        await Store.savePerfil(S.perfil);
        S.aba = 'treino'; S.wdSel = hojeWd(); S.trocandoDia = false; window.scrollTo(0, 0); render();
        toast('Treino do treinador colocado em hoje.'); break;
      }
      case 'trocadia-abrir': S.trocandoDia = !S.trocandoDia; render(); break;
      case 'trocadia-fechar': S.trocandoDia = false; render(); break;
      case 'trocadia': {
        const tr = S.perfil.trocaDia = S.perfil.trocaDia || {};
        const iso = dataDoDia(S.wdSel);
        if (b.dataset.orig === '1') delete tr[iso]; else tr[iso] = b.dataset.k;
        // guarda só as trocas das últimas 3 semanas
        const lim = Date.now() - 21 * 864e5;
        Object.keys(tr).forEach(function (k) { if (new Date(k + 'T12:00:00').getTime() < lim) delete tr[k]; });
        S.trocandoDia = false; await Store.savePerfil(S.perfil); render(); window.scrollTo(0, 0);
        toast(b.dataset.orig === '1' ? 'Voltou ao treino previsto.' : 'Treino trocado para ' + (S.wdSel === hojeWd() ? 'hoje' : NOME_DIA[S.wdSel].toLowerCase()) + '.'); break;
      }
      case 'ficha-ativa': {
        const f = (S.perfil.fichas || []).find(function (x) { return x.id === b.dataset.id; });
        if (f) { f.ativa = f.ativa === false; if (f.ativa) S.perfil.usarFichas = true; S.wdSel = null; await Store.savePerfil(S.perfil); render(); toast(f.ativa ? 'Ficha entra na semana.' : 'Ficha guardada: fica disponível em Trocar treino do dia.'); }
        break;
      }
      case 'mm-modo': S.mmModo = b.dataset.v; S.mmSel = null; render(); break;
      case 'musc': S.mmSel = S.mmSel === b.dataset.m ? null : b.dataset.m; render(); break;
      case 'traduzir-passos': traduzirPassos(b.dataset.ex); break;
      case 'trocar-ex': S.sheetAberta = true; abrirTrocaEx(b.dataset.k, b.dataset.ex); break;
      case 'ocupada': {
        const letra = plano()[S.dia].letra, rd = rascunhoDia(letra);
        if (rd._reserva && rd._reserva[b.dataset.k]) { delete rd._reserva[b.dataset.k]; delete rd[b.dataset.k]; salvarRascunho(); render(); toast('Voltou para o exercício original.'); break; }
        S.sheetAberta = true; abrirReserva(b.dataset.k, b.dataset.ex); break;
      }
      case 'reserva-ex': {
        const letra = plano()[S.dia].letra, rd = rascunhoDia(letra);
        rd._reserva = rd._reserva || {}; rd._reserva[b.dataset.k] = b.dataset.ex;
        delete rd[b.dataset.k]; salvarRascunho();
        S.sheetAberta = false; $layer.innerHTML = ''; render(); toast('Trocado só por hoje.'); break;
      }
      case 'serie-mais':
      case 'serie-menos': {
        S.perfil.seriesAjuste = S.perfil.seriesAjuste || {};
        const k = b.dataset.a, d = a === 'serie-mais' ? 1 : -1;
        S.perfil.seriesAjuste[k] = Math.max(-4, Math.min(5, (S.perfil.seriesAjuste[k] || 0) + d));
        if (!S.perfil.seriesAjuste[k]) delete S.perfil.seriesAjuste[k];
        await Store.savePerfil(S.perfil); render(); break;
      }
      case 'add-ex': S.sheetAberta = true; abrirAdicionarEx(); break;
      case 'foto-aparelho': document.getElementById('aparelho-in').click(); break;
      case 'fds-treino': {
        S.perfil.extraFds = S.perfil.extraFds || {};
        S.perfil.extraFds[b.dataset.w] = Number(b.dataset.i);
        await Store.savePerfil(S.perfil); render(); break;
      }
      case 'aparelho-fechar': S.aparelho = null; render(); break;
      case 'maq-editar': { S.maqEdit = b.dataset.k; render(); const i = document.getElementById('maq-in'); if (i) i.focus(); break; }
      case 'maq-cancelar': S.maqEdit = null; render(); break;
      case 'maq-salvar': {
        const v = (document.getElementById('maq-in').value || '').trim().slice(0, 30);
        S.perfil.maquinas = S.perfil.maquinas || {};
        S.perfil.maquinas[b.dataset.ex] = v;
        S.maqEdit = null; await Store.savePerfil(S.perfil); render(); toast(v ? 'Máquina ' + v + ' salva.' : 'Número da máquina apagado.'); break;
      }
      case 'ficha-foto': document.getElementById('ficha-in').click(); break;
      case 'ficha-repetir': if (S.ultimaFicha) lerFicha(S.ultimaFicha); break;
      case 'ficha-fechar': S.fichaImp = null; render(); break;
      case 'ficha-pronta': {
        const p = FICHAS_PRONTAS.find(function (x) { return x.id === b.dataset.id; });
        if (!p) break;
        await adicionarFicha({ id: p.id, letra: p.letra, nome: p.nome, validade: p.validade, itens: p.itens.map(function (x) { return { ex: x[0], nomeFicha: x[1], maquina: x[2], series: x[3], reps: x[4], descanso: 60 }; }) });
        render(); toast('Ficha adicionada. O treino agora segue a ficha da academia.'); break;
      }
      case 'ficha-salvar': {
        const r = S.fichaImp && S.fichaImp.res;
        if (!r) break;
        const itens = [];
        let criados = 0;
        r.exercicios.forEach(function (e, i) {
          let ex = document.getElementById('fi-ex-' + i).value;
          if (ex === '__novo') { ex = criarExercicio(e.nomeFicha, document.getElementById('fi-g-' + i).value, e.equip); criados++; }
          if (!ex || !F.EX_BY_ID[ex]) return;
          const ser = Math.min(8, Math.max(1, Math.round(Number(document.getElementById('fi-ser-' + i).value) || 3)));
          const int = Math.min(600, Math.max(0, Math.round(Number(document.getElementById('fi-int-' + i).value) || 0)));
          itens.push({ ex: ex, nomeFicha: e.nomeFicha, maquina: (document.getElementById('fi-maq-' + i).value || '').trim().slice(0, 30), series: ser, reps: (document.getElementById('fi-rep-' + i).value || '').trim().slice(0, 12) || '10–12', descanso: int });
        });
        if (!itens.length) { toast('Escolha pelo menos um exercício.'); break; }
        const nome = (document.getElementById('fi-nome').value || '').trim().slice(0, 60) || 'Ficha da academia';
        const subst = document.getElementById('fi-subst');
        if (subst && subst.checked) S.perfil.fichas = [];
        await adicionarFicha({ id: 'imp', letra: nome, nome: nome, validade: r.validade, itens: itens });
        // Números lidos agora valem para os exercícios (atualiza os antigos)
        itens.forEach(function (x) { if (x.maquina) S.perfil.maquinas[x.ex] = x.maquina; });
        await Store.savePerfil(S.perfil);
        S.fichaImp = null;
        // Abre a ficha nova na tela, pronta para treinar hoje
        { const pl = plano(), ag = agenda(pl), novo = S.perfil.fichas[S.perfil.fichas.length - 1].id, idx = pl.findIndex(function (d) { return d.ficha === novo; }), w = hojeWd();
          const a = ag.find(function (x) { return x.wd === w && x.idx === idx; }) || ag.find(function (x) { return x.idx === idx; }) || ag[0];
          S.wdSel = a.wd; }
        render(); window.scrollTo(0, 0); toast('Ficha salva com ' + itens.length + ' exercícios' + (criados ? ' (' + criados + ' criado' + (criados > 1 ? 's' : '') + ')' : '') + '. Pode começar!'); break;
      }
      case 'ficha-del': {
        if (b.dataset.confirm !== '1') { b.dataset.confirm = '1'; b.textContent = 'Confirmar'; return; }
        S.perfil.fichas = (S.perfil.fichas || []).filter(function (f) { return f.id !== b.dataset.id; });
        if (!S.perfil.fichas.length) S.perfil.usarFichas = false;
        S.wdSel = null; await Store.savePerfil(S.perfil); render(); toast('Ficha apagada.'); break;
      }
      case 'aparelho-repetir': if (S.ultimoAparelho) await analisarAparelho(S.ultimoAparelho); break;
      case 'add-criar': {
        const id = criarExercicio(S.addBusca, b.dataset.g, '');
        await Store.savePerfil(S.perfil);
        S.addBusca = '';
        const bt = document.createElement('button'); bt.dataset.act = 'add-escolher'; bt.dataset.ex = id; bt.style.display = 'none'; document.body.appendChild(bt); bt.click(); bt.remove();
        break;
      }
      case 'add-grupo': S.addGrupo = b.dataset.v; S.addBusca = ''; abrirAdicionarEx(); break;
      case 'add-escolher': {
        const letra = plano()[S.dia].letra;
        S.perfil.extrasTreino = S.perfil.extrasTreino || {};
        S.perfil.extrasTreino[letra] = (S.perfil.extrasTreino[letra] || []).concat([b.dataset.ex]).slice(0, 8);
        S.aparelho = null;
        S.sheetAberta = false; $layer.innerHTML = '';
        await Store.savePerfil(S.perfil); render(); toast('Exercício adicionado ao treino ' + letra);
        break;
      }
      case 'remover-ex': {
        const m = /^x([A-Z])_(\d+)$/.exec(b.dataset.k);
        if (!m) return;
        const l = (S.perfil.extrasTreino || {})[m[1]] || [];
        l.splice(Number(m[2]), 1);
        delete rascunhoDia(m[1])[b.dataset.k]; salvarRascunho();
        await Store.savePerfil(S.perfil); render(); toast('Exercício removido');
        break;
      }
      case 'escolher-ex': {
        const mx = /^x([A-Z])_(\d+)$/.exec(b.dataset.k);
        if (mx) {
          S.perfil.extrasTreino[mx[1]][Number(mx[2])] = b.dataset.ex;
          delete rascunhoDia(mx[1])[b.dataset.k]; salvarRascunho();
          S.sheetAberta = false; $layer.innerHTML = '';
          await Store.savePerfil(S.perfil); render(); toast('Exercício trocado');
          break;
        }
        S.perfil.trocasTreino[b.dataset.k] = b.dataset.ex;
        const pl = plano(); delete rascunhoDia(pl[S.dia].letra)[b.dataset.k]; salvarRascunho();
        S.sheetAberta = false; $layer.innerHTML = '';
        await Store.savePerfil(S.perfil); render(); toast('Exercício trocado');
        break;
      }
      case 'fechar-sheet': S.sheetAberta = false; $layer.innerHTML = ''; break;
      case 'finalizar': await finalizarTreino(); break;
      case 'bk-copiar': await copiarBackup(); break;
      case 'cardio-mod': S.cardio.mod = b.dataset.v; salvarCardioAtual(); render(); break;
      case 'cardio-iniciar': S.cardio.inicio = Date.now(); salvarCardioAtual(); render(); break;
      case 'cardio-pausar': S.cardio.acumulado = cardioSegundos(); S.cardio.inicio = null; salvarCardioAtual(); render(); break;
      case 'cardio-cancelar': S.cardio = { mod: S.cardio.mod, inicio: null, acumulado: 0 }; salvarCardioAtual(); render(); break;
      case 'cardio-salvar': {
        const seg = cardioSegundos();
        if (seg < 60) { toast('Faça pelo menos 1 minuto para salvar.'); return; }
        await registrarCardio(seg / 60); break;
      }
      case 'checkin': {
        const delta = Number(b.dataset.delta) || 0;
        S.perfil.checkins = (S.perfil.checkins || []).concat([{ d: hojeISO(), media: Number(b.dataset.media), pct: Number(b.dataset.pct), delta: delta }]).slice(-104);
        S.perfil.resp.ajusteKcal = Math.max(-500, Math.min(500, (Number(S.perfil.resp.ajusteKcal) || 0) + delta));
        await Store.savePerfil(S.perfil); render(); toast(delta ? 'Calorias ajustadas em ' + (delta > 0 ? '+' : '') + delta + ' kcal · +50 XP' : 'Check-in feito · +50 XP'); break;
      }
      case 'pular-ex': {
        const letra = plano()[S.dia].letra, rd = rascunhoDia(letra);
        rd._pulados = rd._pulados || {}; rd._pulados[b.dataset.k] = true; salvarRascunho();
        render(); toast('Exercício pulado hoje'); break;
      }
      case 'despular-ex': {
        const letra = plano()[S.dia].letra, rd = rascunhoDia(letra);
        if (rd._pulados) delete rd._pulados[b.dataset.k]; salvarRascunho(); render(); break;
      }
      case 'tirar-ex': {
        if (b.dataset.confirm !== '1') { b.dataset.confirm = '1'; b.textContent = 'Confirmar'; return; }
        const letra = plano()[S.dia].letra;
        S.perfil.removidosTreino = S.perfil.removidosTreino || {};
        S.perfil.removidosTreino[letra + ':' + b.dataset.k] = true;
        await Store.savePerfil(S.perfil); render(); toast('Exercício tirado do treino ' + letra + '. Dá para restaurar no fim da lista.'); break;
      }
      case 'restaurar-ex': {
        const letra = plano()[S.dia].letra;
        delete (S.perfil.removidosTreino || {})[letra + ':' + b.dataset.k];
        await Store.savePerfil(S.perfil); render(); toast('Exercício restaurado'); break;
      }
      case 'meta-auto': S.perfil.resp.kcalManual = 0; await Store.savePerfil(S.perfil); render(); toast('Voltou ao cálculo automático'); break;
      case 'descartar-treino': {
        if (b.dataset.confirm !== '1') { b.dataset.confirm = '1'; b.textContent = 'Toque de novo para confirmar'; return; }
        const letra = plano()[S.dia].letra;
        delete S.rascunho[letra]; salvarRascunho(); pararDescanso();
        render(); toast('Marcações do treino ' + letra + ' apagadas'); break;
      }
      case 'checkin-zerar': S.perfil.resp.ajusteKcal = 0; await Store.savePerfil(S.perfil); render(); toast('Ajustes desfeitos'); break;
      case 'chat-sug': await enviarChat(b.dataset.v); break;
      case 'chat-repetir': await enviarChat(S.chatUltima); break;
      case 'chat-limpar': S.chat = []; ls.set('forja.chat', []); S.chatErro = ''; render(); break;
      case 'bk-restaurar': await restaurarBackup(); break;
      case 'foto': document.getElementById('foto-in').click(); break;
      case 'galeria': document.getElementById('galeria-in').click(); break;
      case 'descrever': S.descrever = !S.descrever; if (!S.descrever) S.refAlvo = ''; render(); break;
      case 'analisar-texto': {
        const txt = (document.getElementById('desc-txt').value || '').trim();
        if (txt.length < 3) { toast('Escreva o que você comeu.'); return; }
        S.descTxt = txt; await analisarRefeicao(null, txt); break;
      }
      case 'res-add': await adicionarAoDiario(); break;
      case 'tentar-de-novo': if (S.ultimoPedido) await analisarRefeicao(S.ultimoPedido.arquivo, S.ultimoPedido.nota); break;
      case 'res-descartar': S.analise = null; render(); break;
      case 'diario-del': {
        if (b.dataset.confirm !== '1') { b.dataset.confirm = '1'; b.textContent = 'Confirmar'; return; }
        const d = hojeISO();
        S.perfil.diario[d] = (S.perfil.diario[d] || []).filter(function (e) { return e.id !== b.dataset.id; });
        await Store.savePerfil(S.perfil); render(); break;
      }
      case 'ia-salvar': {
        const q = b.dataset.q;
        const cfg = {
          gemini: ['ia-gemini', /^(AIza[0-9A-Za-z_-]{20,}|AQ\.[0-9A-Za-z._-]{20,})$/, 'A chave do Gemini começa com AQ. ou AIza. Confira se copiou inteira, sem espaços.', X.ChaveGemini],
          github: ['ia-github', /^(github_pat_[0-9A-Za-z_]{20,}|ghp_[0-9A-Za-z]{20,})$/, 'O token do GitHub começa com github_pat_. Confira se copiou inteiro, sem espaços.', X.ChaveGitHub],
          claude: ['ia-chave', /^sk-ant-/, 'A chave do Claude começa com sk-ant-.', X.Chave]
        }[q];
        const v = (document.getElementById(cfg[0]).value || '').trim();
        if (!cfg[1].test(v)) { document.getElementById('ia-err').textContent = cfg[2]; return; }
        cfg[3].set(v); render(); toast('Chave salva neste celular'); break;
      }
      case 'ia-remover': ({ gemini: X.ChaveGemini, github: X.ChaveGitHub, claude: X.Chave })[b.dataset.q].set(''); render(); break;
      case 'upd-procurar': {
        b.textContent = 'Procurando…';
        try { S.atualizacao = await X.procurarAtualizacao(); } catch (e) { S.atualizacao = { erro: e.message || 'Sem conexão.' }; }
        render(); break;
      }
      case 'upd-instalar': {
        b.textContent = 'Baixando…'; b.disabled = true;
        try { await X.instalarAtualizacao(S.atualizacao); } catch (e) { b.disabled = false; b.textContent = 'Atualizar agora'; toast(e.message || 'Não consegui atualizar.'); }
        break;
      }
      case 'desc-mais': if (S.descanso) { S.descanso.fim += 15000; desenharDescanso(); } break;
      case 'desc-fim': pararDescanso(); break;
      case 'dia-dieta': S.diaDieta = Number(b.dataset.n); S.trocaDieta = null; render(); break;
      case 'ref-comi': await registrarRefeicaoDoPlano(b.dataset.r); break;
      case 'ref-outra': S.refAlvo = b.dataset.r; S.descrever = true; render(); window.scrollTo(0, 0); { const t = document.getElementById('desc-txt'); if (t) t.focus(); } break;
      case 'ref-alvo': S.refAlvo = b.dataset.r; render(); break;
      case 'ref-pular': {
        const dia = hojeISO();
        S.perfil.pulas = S.perfil.pulas || {}; podarDatas(S.perfil.pulas);
        S.perfil.pulas[dia] = (S.perfil.pulas[dia] || []).concat([b.dataset.r]);
        await Store.savePerfil(S.perfil); render(); toast('Refeição pulada. O resto do dia foi recalculado.'); break;
      }
      case 'ref-despular': {
        const dia = hojeISO();
        S.perfil.pulas[dia] = (S.perfil.pulas[dia] || []).filter(function (x) { return x !== b.dataset.r; });
        await Store.savePerfil(S.perfil); render(); break;
      }
      case 'ref-desfazer': {
        const dia = hojeISO();
        S.perfil.diario[dia] = (S.perfil.diario[dia] || []).filter(function (e) { return e.refeicao !== b.dataset.r; });
        await Store.savePerfil(S.perfil); render(); break;
      }
      case 'troca-dieta': S.trocaDieta = S.trocaDieta === b.dataset.c ? null : b.dataset.c; render(); break;
      case 'escolher-alim': {
        const iso = dataMais(S.diaDieta || 0);
        S.perfil.trocasDia = S.perfil.trocasDia || {}; podarDatas(S.perfil.trocasDia);
        S.perfil.trocasDia[iso] = S.perfil.trocasDia[iso] || {};
        S.perfil.trocasDia[iso][b.dataset.c] = b.dataset.v;
        S.trocaDieta = null; render(); await Store.savePerfil(S.perfil); break;
      }
      case 'del-log': {
        if (b.dataset.confirm !== '1') { b.dataset.confirm = '1'; b.textContent = 'Confirmar'; return; }
        await Store.delLog(b.dataset.id);
        S.logs = S.logs.filter(function (l) { return l.id !== b.dataset.id; });
        render(); toast('Treino apagado');
        break;
      }
    }
  });
  // Foto escolhida: manda para a IA
  document.addEventListener('change', function (ev) {
    const i = ev.target;
    if ((i.id === 'foto-in' || i.id === 'galeria-in') && i.files && i.files[0]) analisarRefeicao(i.files[0], '');
    if (i.id === 'aparelho-in' && i.files && i.files[0]) analisarAparelho(i.files[0]);
    if (i.id === 'est-ex') { S.estEx = i.value; render(); return; }
    if (i.dataset && i.dataset.fiSel != null) { const w = document.getElementById('fi-gwrap-' + i.dataset.fiSel); if (w) w.style.display = i.value === '__novo' ? '' : 'none'; return; }
    if (i.dataset && i.dataset.act === 'strava-auto') { S.perfil.strava = S.perfil.strava || {}; S.perfil.strava[i.dataset.k] = i.checked; Store.savePerfil(S.perfil); return; }
    if (i.id === 'ficha-in' && i.files && i.files[0]) { lerFicha(i.files[0]); i.value = ''; }
    if (i.dataset && i.dataset.act === 'fichas-usar') { S.perfil.usarFichas = i.checked; S.wdSel = null; Store.savePerfil(S.perfil).then(render); }
  });
  // Gramas editadas no resultado: recalcula (redesenha ao sair do campo)
  document.addEventListener('focusout', function (ev) {
    const i = ev.target;
    if (!i.dataset || i.dataset.resG == null || !S.analise || !S.analise.res) return;
    const k = Number(i.dataset.resG), it = S.analise.res.itens[k];
    if (it && Number(i.value) !== it.gramas) { S.analise.res.itens[k] = X.ajustarGramas(it, i.value); render(); }
  });
  // Digitação nas séries vai para o rascunho (sem redesenhar a tela)
  document.addEventListener('input', function (ev) {
    const i = ev.target;
    if (i.id === 'add-busca') {
      S.addBusca = i.value;
      const l = document.getElementById('add-lista'); if (l) l.innerHTML = listaAdicionar();
      document.querySelectorAll('[data-act="add-grupo"]').forEach(function (c) { c.classList.toggle('on', !S.addBusca && c.dataset.v === (S.addGrupo || 'peito')); });
      return;
    }
    if (!i.dataset || !i.dataset.set) return;
    const pl = plano(), rd = rascunhoDia(pl[S.dia].letra);
    rd[i.dataset.k] = rd[i.dataset.k] || [];
    const v = rd[i.dataset.k][Number(i.dataset.s)] || {};
    const campo = i.dataset.set, sIdx = Number(i.dataset.s), k = i.dataset.k;
    v[campo] = i.value === '' ? null : Number(i.value);
    if (v.auto) delete v.auto[campo]; // digitado à mão: não é mais cópia
    rd[k][sIdx] = v;
    // Replica para as séries seguintes que ainda não foram feitas nem digitadas à mão
    for (let s2 = sIdx + 1; ; s2++) {
      const el = document.getElementById((campo === 'kg' ? 'kg-' : 'rp-') + k + '-' + s2);
      if (!el) break;
      const w = rd[k][s2] || {};
      const copia = w.auto && w.auto[campo];
      if (w.ok || (w[campo] != null && !copia)) continue;
      w[campo] = v[campo];
      w.auto = w.auto || {}; w.auto[campo] = true;
      if (v[campo] == null) { delete w.auto[campo]; }
      rd[k][s2] = w;
      el.value = v[campo] == null ? '' : String(v[campo]);
    }
    salvarRascunho();
  });
  document.addEventListener('submit', async function (ev) {
    if (ev.target.dataset.form === 'chat') {
      ev.preventDefault();
      const i = document.getElementById('chat-in');
      await enviarChat(i.value);
      return;
    }
    if (ev.target.dataset.form === 'meta-manual') {
      ev.preventDefault();
      const v = Number(document.getElementById('meta-in').value);
      if (!v) { S.perfil.resp.kcalManual = 0; }
      else if (v < 1000 || v > 6000) { toast('Digite uma meta entre 1.000 e 6.000 kcal.'); return; }
      else S.perfil.resp.kcalManual = v;
      await Store.savePerfil(S.perfil); render(); toast(v ? 'Meta definida: ' + fmt(F.metas(S.perfil.resp).kcal) + ' kcal' : 'Voltou ao cálculo automático');
      return;
    }
    if (ev.target.dataset.form === 'cardio-manual') {
      ev.preventDefault();
      const v = Number(document.getElementById('cardio-min').value);
      if (!v || v < 1 || v > 300) { toast('Digite entre 1 e 300 minutos.'); return; }
      await registrarCardio(v);
      return;
    }
    if (ev.target.dataset.form !== 'peso') return;
    ev.preventDefault();
    const inp = document.getElementById('in-peso-hoje');
    const kg = Number(String(inp.value).replace(',', '.'));
    if (!kg || kg < 35 || kg > 250) { document.getElementById('peso-err').textContent = 'Digite um peso entre 35 e 250 kg.'; return; }
    registrarPesoNoPerfil(S.perfil, kg);
    S.perfil.resp.peso = kg; // a dieta passa a usar o peso novo
    await Store.savePerfil(S.perfil);
    render(); toast('Peso registrado. Metas da dieta atualizadas.');
  });

  // Alterna as duas fotos de cada exercício, simulando o movimento
  if (!window.matchMedia || !window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
    setInterval(function () { document.body.classList.toggle('f1'); }, 1100);
    setInterval(manterTela, 5000);
    document.addEventListener('visibilitychange', function () { S.wake = null; manterTela(); });
  }

  /* ---------- Tela acesa no treino ----------
     Fica acesa na aba Treino depois da primeira série marcada (até finalizar ou sair da aba). */
  async function manterTela() {
    if (!('wakeLock' in navigator) || document.hidden) return;
    let ativo = false;
    try { ativo = S.aba === 'treino' && Object.keys(S.rascunho || {}).some(function (l) { const r = S.rascunho[l] || {}; return Object.keys(r).some(function (k) { return Array.isArray(r[k]) && r[k].some(function (x) { return x && x.ok; }); }); }); } catch (e) { ativo = false; }
    try {
      if (ativo && !S.wake) { S.wake = await navigator.wakeLock.request('screen'); S.wake.addEventListener('release', function () { S.wake = null; }); }
      else if (!ativo && S.wake) { const w = S.wake; S.wake = null; await w.release(); }
    } catch (e) { S.wake = null; /* aparelho não permitiu: segue normal */ }
  }

  /* ---------- Início ---------- */
  (async function iniciar() {
    await Store.init();
    try {
      S.perfil = await Store.getPerfil();
      if (S.perfil) S.logs = await Store.getLogs();
    } catch (e) {
      $view.innerHTML = '<div class="card">Não consegui carregar seus dados agora. Feche e abra o app de novo em instantes.</div>';
      return;
    }
    if (S.perfil) {
      S.perfil.trocasTreino = S.perfil.trocasTreino || {};
      S.perfil.trocasDieta = S.perfil.trocasDieta || {};
      S.perfil.pesos = S.perfil.pesos || [];
      S.perfil.resp.objetivos = F.listaObjetivos(S.perfil.resp);
      S.perfil.resp.divisao = S.perfil.resp.divisao || 'auto';
      S.perfil.resp.estilo = S.perfil.resp.estilo || 'misto';
      S.perfil.resp.metodo = S.perfil.resp.metodo || 'normal';
    }
    // Uma vez só: coloca a ficha da academia (masculina ou feminina, pelo sexo do perfil) direto na tela de treino
    if (S.perfil && !S.perfil.fichaAuto) {
      S.perfil.fichaAuto = true;
      const p = FICHAS_PRONTAS.find(function (x) { return x.id === (S.perfil.resp.sexo === 'F' ? 'f2' : 'm2'); });
      if (p && !(S.perfil.fichas || []).length) {
        await adicionarFicha({ id: p.id, letra: p.letra, nome: p.nome, validade: p.validade, itens: p.itens.map(function (x) { return { ex: x[0], nomeFicha: x[1], maquina: x[2], series: x[3], reps: x[4], descanso: 60 }; }) });
        S.aba = 'treino'; S.fichaAvisar = true;
      } else await Store.savePerfil(S.perfil);
    }
    render();
    if (S.fichaAvisar) toast('Ficha da academia (Treino 2) já está no seu treino, com os números das máquinas.');
    X.avisarPronto();
    acaoDoWidget();
    window.addEventListener('forja-acao', acaoDoWidget);
    document.addEventListener('visibilitychange', function () { if (!document.hidden) acaoDoWidget(); });
    // Confere atualização uma vez ao abrir (só no app do celular, em silêncio)
    if (X.ehAndroid()) {
      X.procurarAtualizacao().then(function (u) {
        S.atualizacao = u;
        if (u.temNova) toast('Atualização disponível. Veja em Perfil.');
        if (S.aba === 'perfil') render();
      }).catch(function () { /* sem internet: tenta na próxima abertura */ });
    }
  })();
})();
