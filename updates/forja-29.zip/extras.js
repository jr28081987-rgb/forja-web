/* Forja — foto do prato (IA), diário alimentar e atualização do app.
   Carregado depois de logic.js e antes de app.js. Expõe window.ForjaExtras. */
(function () {
  'use strict';

  /* Versão dos arquivos do app (telas e cálculos). Aumente a cada atualização publicada. */
  const VERSAO_WEB = 29;
  const URL_VERSAO = 'https://jr28081987-rgb.github.io/forja-web/version.json';
  const MODELO_API = 'claude-haiku-5-5'; // o mais rápido; suficiente para estimar porções
  // Gemini: tenta na ordem (do mais rápido ao mais completo); se um modelo não existir ou
  // estourar o limite grátis, passa ao próximo. O que funcionou fica guardado e é tentado primeiro.
  const MODELOS_GEMINI = ['gemini-2.5-flash-lite', 'gemini-flash-lite-latest', 'gemini-2.5-flash', 'gemini-flash-latest'];
  const modeloBom = guardado('forja.gemini.modelo');
  let ultimaIA = null; // {prov, modelo, s}: quem respondeu a última análise e em quanto tempo

  const ehAndroid = function () {
    const c = window.Capacitor;
    return !!(c && c.getPlatform && c.getPlatform() === 'android' && c.nativePromise);
  };
  const nativo = function (plugin, metodo, opcoes) { return window.Capacitor.nativePromise(plugin, metodo, opcoes || {}); };

  /* ---------- Chave de API (só no celular; nunca vai para backup nem para o banco) ---------- */
  function guardado(nome) {
    return {
      get: function () { try { return localStorage.getItem(nome) || ''; } catch (e) { return ''; } },
      set: function (v) { try { if (v) localStorage.setItem(nome, v); else localStorage.removeItem(nome); } catch (e) { /* sem armazenamento */ } }
    };
  }
  const Chave = guardado('forja.apikey');          // Claude (pago)
  const ChaveGemini = guardado('forja.gemini');    // Gemini (faixa grátis)
  const ChaveGitHub = guardado('forja.github');    // GitHub Models (grátis, reserva)

  /* ---------- Imagem: reduz para no máximo 1024 px e converte em JPEG ---------- */
  // 768 px cabe num único bloco de imagem do Gemini (menos dados para processar = resposta mais rápida).
  // A ficha impressa usa mais resolução para ler os números.
  function reduzirImagem(arquivo, maxLado) {
    return new Promise(function (ok, erro) {
      const url = URL.createObjectURL(arquivo);
      const img = new Image();
      img.onload = function () {
        const max = maxLado || 768, esc = Math.min(1, max / Math.max(img.width, img.height));
        const cv = document.createElement('canvas');
        cv.width = Math.round(img.width * esc); cv.height = Math.round(img.height * esc);
        cv.getContext('2d').drawImage(img, 0, 0, cv.width, cv.height);
        URL.revokeObjectURL(url);
        cv.toBlob(function (b) { b ? ok(b) : erro(new Error('Não consegui ler a foto.')); }, 'image/jpeg', 0.72);
      };
      img.onerror = function () { URL.revokeObjectURL(url); erro(new Error('Não consegui abrir essa imagem.')); };
      img.src = url;
    });
  }
  function blobParaBase64(blob) {
    return new Promise(function (ok, erro) {
      const r = new FileReader();
      r.onload = function () { ok(String(r.result).split(',')[1]); };
      r.onerror = function () { erro(new Error('Não consegui ler a foto.')); };
      r.readAsDataURL(blob);
    });
  }

  /* ---------- Pedido à IA ---------- */
  function instrucao(temFoto, nota) {
    return 'Você é um nutricionista brasileiro. ' +
      (temFoto ? 'Analise a foto do prato. Identifique cada alimento visível e estime a porção em gramas pelo tamanho no prato.' : 'Analise a descrição da refeição abaixo e estime a porção de cada alimento em gramas.') +
      (nota ? '\nInformação do usuário sobre a refeição: "' + nota.slice(0, 500) + '"' : '') +
      '\nUse como referência valores da Tabela TACO (alimentos preparados como aparecem). Seja realista: não arredonde tudo para valores redondos.' +
      '\nResponda SOMENTE com JSON, sem texto fora dele, neste formato:' +
      '\n{"titulo":"nome curto da refeição","itens":[{"nome":"Arroz branco cozido","gramas":150,"kcal":192,"p":3.8,"c":42.2,"g":0.3}],"confianca":"alta|media|baixa","observacao":"uma frase curta, por exemplo o que não deu para ver"}' +
      '\nSe a imagem não mostrar comida, responda {"itens":[],"observacao":"explique em uma frase"}.';
  }
  function lerJson(texto) {
    const t = String(texto || '').trim();
    try { return JSON.parse(t); } catch (e) { /* tenta extrair */ }
    const i = t.indexOf('{'), f = t.lastIndexOf('}');
    if (i >= 0 && f > i) return JSON.parse(t.slice(i, f + 1));
    throw new Error('A resposta da IA veio num formato inesperado. Tente de novo.');
  }
  // Normaliza e confere números (a IA pode mandar texto onde devia vir número)
  function normalizar(r) {
    const n = function (v) { const x = Number(String(v).replace(',', '.')); return isFinite(x) && x >= 0 ? x : 0; };
    const itens = (Array.isArray(r && r.itens) ? r.itens : []).slice(0, 15).map(function (i) {
      return { nome: String(i.nome || 'Alimento').slice(0, 60), gramas: Math.round(n(i.gramas)), kcal: n(i.kcal), p: n(i.p), c: n(i.c), g: n(i.g) };
    }).filter(function (i) { return i.gramas > 0 || i.kcal > 0; });
    return { titulo: String((r && r.titulo) || 'Refeição').slice(0, 60), itens: itens, confianca: String((r && r.confianca) || ''), observacao: String((r && r.observacao) || '').slice(0, 200) };
  }

  // Onde a IA roda: na versão web usa a conta Claude; no APK usa a chave de API do usuário
  async function provedor() {
    if (!ehAndroid() && typeof claude !== 'undefined' && claude.use) {
      const s = await claude.use('sample');
      if (s) return { tipo: 'conta', sample: s };
    }
    if (ChaveGemini.get() || ChaveGitHub.get() || Chave.get()) return { tipo: 'chaves' };
    return null;
  }
  async function disponivel() { try { return !!(await provedor()); } catch (e) { return false; } }

  // Envia imagem (opcional) + instrução para a IA disponível e devolve o texto da resposta
  async function rodarImagem(blob, prompt) {
    const pv = await provedor();
    if (!pv) throw new Error(ehAndroid() ? 'Para usar a IA no celular, cadastre uma chave em Perfil → Inteligência artificial (o Gemini é grátis).' : 'A IA não está disponível nesta tela.');
    if (pv.tipo === 'conta') {
      try {
        const res = await pv.sample(prompt, blob ? { images: [blob], cache: false, modelTier: 'quick' } : { cache: false, modelTier: 'quick' });
        return res.text;
      } catch (e) {
        const msg = { not_granted: 'Você não autorizou o uso do Claude nesta página.', rate_limited: 'Muitos pedidos seguidos. Espere um pouco e tente de novo.', images_unavailable: 'Esta tela não consegue enviar fotos. Use a descrição em texto.', refused: 'A IA não conseguiu analisar essa imagem. Tente outra foto.' }[e && e.code];
        throw new Error(msg || 'Não consegui falar com a IA agora. Tente de novo em instantes.');
      }
    }
    // Ordem: Gemini (grátis) → GitHub Models (grátis) → Claude (pago). Se um falhar, tenta o próximo.
    const tarefas = [];
    if (ChaveGemini.get()) tarefas.push({ nome: 'Gemini', fn: function () { return chamarGemini(blob, prompt); } });
    if (ChaveGitHub.get() && ehAndroid()) tarefas.push({ nome: 'GitHub', fn: async function () {
      const conteudo = [{ type: 'text', text: prompt }];
      if (blob) conteudo.push({ type: 'image_url', image_url: { url: 'data:image/jpeg;base64,' + await blobParaBase64(blob), detail: 'low' } });
      return githubGerar([{ role: 'user', content: conteudo }], true);
    } });
    if (Chave.get()) tarefas.push({ nome: 'Claude', fn: function () { return chamarClaude(blob, prompt); } });
    return comReserva(tarefas);
  }

  async function analisar(arquivo, nota) {
    const blob = arquivo ? await reduzirImagem(arquivo) : null;
    return normalizar(lerJson(await rodarImagem(blob, instrucao(!!blob, nota))));
  }

  /* ---------- Foto do aparelho: identifica e ensina ----------
     catalogo: [{id, nome}] dos exercícios do app, para a IA apontar o correspondente */
  async function identificarAparelho(arquivo, catalogo) {
    const blob = await reduzirImagem(arquivo);
    const lista = catalogo.map(function (e) { return e.id + ' = ' + e.nome; }).join('\n');
    const prompt = 'Você é um personal trainer brasileiro experiente. A foto mostra um aparelho ou equipamento de academia.' +
      '\nIdentifique o aparelho e ensine um iniciante a usar com segurança, em português do Brasil, frases curtas.' +
      '\nResponda SOMENTE com JSON neste formato:' +
      '\n{"reconhecido":true,"aparelho":"nome usado nas academias do Brasil","musculos":["principal","secundário"],"ajustes":["como regular banco, apoio, pegada ou pino"],"execucao":["passo 1","passo 2","passo 3"],"erros":["erro comum e como evitar"],"seguranca":"um cuidado importante","exercicio_id":"ID do catálogo abaixo que corresponde ao uso principal, ou null","outros_ids":["até 3 IDs de outros exercícios do catálogo que dá para fazer nesse aparelho"]}' +
      '\nSe não for um equipamento de academia, ou a foto não der para identificar, responda {"reconhecido":false,"aparelho":"","dica":"o que fotografar para identificar"}.' +
      '\nUse apenas IDs que existem no catálogo. Catálogo (ID = nome):\n' + lista;
    const r = lerJson(await rodarImagem(blob, prompt));
    const ids = {}; catalogo.forEach(function (e) { ids[e.id] = true; });
    const txt = function (v, n) { return String(v || '').slice(0, n || 200); };
    const arr = function (v, n) { return (Array.isArray(v) ? v : []).slice(0, n || 6).map(function (x) { return txt(x, 220); }).filter(Boolean); };
    return {
      reconhecido: r.reconhecido !== false && !!r.aparelho,
      aparelho: txt(r.aparelho, 80), dica: txt(r.dica, 200),
      musculos: arr(r.musculos, 5), ajustes: arr(r.ajustes), execucao: arr(r.execucao, 8), erros: arr(r.erros), seguranca: txt(r.seguranca, 240),
      exercicio_id: ids[r.exercicio_id] ? r.exercicio_id : null,
      outros_ids: arr(r.outros_ids, 3).filter(function (i) { return ids[i] && i !== r.exercicio_id; })
    };
  }

  /* ---------- Ficha da academia (ticket impresso) ----------
     Lê a foto do ticket e devolve os exercícios com número da máquina, séries, repetições e intervalo.
     catalogo: [{id, nome}] para a IA apontar o exercício correspondente do app. */
  async function importarFicha(arquivo, catalogo) {
    const blob = await reduzirImagem(arquivo, 1024);
    const lista = catalogo.map(function (e) { return e.id + ' = ' + e.nome; }).join('\n');
    const prompt = 'A foto é um ticket impresso de ficha de treino de academia brasileira.' +
      '\nCada linha de exercício costuma ter: número da máquina no início (às vezes "4 ou 5", ou vazio), nome do exercício, séries (ex.: 3x), repetições (ex.: 12 ou 12/15) e intervalo (ex.: INT 1\' = 1 minuto, INT 45" = 45 segundos).' +
      '\nTranscreva fielmente, sem inventar. Se um campo não aparece, use null.' +
      '\nResponda SOMENTE com JSON neste formato:' +
      '\n{"legivel":true,"treino":"título da ficha","validade":"data final se houver, dd/mm/aaaa","exercicios":[{"maquina":"texto ou null","nome":"como está no ticket","series":3,"reps":"12/15","intervalo_seg":60,"exercicio_id":"ID do catálogo que corresponde, ou null"}]}' +
      '\nSe não for uma ficha de treino legível, responda {"legivel":false,"exercicios":[]}.' +
      '\nUse apenas IDs que existem no catálogo. Catálogo (ID = nome):\n' + lista;
    const r = lerJson(await rodarImagem(blob, prompt));
    const ids = {}; catalogo.forEach(function (e) { ids[e.id] = true; });
    const txt = function (v, n) { return v == null ? '' : String(v).slice(0, n || 80).trim(); };
    const exs = (Array.isArray(r.exercicios) ? r.exercicios : []).slice(0, 20).map(function (e) {
      const ser = Math.round(Number(e.series));
      const int = Math.round(Number(e.intervalo_seg));
      return {
        nomeFicha: txt(e.nome, 80), maquina: txt(e.maquina, 30).replace(/^null$/i, ''),
        series: ser >= 1 && ser <= 8 ? ser : 3,
        reps: txt(e.reps, 12).replace('/', '–') || '10–12',
        descanso: int >= 0 && int <= 600 ? int : 60,
        ex: ids[e.exercicio_id] ? e.exercicio_id : null
      };
    }).filter(function (e) { return e.nomeFicha; });
    return { legivel: r.legivel !== false && exs.length > 0, treino: txt(r.treino, 60), validade: txt(r.validade, 12), exercicios: exs };
  }

  // Traduz os passos (em inglês) de um exercício do catálogo extra para o português
  async function traduzir(passos) {
    const prompt = 'Traduza para o português do Brasil estes passos de um exercício de academia. Use os termos das academias brasileiras (ex.: halteres, polia, banco, pegada). Frases curtas, mesma quantidade de itens.' +
      '\nResponda SOMENTE com JSON: {"passos":["...","..."]}\n' + JSON.stringify(passos);
    const r = lerJson(await rodarImagem(null, prompt));
    return (Array.isArray(r.passos) ? r.passos : []).slice(0, 12).map(function (x) { return String(x).slice(0, 400); });
  }

  // Chamada genérica ao Gemini, com troca automática de modelo
  async function geminiGerar(corpo) {
    const lista = MODELOS_GEMINI.slice();
    const bom = modeloBom.get();
    if (bom && lista.indexOf(bom) > 0) { lista.splice(lista.indexOf(bom), 1); lista.unshift(bom); }
    let ultimoErro = 'Não consegui usar o Gemini agora.';
    const espera = function (ms) { return new Promise(function (r) { setTimeout(r, ms); }); };
    // Até 3 voltas pela lista de modelos; entre voltas espera um pouco (o Google às vezes fica sobrecarregado)
    // Com o GitHub de reserva, não vale esperar: uma volta só e passa para ele
    const voltas = ChaveGitHub.get() && ehAndroid() ? 1 : 3;
    for (let volta = 0; volta < voltas; volta++) {
      if (volta > 0) await espera(volta * 2500);
      let soSobrecarga = true;
      for (let i = 0; i < lista.length; i++) {
        const modelo = lista[i];
        const cfg = Object.assign({}, corpo.generationConfig || {});
        // Modelos 2.5 "pensam" antes de responder: desligar deixa a resposta bem mais rápida
        if (/2\.5/.test(modelo)) cfg.thinkingConfig = { thinkingBudget: 0 };
        let resp;
        // Tempo máximo por modelo: se travar, desiste e passa para o próximo em vez de deixar você esperando
        const ctl = typeof AbortController !== 'undefined' ? new AbortController() : null;
        const limite = setTimeout(function () { if (ctl) ctl.abort(); }, 20000);
        const t0 = Date.now();
        try {
          resp = await fetch('https://generativelanguage.googleapis.com/v1beta/models/' + modelo + ':generateContent', {
            method: 'POST', headers: { 'content-type': 'application/json', 'x-goog-api-key': ChaveGemini.get() },
            body: JSON.stringify(Object.assign({}, corpo, { generationConfig: cfg })), signal: ctl ? ctl.signal : undefined
          });
        } catch (e) {
          clearTimeout(limite);
          if (e && e.name === 'AbortError') { ultimoErro = 'O Gemini demorou demais para responder. Toque em Tentar de novo.'; soSobrecarga = false; if (modelo === bom) modeloBom.set(''); continue; }
          throw new Error('Sem conexão com a internet, ou o Gemini não respondeu.');
        }
        clearTimeout(limite);
        const j = await resp.json().catch(function () { return {}; });
        const msg = (j.error && j.error.message) || '';
        if (resp.ok) {
          const c = (j.candidates || [])[0];
          const t = c && c.content && (c.content.parts || []).map(function (p) { return p.text || ''; }).join('');
          if (t) { modeloBom.set(modelo); ultimaIA = { prov: 'Gemini', modelo: modelo, s: (Date.now() - t0) / 1000 }; return t; }
          ultimoErro = 'O Gemini não devolveu resposta. Tente de novo.';
          continue;
        }
        if (resp.status === 400 && /api key/i.test(msg)) throw new Error('Chave do Gemini inválida. Confira em Perfil → Inteligência artificial.');
        if (resp.status === 401) throw new Error('O Google recusou a chave (' + (msg || 'não autenticado') + '). Apague a chave no AI Studio, crie outra e cadastre de novo.');
        if (resp.status === 403) throw new Error('A chave do Gemini não tem permissão. Crie a chave de novo no Google AI Studio.');
        if (modelo === bom) modeloBom.set('');
        if (resp.status >= 500) { ultimoErro = 'Os servidores do Gemini estão sobrecarregados agora. Espere um minuto e toque em Tentar de novo.'; continue; }
        soSobrecarga = false;
        // 404 = modelo não existe; 429 = limite grátis do modelo; 400 = opção não aceita pelo modelo: tenta o próximo
        ultimoErro = resp.status === 429 ? 'Limite grátis do Gemini atingido. Tente mais tarde ou amanhã.' : 'O Gemini respondeu com erro ' + resp.status + (msg ? ': ' + msg : '') + '.';
        if (resp.status !== 404 && resp.status !== 429 && resp.status !== 400) throw new Error(ultimoErro);
      }
      if (!soSobrecarga) break; // só vale esperar e repetir quando o problema é sobrecarga
    }
    throw new Error(ultimoErro);
  }
  async function chamarGemini(blob, prompt) {
    const partes = [];
    if (blob) partes.push({ inline_data: { mime_type: 'image/jpeg', data: await blobParaBase64(blob) } });
    partes.push({ text: prompt });
    return geminiGerar({ contents: [{ role: 'user', parts: partes }], generationConfig: { responseMimeType: 'application/json', temperature: 0.2, maxOutputTokens: 1500 } });
  }

  async function chamarClaude(blob, prompt) {
    const conteudo = [];
    if (blob) conteudo.push({ type: 'image', source: { type: 'base64', media_type: 'image/jpeg', data: await blobParaBase64(blob) } });
    conteudo.push({ type: 'text', text: prompt });
    return claudeMensagens({ model: MODELO_API, max_tokens: 1200, messages: [{ role: 'user', content: conteudo }] });
  }
  async function claudeMensagens(corpo) {
    let resp;
    try {
      resp = await fetch('https://api.anthropic.com/v1/messages', {
        method: 'POST',
        headers: { 'content-type': 'application/json', 'x-api-key': Chave.get(), 'anthropic-version': '2023-06-01', 'anthropic-dangerous-direct-browser-access': 'true' },
        body: JSON.stringify(corpo)
      });
    } catch (e) { throw new Error('Sem conexão com a internet, ou a IA não respondeu.'); }
    if (resp.status === 401) throw new Error('Chave do Claude inválida.');
    if (resp.status === 429) throw new Error('Limite de uso da chave do Claude atingido.');
    if (!resp.ok) { const j = await resp.json().catch(function () { return {}; }); throw new Error('A IA respondeu com erro ' + resp.status + ((j.error && j.error.message) ? ': ' + j.error.message : '') + '.'); }
    const j = await resp.json();
    return (j.content || []).filter(function (c) { return c.type === 'text'; }).map(function (c) { return c.text; }).join('');
  }

  /* GitHub Models: o GitHub não aceita chamadas de páginas (CORS), então usa o HTTP nativo do app */
  async function githubGerar(messages, json) {
    if (!ehAndroid()) throw new Error('O GitHub Models funciona só no app do celular.');
    const modelos = ['openai/gpt-4o-mini', 'openai/gpt-4o'];
    let ultimo = 'Não consegui usar o GitHub Models agora.';
    for (let i = 0; i < modelos.length; i++) {
      let r;
      try {
        r = await nativo('CapacitorHttp', 'request', {
          url: 'https://models.github.ai/inference/chat/completions', method: 'POST', responseType: 'json',
          headers: { 'Content-Type': 'application/json', 'Accept': 'application/vnd.github+json', 'Authorization': 'Bearer ' + ChaveGitHub.get(), 'X-GitHub-Api-Version': '2022-11-28' },
          data: Object.assign({ model: modelos[i], messages: messages, temperature: json ? 0.2 : 0.6, max_tokens: 900 }, json ? { response_format: { type: 'json_object' } } : {})
        });
      } catch (e) { throw new Error('Sem conexão com o GitHub Models.'); }
      let d = r && r.data;
      if (typeof d === 'string') { try { d = JSON.parse(d); } catch (e) { d = {}; } }
      d = d || {};
      const st = Number(r && r.status) || 0;
      if (st >= 200 && st < 300) {
        const t = d.choices && d.choices[0] && d.choices[0].message && d.choices[0].message.content;
        if (t) return t;
        ultimo = 'O GitHub Models não devolveu resposta.';
        continue;
      }
      const msg = (d.error && (d.error.message || d.error.code)) || d.message || '';
      if (st === 401) throw new Error('Token do GitHub inválido. Gere outro com a permissão Models.');
      if (st === 403) throw new Error('O token do GitHub não tem a permissão Models (leitura).');
      ultimo = st === 429 ? 'Limite grátis do GitHub Models atingido.' : 'O GitHub Models respondeu com erro ' + st + (msg ? ': ' + msg : '') + '.';
      if (st !== 429 && st !== 404 && st !== 400 && st < 500) break;
    }
    throw new Error(ultimo);
  }

  // Tenta cada serviço na ordem; se todos falharem, junta as mensagens
  async function comReserva(tarefas) {
    if (!tarefas.length) throw new Error('Cadastre uma chave em Perfil → Inteligência artificial.');
    const erros = [];
    for (let i = 0; i < tarefas.length; i++) {
      try { return await tarefas[i].fn(); } catch (e) { erros.push(tarefas[i].nome + ': ' + (e.message || e)); }
    }
    throw new Error(erros.join('\n'));
  }

  /* ---------- Treinador (chat) ---------- */
  function instrucaoTreinador(contexto) {
    return 'Você é o treinador do app Forja: personal trainer e orientador de alimentação, conversando em português do Brasil com o dono do app.' +
      '\nRegras: respostas curtas e práticas (até 150 palavras, use listas quando ajudar). Use os dados do usuário abaixo para personalizar.' +
      ' Você não é médico nem nutricionista: para dor, lesão, doença, remédios, gestação ou dietas muito restritivas, oriente procurar um profissional.' +
      ' Nunca sugira comer menos que a meta de calorias do app, jejuns longos ou perda de peso rápida demais.' +
      '\nDados do usuário (JSON): ' + JSON.stringify(contexto);
  }
  // turnos: [{role: 'user'|'assistant', content}] terminando no usuário
  async function conversar(turnos, contexto) {
    const pv = await provedor();
    if (!pv) throw new Error(ehAndroid() ? 'Cadastre uma chave em Perfil → Inteligência artificial (o Gemini é grátis).' : 'A IA não está disponível nesta tela.');
    const instr = instrucaoTreinador(contexto);
    const ultimos = turnos.slice(-12);
    if (pv.tipo === 'conta') {
      try {
        const r = await pv.sample([{ role: 'user', content: instr }].concat(ultimos), { cache: false });
        return r.text;
      } catch (e) {
        throw new Error({ not_granted: 'Você não autorizou o uso do Claude nesta página.', rate_limited: 'Muitos pedidos seguidos. Espere um pouco.' }[e && e.code] || 'Não consegui falar com a IA agora.');
      }
    }
    const tarefas = [];
    if (ChaveGemini.get()) tarefas.push({ nome: 'Gemini', fn: function () {
      return geminiGerar({
        systemInstruction: { parts: [{ text: instr }] },
        contents: ultimos.map(function (t) { return { role: t.role === 'assistant' ? 'model' : 'user', parts: [{ text: t.content }] }; }),
        generationConfig: { temperature: 0.6 }
      });
    } });
    if (ChaveGitHub.get() && ehAndroid()) tarefas.push({ nome: 'GitHub', fn: function () {
      return githubGerar([{ role: 'system', content: instr }].concat(ultimos.map(function (t) { return { role: t.role, content: t.content }; })), false);
    } });
    if (Chave.get()) tarefas.push({ nome: 'Claude', fn: function () {
      return claudeMensagens({ model: MODELO_API, max_tokens: 800, system: instr, messages: ultimos });
    } });
    return comReserva(tarefas);
  }

  /* ---------- Diário: soma e ajuste de porção ---------- */
  function totalItens(itens) {
    return itens.reduce(function (t, i) { return { kcal: t.kcal + i.kcal, p: t.p + i.p, c: t.c + i.c, g: t.g + i.g }; }, { kcal: 0, p: 0, c: 0, g: 0 });
  }
  // Mudou a gramagem: recalcula proporcionalmente
  function ajustarGramas(item, novas) {
    const g = Math.max(0, Math.round(Number(novas) || 0));
    const f = item.gramas > 0 ? g / item.gramas : 0;
    return { nome: item.nome, gramas: g, kcal: item.kcal * f, p: item.p * f, c: item.c * f, g: item.g * f };
  }

  /* ---------- Atualização do app (só no APK) ---------- */
  async function avisarPronto() {
    if (!ehAndroid()) return;
    try { await nativo('CapacitorUpdater', 'notifyAppReady'); } catch (e) { /* plugin ausente em APK antigo */ }
  }
  async function procurarAtualizacao() {
    const r = await fetch(URL_VERSAO + '?t=' + Date.now(), { cache: 'no-store' });
    if (!r.ok) throw new Error('Não consegui verificar agora (erro ' + r.status + ').');
    const v = await r.json();
    return { atual: VERSAO_WEB, nova: Number(v.versao) || 0, url: String(v.url || ''), checksum: String(v.checksum || ''), novidades: Array.isArray(v.novidades) ? v.novidades.map(String) : [], temNova: Number(v.versao) > VERSAO_WEB };
  }
  async function instalarAtualizacao(info) {
    if (!ehAndroid()) throw new Error('A atualização automática funciona só no app do celular.');
    if (!/^https:\/\/jr28081987-rgb\.github\.io\/forja-web\//.test(info.url)) throw new Error('Endereço de atualização inesperado.');
    // O atualizador exige o SHA-256 do pacote: confere que o arquivo baixado é exatamente o publicado
    if (!/^[0-9a-f]{64}$/.test(info.checksum)) throw new Error('Pacote de atualização sem verificação. Tente mais tarde.');
    const pacote = await nativo('CapacitorUpdater', 'download', { url: info.url, version: String(info.nova), checksum: info.checksum });
    await nativo('CapacitorUpdater', 'set', { id: pacote.id }); // recarrega o app na versão nova
  }

  window.ForjaExtras = {
    VERSAO_WEB: VERSAO_WEB, ehAndroid: ehAndroid, Chave: Chave, ChaveGemini: ChaveGemini, ChaveGitHub: ChaveGitHub,
    analisar: analisar, identificarAparelho: identificarAparelho, importarFicha: importarFicha, traduzir: traduzir, conversar: conversar, disponivel: disponivel, totalItens: totalItens, ajustarGramas: ajustarGramas,
    avisarPronto: avisarPronto, ultimaIA: function () { return ultimaIA; }, procurarAtualizacao: procurarAtualizacao, instalarAtualizacao: instalarAtualizacao
  };
})();
